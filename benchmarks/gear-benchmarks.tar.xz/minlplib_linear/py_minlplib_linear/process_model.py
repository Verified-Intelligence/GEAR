"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ProcessModel
  model = ProcessModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class ProcessModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'process_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 1)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 1)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 1)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 2)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 2)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 2)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 2)
        _m69 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m70 = VariableVectorGatherModule([0] * 2)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 2)
        _m81 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m82 = VariableVectorGatherModule([0] * 2)
        _m84 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m85 = VariableVectorGatherModule([0] * 2)
        _m86 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m83 = VectorBinaryOpModule(_m84, _m85, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m27, 'pow')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'add')
        _m43 = VectorBinaryOpModule(_m44, _m47, 'pow')
        _m51 = VectorBinaryOpModule(_m52, _m55, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'add')
        _m67 = VectorBinaryOpModule(_m68, _m71, 'pow')
        _m76 = VectorBinaryOpModule(_m77, _m80, 'add')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m58, 'mul')
        _m66 = ResidualCoefScaleModule(_m67, [0.0] * 2, dtype=torch.float64)
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 9, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m21, 'add')
        _m35 = VectorBinaryOpModule(_m36, _m41, 'add')
        _m49 = VectorBinaryOpModule(_m50, _m61, 'div')
        _m73 = VectorBinaryOpModule(_m74, _m83, 'div')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m48 = ResidualCoefScaleModule(_m49, [0.0] * 2, dtype=torch.float64)
        _m72 = ResidualCoefScaleModule(_m73, [0.0] * 2, dtype=torch.float64)
        _m10 = ResidualCoefScaleModule(_m11, [0.0] * 1, dtype=torch.float64)
        _m29 = VectorBinaryOpModule(_m30, _m33, 'mul')
        _m28 = ResidualCoefScaleModule(_m29, [0.0] * 1, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m28, _m48, _m66, _m72, _m86], [[], [0] * 1, [0] * 1, [0] * 2, [0] * 2, [0] * 2, [0] * 9], 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
