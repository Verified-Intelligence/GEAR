"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE06Model
  model = StE06Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class StE06Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e06_model_state.pt'

        _m1 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m10 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m12 = LastDimSliceModule(1, 2)
        _m14 = LastDimSliceModule(0, 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m22 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m24 = LastDimSliceModule(1, 2)
        _m26 = LastDimSliceModule(0, 1)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'pow')
        _m4 = VectorScaleModule(_m5, -1, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m9 = SharedLinearSingleCoreModule(_m10, _m11)
        _m21 = SharedLinearSingleCoreModule(_m22, _m23)
        _m8 = VectorScaleModule(_m9, -1, dtype=torch.float64)
        _m16 = VectorSumModule([_m17, _m18, _m21])
        _m2 = VectorSumModule([_m3, _m4, _m8])
        _m0 = CombinedASTModule([_m1, _m2, _m16], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
