"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StBpv2Model
  model = StBpv2Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import LastDimSliceModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class StBpv2Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_bpv2_model_state.pt'

        _m3 = VariableVectorGatherModule([0] * 2)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m10 = LastDimSliceModule(1, 2)
        _m11 = LastDimSliceModule(0, 1)
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m0 = VectorSumModule([_m1, _m4, _m7])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
