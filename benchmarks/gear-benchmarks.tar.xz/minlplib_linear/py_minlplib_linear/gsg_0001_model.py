"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Gsg0001Model
  model = Gsg0001Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Gsg0001Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'gsg_0001_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m6 = SharedLinearFormModule([0] * 34, [[0.0] * 34 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 22)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 22)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 22)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 22)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m12 = VectorBinaryOpModule(_m13, _m16, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m26, 'pow')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 3, dtype=torch.float64)
        _m8 = VectorBinaryOpModule(_m9, _m12, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m22, 'mul')
        _m7 = ResidualCoefScaleModule(_m8, [0.0] * 22, dtype=torch.float64)
        _m17 = ResidualCoefScaleModule(_m18, [0.0] * 22, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m6, _m7, _m17], [[], [0] * 2, [0] * 22, [0] * 22], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
