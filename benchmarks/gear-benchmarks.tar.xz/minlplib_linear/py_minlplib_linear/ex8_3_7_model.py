"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex837Model
  model = Ex837Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex837Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_7_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 10)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 10)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 10)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 10)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 10)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 10)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 10)
        _m38 = SharedLinearFormModule([0] * 15, [[0.0] * 15 for _ in range(40)], [0.0] * 40, dtype=torch.float64)
        _m42 = ConstantVectorModule([0.0] * 510, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 510)
        _m45 = ConstantVectorModule([0.0] * 510, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 510)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'div')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m32, 'add')
        _m40 = VectorBinaryOpModule(_m41, _m44, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m35, 'add')
        _m39 = ResidualCoefScaleModule(_m40, [0.0] * 510, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 131, dtype=torch.float64)
        _m10 = ResidualCoefScaleModule(_m11, [0.0] * 10, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m27, 'mul')
        _m22 = ResidualCoefScaleModule(_m23, [0.0] * 10, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m22, _m38, _m39], [[], [0] * 10, [0] * 10, [0] * 40, [0] * 510], 131, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 131
