"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex835Model
  model = Ex835Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex835Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_5_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 20)
        _m9 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 20)
        _m12 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 20)
        _m14 = SharedLinearFormModule([0] * 11, [[0.0] * 11 for _ in range(21)], [0.0] * 21, dtype=torch.float64)
        _m18 = ConstantVectorModule([0.0] * 398, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 398)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 398)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = ResidualCoefScaleModule(_m16, [0.0] * 398, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 20, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 20, 99, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m15], [[], [0] * 21, [0] * 398], 99, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 99
