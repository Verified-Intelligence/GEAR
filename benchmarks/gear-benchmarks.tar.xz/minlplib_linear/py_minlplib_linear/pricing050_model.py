"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Pricing050Model
  model = Pricing050Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Pricing050Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = True

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'pricing050_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 46, [[0.0] * 46 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m8 = ConstantVectorModule([0.0] * 77, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 77)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 77)
        _m23 = ConstantVectorModule([0.0] * 78, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 78)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 78)
        _m34 = ConstantVectorModule([0.0] * 94, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 94)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 94)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 6, dtype=torch.float64)
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 5, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'pow')
        _m24 = VectorUnaryOpModule(_m25, 'exp')
        _m38 = VectorBinaryOpModule(_m39, _m42, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m9 = VectorUnaryOpModule(_m10, 'exp')
        _m21 = VectorBinaryOpModule(_m22, _m28, 'mul')
        _m35 = VectorUnaryOpModule(_m36, 'exp')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m20 = ResidualCoefScaleModule(_m21, [0.0] * 78, dtype=torch.float64)
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m17, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m43, 'mul')
        _m5 = ResidualCoefScaleModule(_m6, [0.0] * 77, dtype=torch.float64)
        _m31 = ResidualCoefScaleModule(_m32, [0.0] * 94, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3, _m5, _m20, _m31], [[], [0] * 5, [0] * 77, [0] * 78, [0] * 94], 6, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 6
