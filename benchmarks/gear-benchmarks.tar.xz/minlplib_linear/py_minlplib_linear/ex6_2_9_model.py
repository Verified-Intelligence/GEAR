"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex629Model
  model = Ex629Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex629Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_9_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m3 = LastDimSliceModule(10, 11)
        _m6 = LastDimSliceModule(5, 6)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m16 = LastDimSliceModule(4, 5)
        _m17 = LastDimSliceModule(4, 5)
        _m20 = LastDimSliceModule(8, 9)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m30 = LastDimSliceModule(7, 8)
        _m31 = LastDimSliceModule(7, 8)
        _m35 = VariableVectorGatherModule([0] * 4)
        _m37 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 4)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 1)
        _m47 = LastDimSliceModule(5, 6)
        _m51 = VariableVectorGatherModule([0] * 2)
        _m53 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 2)
        _m57 = VariableVectorGatherModule([0] * 2)
        _m61 = VariableVectorGatherModule([0] * 2)
        _m63 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 2)
        _m67 = VariableVectorGatherModule([0] * 2)
        _m71 = VariableVectorGatherModule([0] * 4)
        _m73 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 4)
        _m77 = SharedLinearFormModule([0] * 4, [[0.0] * 4 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 1)
        _m81 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 1)
        _m85 = LastDimSliceModule(8, 9)
        _m89 = VariableVectorGatherModule([0] * 2)
        _m91 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m94 = VariableVectorGatherModule([0] * 2)
        _m95 = VariableVectorGatherModule([0] * 2)
        _m99 = VariableVectorGatherModule([0] * 2)
        _m101 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m104 = VariableVectorGatherModule([0] * 2)
        _m105 = VariableVectorGatherModule([0] * 2)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m15 = VectorUnaryOpModule(_m16, 'log')
        _m19 = VectorUnaryOpModule(_m20, 'log')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m29 = VectorUnaryOpModule(_m30, 'log')
        _m38 = VectorUnaryOpModule(_m39, 'log')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'div')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'div')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'div')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'div')
        _m83 = VectorBinaryOpModule(_m84, _m85, 'div')
        _m93 = VectorBinaryOpModule(_m94, _m95, 'div')
        _m103 = VectorBinaryOpModule(_m104, _m105, 'div')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m17, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m31, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m44 = VectorUnaryOpModule(_m45, 'log')
        _m54 = VectorUnaryOpModule(_m55, 'log')
        _m64 = VectorUnaryOpModule(_m65, 'log')
        _m74 = VectorUnaryOpModule(_m75, 'log')
        _m82 = VectorUnaryOpModule(_m83, 'log')
        _m92 = VectorUnaryOpModule(_m93, 'log')
        _m102 = VectorUnaryOpModule(_m103, 'log')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m21, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m90 = VectorBinaryOpModule(_m91, _m92, 'mul')
        _m100 = VectorBinaryOpModule(_m101, _m102, 'mul')
        _m33 = VectorScaleModule(_m34, 1, dtype=torch.float64)
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'mul')
        _m88 = VectorBinaryOpModule(_m89, _m90, 'mul')
        _m98 = VectorBinaryOpModule(_m99, _m100, 'mul')
        _m32 = VectorReduceModule(_m33, 'sum')
        _m49 = VectorScaleModule(_m50, 1, dtype=torch.float64)
        _m59 = VectorScaleModule(_m60, 1, dtype=torch.float64)
        _m69 = VectorScaleModule(_m70, 1, dtype=torch.float64)
        _m87 = VectorScaleModule(_m88, 1, dtype=torch.float64)
        _m97 = VectorScaleModule(_m98, 1, dtype=torch.float64)
        _m48 = VectorReduceModule(_m49, 'sum')
        _m58 = VectorReduceModule(_m59, 'sum')
        _m68 = VectorReduceModule(_m69, 'sum')
        _m86 = VectorReduceModule(_m87, 'sum')
        _m96 = VectorReduceModule(_m97, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m14, _m18, _m28, _m32, _m40, _m48, _m58, _m68, _m78, _m86, _m96])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
