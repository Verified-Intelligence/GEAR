"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex625Model
  model = Ex625Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex625Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_5_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 9 for _ in range(8)], [0.0] * 8, dtype=torch.float64)
        _m3 = LastDimSliceModule(16, 17)
        _m6 = LastDimSliceModule(11, 12)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m20 = LastDimSliceModule(12, 13)
        _m21 = LastDimSliceModule(12, 13)
        _m24 = LastDimSliceModule(14, 15)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m38 = LastDimSliceModule(15, 16)
        _m39 = LastDimSliceModule(15, 16)
        _m43 = VariableVectorGatherModule([0] * 3)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 3)
        _m49 = VariableVectorGatherModule([0] * 3)
        _m53 = VariableVectorGatherModule([0] * 24)
        _m55 = ConstantVectorModule([0.0] * 24, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 24)
        _m61 = VariableVectorGatherModule([0] * 3)
        _m63 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 3)
        _m69 = VariableVectorGatherModule([0] * 3)
        _m71 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m73 = VariableVectorGatherModule([0] * 3)
        _m77 = VariableVectorGatherModule([0] * 6)
        _m79 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m81 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(6)], [0.0] * 6, dtype=torch.float64)
        _m85 = VariableVectorGatherModule([0] * 3)
        _m87 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m89 = VariableVectorGatherModule([0] * 3)
        _m93 = VariableVectorGatherModule([0] * 3)
        _m95 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m97 = VariableVectorGatherModule([0] * 3)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m19 = VectorUnaryOpModule(_m20, 'log')
        _m23 = VectorUnaryOpModule(_m24, 'log')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m37 = VectorUnaryOpModule(_m38, 'log')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'div')
        _m56 = VectorUnaryOpModule(_m57, 'log')
        _m64 = VectorUnaryOpModule(_m65, 'log')
        _m72 = VectorUnaryOpModule(_m73, 'log')
        _m80 = VectorUnaryOpModule(_m81, 'log')
        _m88 = VectorUnaryOpModule(_m89, 'log')
        _m96 = VectorUnaryOpModule(_m97, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m12, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m21, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m39, 'mul')
        _m46 = VectorUnaryOpModule(_m47, 'log')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m94 = VectorBinaryOpModule(_m95, _m96, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m15, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m33, 'add')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'add')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'mul')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m25, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m51 = VectorScaleModule(_m52, 1, dtype=torch.float64)
        _m59 = VectorScaleModule(_m60, 1, dtype=torch.float64)
        _m67 = VectorScaleModule(_m68, 1, dtype=torch.float64)
        _m75 = VectorScaleModule(_m76, 1, dtype=torch.float64)
        _m83 = VectorScaleModule(_m84, 1, dtype=torch.float64)
        _m91 = VectorScaleModule(_m92, 1, dtype=torch.float64)
        _m41 = VectorScaleModule(_m42, 1, dtype=torch.float64)
        _m50 = VectorReduceModule(_m51, 'sum')
        _m58 = VectorReduceModule(_m59, 'sum')
        _m66 = VectorReduceModule(_m67, 'sum')
        _m74 = VectorReduceModule(_m75, 'sum')
        _m82 = VectorReduceModule(_m83, 'sum')
        _m90 = VectorReduceModule(_m91, 'sum')
        _m40 = VectorReduceModule(_m41, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m18, _m22, _m36, _m40, _m50, _m58, _m66, _m74, _m82, _m90])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
