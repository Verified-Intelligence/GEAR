"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex838Model
  model = Ex838Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex838Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_8_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 10)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 10)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 10)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 10)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 10)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 10)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 10)
        _m30 = SharedLinearFormModule([0] * 16, [[0.0] * 16 for _ in range(31)], [0.0] * 31, dtype=torch.float64)
        _m34 = ConstantVectorModule([0.0] * 510, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 510)
        _m37 = ConstantVectorModule([0.0] * 510, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 510)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m24, 'add')
        _m32 = VectorBinaryOpModule(_m33, _m36, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m27, 'add')
        _m31 = ResidualCoefScaleModule(_m32, [0.0] * 510, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 10, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m19, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 10, 131, dtype=torch.float64)
        _m14 = ResidualCoefScaleModule(_m15, [0.0] * 10, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m30, _m31], [[], [0] * 10, [0] * 31, [0] * 510], 131, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 131
