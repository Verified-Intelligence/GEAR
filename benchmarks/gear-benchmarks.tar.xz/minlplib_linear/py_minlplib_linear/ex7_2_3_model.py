"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex723Model
  model = Ex723Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex723Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex7_2_3_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m11 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 2)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 2)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 2)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 4)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 4)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 4)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 4, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m27 = ResidualCoefScaleModule(_m28, [0.0] * 3, dtype=torch.float64)
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'div')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m24, 'div')
        _m31 = VectorBinaryOpModule(_m32, _m35, 'div')
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 1, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'div')
        _m19 = ResidualCoefScaleModule(_m20, [0.0] * 2, dtype=torch.float64)
        _m30 = VectorBinaryOpModule(_m31, _m38, 'div')
        _m9 = ResidualCoefScaleModule(_m10, [0.0] * 2, dtype=torch.float64)
        _m29 = ResidualCoefScaleModule(_m30, [0.0] * 4, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3, _m9, _m19, _m27, _m29], [[], [0] * 1, [0] * 2, [0] * 2, [0] * 3, [0] * 4], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
