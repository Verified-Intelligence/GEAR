"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex6210Model
  model = Ex6210Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex6210Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_10_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 6 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m3 = LastDimSliceModule(10, 11)
        _m6 = LastDimSliceModule(7, 8)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m20 = LastDimSliceModule(6, 7)
        _m21 = LastDimSliceModule(6, 7)
        _m24 = LastDimSliceModule(9, 10)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m38 = LastDimSliceModule(8, 9)
        _m39 = LastDimSliceModule(8, 9)
        _m43 = VariableVectorGatherModule([0] * 6)
        _m45 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 6)
        _m51 = VariableVectorGatherModule([0] * 3)
        _m53 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 3)
        _m57 = VariableVectorGatherModule([0] * 3)
        _m61 = VariableVectorGatherModule([0] * 3)
        _m63 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 3)
        _m67 = VariableVectorGatherModule([0] * 3)
        _m71 = VariableVectorGatherModule([0] * 6)
        _m73 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 6)
        _m77 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(6)], [0.0] * 6, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 3)
        _m83 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m86 = VariableVectorGatherModule([0] * 3)
        _m87 = VariableVectorGatherModule([0] * 3)
        _m91 = VariableVectorGatherModule([0] * 3)
        _m93 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m96 = VariableVectorGatherModule([0] * 3)
        _m97 = VariableVectorGatherModule([0] * 3)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m19 = VectorUnaryOpModule(_m20, 'log')
        _m23 = VectorUnaryOpModule(_m24, 'log')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m37 = VectorUnaryOpModule(_m38, 'log')
        _m46 = VectorUnaryOpModule(_m47, 'log')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'div')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'div')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'div')
        _m85 = VectorBinaryOpModule(_m86, _m87, 'div')
        _m95 = VectorBinaryOpModule(_m96, _m97, 'div')
        _m8 = VectorBinaryOpModule(_m9, _m12, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m21, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m39, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m54 = VectorUnaryOpModule(_m55, 'log')
        _m64 = VectorUnaryOpModule(_m65, 'log')
        _m74 = VectorUnaryOpModule(_m75, 'log')
        _m84 = VectorUnaryOpModule(_m85, 'log')
        _m94 = VectorUnaryOpModule(_m95, 'log')
        _m7 = VectorBinaryOpModule(_m8, _m15, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m33, 'add')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m25, 'mul')
        _m41 = VectorScaleModule(_m42, 1, dtype=torch.float64)
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m90 = VectorBinaryOpModule(_m91, _m92, 'mul')
        _m40 = VectorReduceModule(_m41, 'sum')
        _m49 = VectorScaleModule(_m50, 1, dtype=torch.float64)
        _m59 = VectorScaleModule(_m60, 1, dtype=torch.float64)
        _m69 = VectorScaleModule(_m70, 1, dtype=torch.float64)
        _m79 = VectorScaleModule(_m80, 1, dtype=torch.float64)
        _m89 = VectorScaleModule(_m90, 1, dtype=torch.float64)
        _m48 = VectorReduceModule(_m49, 'sum')
        _m58 = VectorReduceModule(_m59, 'sum')
        _m68 = VectorReduceModule(_m69, 'sum')
        _m78 = VectorReduceModule(_m79, 'sum')
        _m88 = VectorReduceModule(_m89, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m18, _m22, _m36, _m40, _m48, _m58, _m68, _m78, _m88])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
