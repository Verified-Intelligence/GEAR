"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import KallCirclesrectanglesC6r1Model
  model = KallCirclesrectanglesC6r1Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class KallCirclesrectanglesC6r1Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'kall_circlesrectangles_c6r1_model_state.pt'

        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 30)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 30)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 30)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 30)
        _m19 = ConstantVectorModule([0.0] * 31, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 99)
        _m24 = SharedLinearFormModule([0] * 92, [[0.0] * 92 for _ in range(120)], [0.0] * 120, dtype=torch.float64)
        _m28 = ConstantVectorModule([0.0] * 254, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 254)
        _m31 = ConstantVectorModule([0.0] * 254, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 254)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m18 = ResidualCoefScaleModule(_m19, [0.0] * 31, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'add')
        _m20 = ResidualCoefScaleModule(_m21, [0.0] * 99, dtype=torch.float64)
        _m26 = VectorBinaryOpModule(_m27, _m30, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'mul')
        _m25 = ResidualCoefScaleModule(_m26, [0.0] * 254, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 30, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 30, 252, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m18, _m20, _m24, _m25], [[], [0] * 31, [0] * 99, [0] * 120, [0] * 254], 252, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 252
