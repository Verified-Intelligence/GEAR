"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE41Model
  model = StE41Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import CombinedASTModule, ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class StE41Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e41_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 4)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m13 = LastDimSliceModule(2, 3)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = LastDimSliceModule(1, 2)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = LastDimSliceModule(0, 1)
        _m23 = LastDimSliceModule(3, 4)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m30 = LastDimSliceModule(1, 2)
        _m32 = LastDimSliceModule(0, 1)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = LastDimSliceModule(2, 3)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m41 = LastDimSliceModule(2, 3)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = LastDimSliceModule(1, 2)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = LastDimSliceModule(0, 1)
        _m51 = LastDimSliceModule(3, 4)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m57 = LastDimSliceModule(0, 1)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = LastDimSliceModule(1, 2)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = LastDimSliceModule(2, 3)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'pow')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'pow')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'pow')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'pow')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'add')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m34, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'add')
        _m26 = SharedLinearSingleCoreModule(_m27, _m28)
        _m43 = VectorBinaryOpModule(_m44, _m45, 'add')
        _m55 = VectorBinaryOpModule(_m56, _m63, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m24, 'pow')
        _m25 = VectorScaleModule(_m26, -1, dtype=torch.float64)
        _m42 = VectorBinaryOpModule(_m43, _m52, 'pow')
        _m53 = SharedLinearSingleCoreModule(_m54, _m55)
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m10 = SharedLinearSingleCoreModule(_m11, _m12)
        _m38 = SharedLinearSingleCoreModule(_m39, _m40)
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m37 = VectorSumModule([_m38, _m53])
        _m7 = VectorSumModule([_m8, _m9, _m25])
        _m0 = CombinedASTModule([_m1, _m7, _m37], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
