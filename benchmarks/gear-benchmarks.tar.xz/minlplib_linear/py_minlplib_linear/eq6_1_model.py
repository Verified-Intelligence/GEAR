"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Eq61Model
  model = Eq61Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import CombinedASTModule, ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Eq61Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'eq6_1_model_state.pt'

        _m4 = ConstantVectorModule([0.0] * 16, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 16)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 36)
        _m12 = SharedLinearFormModule([0] * 14, [[0.0] * 14 for _ in range(36)], [0.0] * 36, dtype=torch.float64)
        _m14 = ConstantVectorModule([0.0] * 28, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 28)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 28)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 28)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 28)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m20 = VectorBinaryOpModule(_m21, _m24, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m33, 'add')
        _m2 = VectorReduceModule(_m3, 'sum')
        _m8 = VectorReduceModule(_m9, 'sum')
        _m19 = VectorBinaryOpModule(_m20, _m27, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m36, 'pow')
        _m1 = VectorSumModule([_m2, _m8])
        _m18 = VectorBinaryOpModule(_m19, _m28, 'add')
        _m17 = VectorUnaryOpModule(_m18, 'sqrt')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'add')
        _m0 = CombinedASTModule([_m1, _m13], [('scalar_at', 0, 0), ('vector_pick', 1, 0, 1), ('vector_pick', 1, 1, 2), ('vector_pick', 1, 2, 3), ('vector_pick', 1, 3, 4), ('vector_pick', 1, 4, 5), ('vector_pick', 1, 5, 6), ('vector_pick', 1, 6, 7), ('vector_pick', 1, 7, 8), ('vector_pick', 1, 8, 9), ('vector_pick', 1, 9, 10), ('vector_pick', 1, 10, 11), ('vector_pick', 1, 11, 12), ('vector_pick', 1, 12, 13), ('vector_pick', 1, 13, 14), ('vector_pick', 1, 14, 15), ('vector_pick', 1, 15, 16), ('vector_pick', 1, 16, 17), ('vector_pick', 1, 17, 18), ('vector_pick', 1, 18, 19), ('vector_pick', 1, 19, 20), ('vector_pick', 1, 20, 21), ('vector_pick', 1, 21, 22), ('vector_pick', 1, 22, 23), ('vector_pick', 1, 23, 24), ('vector_pick', 1, 24, 25), ('vector_pick', 1, 25, 26), ('vector_pick', 1, 26, 27), ('vector_pick', 1, 27, 28)], 29)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 29
