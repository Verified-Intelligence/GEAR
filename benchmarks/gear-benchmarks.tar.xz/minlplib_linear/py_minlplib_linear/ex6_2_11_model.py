"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex6211Model
  model = Ex6211Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex6211Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_11_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m3 = LastDimSliceModule(4, 5)
        _m6 = LastDimSliceModule(9, 10)
        _m7 = LastDimSliceModule(8, 9)
        _m10 = LastDimSliceModule(7, 8)
        _m11 = LastDimSliceModule(7, 8)
        _m15 = VariableVectorGatherModule([0] * 3)
        _m17 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 3)
        _m23 = VariableVectorGatherModule([0] * 3)
        _m25 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 3)
        _m29 = VariableVectorGatherModule([0] * 3)
        _m33 = VariableVectorGatherModule([0] * 3)
        _m35 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 3)
        _m39 = VariableVectorGatherModule([0] * 3)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 1)
        _m47 = LastDimSliceModule(6, 7)
        _m49 = VariableVectorGatherModule([0] * 1)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 1)
        _m55 = LastDimSliceModule(5, 6)
        _m57 = VariableVectorGatherModule([0] * 1)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 1)
        _m63 = LastDimSliceModule(3, 4)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m18 = VectorUnaryOpModule(_m19, 'log')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'div')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'div')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'div')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'div')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'div')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m11, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m26 = VectorUnaryOpModule(_m27, 'log')
        _m36 = VectorUnaryOpModule(_m37, 'log')
        _m44 = VectorUnaryOpModule(_m45, 'log')
        _m52 = VectorUnaryOpModule(_m53, 'log')
        _m60 = VectorUnaryOpModule(_m61, 'log')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m13 = VectorScaleModule(_m14, 1, dtype=torch.float64)
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m12 = VectorReduceModule(_m13, 'sum')
        _m21 = VectorScaleModule(_m22, 1, dtype=torch.float64)
        _m31 = VectorScaleModule(_m32, 1, dtype=torch.float64)
        _m20 = VectorReduceModule(_m21, 'sum')
        _m30 = VectorReduceModule(_m31, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m8, _m12, _m20, _m30, _m40, _m48, _m56])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
