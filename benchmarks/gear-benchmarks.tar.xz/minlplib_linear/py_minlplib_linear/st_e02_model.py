"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE02Model
  model = StE02Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE02Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e02_model_state.pt'

        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 2)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 2)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 4)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 4)
        _m20 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'pow')
        _m12 = ResidualCoefScaleModule(_m13, [0.0] * 4, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 2, 7, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m12, _m20], [[], [0] * 4, [0] * 7], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
