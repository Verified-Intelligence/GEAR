"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex8313Model
  model = Ex8313Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex8313Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_13_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 10)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 10)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 10)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 10)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 10)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 10)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 20)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = VariableVectorGatherModule([0] * 20)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 20)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = VariableVectorGatherModule([0] * 40)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 388)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 388)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 109, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'div')
        _m17 = VectorBinaryOpModule(_m18, _m21, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'div')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'pow')
        _m38 = VectorBinaryOpModule(_m39, _m42, 'pow')
        _m48 = VectorBinaryOpModule(_m49, _m52, 'add')
        _m55 = ResidualCoefScaleModule(_m56, [0.0] * 40, dtype=torch.float64)
        _m60 = VectorBinaryOpModule(_m61, _m64, 'mul')
        _m8 = VectorUnaryOpModule(_m9, 'exp')
        _m27 = VectorUnaryOpModule(_m28, 'exp')
        _m44 = VectorBinaryOpModule(_m45, _m48, 'mul')
        _m59 = ResidualCoefScaleModule(_m60, [0.0] * 388, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m43 = ResidualCoefScaleModule(_m44, [0.0] * 20, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m14, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m33, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m17, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m38, 'mul')
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 10, dtype=torch.float64)
        _m22 = ResidualCoefScaleModule(_m23, [0.0] * 10, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3, _m22, _m43, _m55, _m59], [[], [0] * 10, [0] * 10, [0] * 20, [0] * 40, [0] * 388], 109, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 109
