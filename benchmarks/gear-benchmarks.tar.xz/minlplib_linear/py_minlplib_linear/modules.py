"""Runtime modules for generated MINLPLib-linear PyTorch models.

The linear benchmark was generated with the common vector-IR modules plus a
small residual wrapper family used after linear constraints are separated out.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import torch
import torch.nn as nn


_BENCHMARKS_ROOT = Path(__file__).resolve().parents[2]
_BASE_MODULES = _BENCHMARKS_ROOT / "minlplib" / "mod_files" / "modules.py"
_SPEC = importlib.util.spec_from_file_location("_minlplib_generated_modules", _BASE_MODULES)
if _SPEC is None or _SPEC.loader is None:
    raise ImportError(f"Could not load generated module helpers from {_BASE_MODULES}")
_BASE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_BASE)

for _name in dir(_BASE):
    if not _name.startswith("_"):
        globals()[_name] = getattr(_BASE, _name)


def _as_last_dim_vector(v: torch.Tensor, batch_shape: torch.Size | tuple[int, ...]) -> torch.Tensor:
    if v.dim() == 0:
        v = v.reshape(1)
    if v.dim() == 1 and len(batch_shape) > 0:
        v = v.expand(*batch_shape, v.shape[-1])
    return v


def _broadcast_scalar_last_dim(v: torch.Tensor, size: int) -> torch.Tensor:
    if int(v.shape[-1]) == 1 and int(size) != 1:
        return v.expand(*v.shape[:-1], int(size))
    return v


class ResidualCoefScaleModule(nn.Module):
    """Apply per-residual coefficients to a compact residual vector."""

    def __init__(self, bucket_module: nn.Module, coef, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.bucket_module = bucket_module
        w = torch.tensor(coef, dtype=dtype)
        if w.dim() != 1:
            raise ValueError("coef must be a 1D tensor")
        self.n = int(w.numel())
        self.register_buffer("coef", w)

    def forward(self, x):
        v = self.bucket_module(x)
        v = _as_last_dim_vector(v, x.shape[:-1])
        v = _broadcast_scalar_last_dim(v, self.n)
        if not torch.jit.is_tracing() and v.shape[-1] != self.n:
            raise ValueError(f"ResidualCoefScaleModule expected last-dim {self.n}, got {int(v.shape[-1])}")
        return v * self.coef.view(*([1] * (v.dim() - 1)), self.n)


class LiftCompactToFullModule(nn.Module):
    """Scatter a compact residual vector into the full output vector."""

    def __init__(self, child_module: nn.Module, indices, total_outputs: int, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.child_module = child_module
        self.total_outputs = int(total_outputs)
        self.dtype = dtype
        self.register_buffer("indices", torch.tensor(indices, dtype=torch.long))

    def forward(self, x):
        v = self.child_module(x)
        v = _as_last_dim_vector(v, x.shape[:-1])
        v = _broadcast_scalar_last_dim(v, int(self.indices.numel()))
        out = torch.zeros(*x.shape[:-1], self.total_outputs, dtype=v.dtype, device=x.device)
        return out.index_add(out.dim() - 1, self.indices, v)

    def get_output_dimension(self):
        return self.total_outputs


class GeneralResidualModule(nn.Module):
    """Sum full-vector modules and indexed compact residual modules."""

    def __init__(self, input_modules, input_indices, total_outputs: int, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.input_modules = nn.ModuleList(input_modules)
        self.total_outputs = int(total_outputs)
        self.dtype = dtype

        if input_indices is None:
            input_indices = [[] for _ in range(len(self.input_modules))]
        if len(input_indices) != len(self.input_modules):
            raise ValueError("input_indices must match input_modules length")

        self._has_indices: list[bool] = []
        for i, indices in enumerate(input_indices):
            has_indices = len(indices) > 0
            self._has_indices.append(has_indices)
            if has_indices:
                self.register_buffer(f"_idx_{i}", torch.tensor(indices, dtype=torch.long))

    def forward(self, x):
        y = torch.zeros(*x.shape[:-1], self.total_outputs, dtype=self.dtype, device=x.device)
        for i, module in enumerate(self.input_modules):
            v = module(x)
            v = _as_last_dim_vector(v, x.shape[:-1]).to(dtype=y.dtype, device=y.device)
            if self._has_indices[i]:
                idx = getattr(self, f"_idx_{i}")
                v = _broadcast_scalar_last_dim(v, int(idx.numel()))
                y = y.index_add(y.dim() - 1, idx, v)
            else:
                y = y + v
        return y

    def get_output_dimension(self):
        return self.total_outputs


__all__ = [name for name in globals() if not name.startswith("_")]
