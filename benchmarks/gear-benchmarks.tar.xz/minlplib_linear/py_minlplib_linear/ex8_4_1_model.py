"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex841Model
  model = Ex841Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex841Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_4_1_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ConstantVectorModule([0.0] * 19, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 19)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = SharedLinearFormModule([0] * 11, [[0.0] * 11 for _ in range(20)], [0.0] * 20, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 20)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 20)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m22, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m15, 'pow')
        _m17 = ResidualCoefScaleModule(_m18, [0.0] * 20, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 21, dtype=torch.float64)
        _m8 = ResidualCoefScaleModule(_m9, [0.0] * 19, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m8, _m16, _m17], [[], [0] * 19, [0] * 20, [0] * 20], 21, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 21
