"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE01Model
  model = StE01Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import CombinedASTModule, GeneralResidualModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule

class StE01Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e01_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 1)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m2 = VectorSumModule([_m3, _m6])
        _m1 = CombinedASTModule([_m2], [('scalar_at', 0, 1)], 2)
        _m0 = GeneralResidualModule([_m1, _m7], [[], [0] * 1], 2, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
