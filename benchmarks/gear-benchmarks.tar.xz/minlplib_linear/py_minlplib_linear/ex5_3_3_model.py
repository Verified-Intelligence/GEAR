"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex533Model
  model = Ex533Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex533Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex5_3_3_model_state.pt'

        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 3)
        _m12 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m14 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 3)
        _m17 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 3)
        _m20 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 3)
        _m22 = SharedLinearFormModule([0] * 4, [[0.0] * 4 for _ in range(32)], [0.0] * 32, dtype=torch.float64)
        _m26 = ConstantVectorModule([0.0] * 188, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 188)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 188)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 69, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m13, 'add')
        _m24 = VectorBinaryOpModule(_m25, _m28, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m16, 'add')
        _m23 = ResidualCoefScaleModule(_m24, [0.0] * 188, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m19, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'mul')
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 3, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m22, _m23], [[], [0] * 3, [0] * 32, [0] * 188], 69, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 69
