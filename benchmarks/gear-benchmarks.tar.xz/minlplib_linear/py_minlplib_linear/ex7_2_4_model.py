"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex724Model
  model = Ex724Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex724Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex7_2_4_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 2)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 2)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 2)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 2)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 2)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 2)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 2)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 2)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m64 = ResidualCoefScaleModule(_m65, [0.0] * 2, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m11, 'pow')
        _m17 = VectorBinaryOpModule(_m18, _m21, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'pow')
        _m31 = VectorBinaryOpModule(_m32, _m35, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m55, 'pow')
        _m57 = VectorBinaryOpModule(_m58, _m61, 'div')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'div')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m36 = ResidualCoefScaleModule(_m37, [0.0] * 2, dtype=torch.float64)
        _m47 = VectorBinaryOpModule(_m48, _m51, 'mul')
        _m56 = ResidualCoefScaleModule(_m57, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m12 = ResidualCoefScaleModule(_m13, [0.0] * 1, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m31, 'div')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'div')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 5, dtype=torch.float64)
        _m22 = ResidualCoefScaleModule(_m23, [0.0] * 2, dtype=torch.float64)
        _m44 = ResidualCoefScaleModule(_m45, [0.0] * 2, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m12, _m22, _m36, _m44, _m56, _m64, _m66], [[], [0] * 1, [0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 3], 5, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
