"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex524Model
  model = Ex524Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex524Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex5_2_4_model_state.pt'

        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 2)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 2)
        _m12 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 4)
        _m21 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m23 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 4)
        _m26 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 4)
        _m29 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 4)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 4, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m9, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'add')
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 2, dtype=torch.float64)
        _m19 = VectorBinaryOpModule(_m20, _m25, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m28, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m18, 'mul')
        _m13 = ResidualCoefScaleModule(_m14, [0.0] * 4, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m12, _m13], [[], [0] * 2, [0] * 3, [0] * 4], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
