"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex626Model
  model = Ex626Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex626Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_6_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(8)], [0.0] * 8, dtype=torch.float64)
        _m3 = LastDimSliceModule(3, 4)
        _m6 = LastDimSliceModule(7, 8)
        _m7 = LastDimSliceModule(5, 6)
        _m10 = LastDimSliceModule(9, 10)
        _m11 = LastDimSliceModule(9, 10)
        _m15 = VariableVectorGatherModule([0] * 12)
        _m17 = ConstantVectorModule([0.0] * 12, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 12)
        _m23 = VariableVectorGatherModule([0] * 3)
        _m25 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 3)
        _m31 = VariableVectorGatherModule([0] * 3)
        _m33 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 3)
        _m37 = VariableVectorGatherModule([0] * 1)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = LastDimSliceModule(8, 9)
        _m43 = VariableVectorGatherModule([0] * 1)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = LastDimSliceModule(10, 11)
        _m49 = VariableVectorGatherModule([0] * 1)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = LastDimSliceModule(4, 5)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m18 = VectorUnaryOpModule(_m19, 'log')
        _m26 = VectorUnaryOpModule(_m27, 'log')
        _m34 = VectorUnaryOpModule(_m35, 'log')
        _m40 = VectorUnaryOpModule(_m41, 'log')
        _m46 = VectorUnaryOpModule(_m47, 'log')
        _m52 = VectorUnaryOpModule(_m53, 'log')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m11, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m13 = VectorScaleModule(_m14, 1, dtype=torch.float64)
        _m21 = VectorScaleModule(_m22, 1, dtype=torch.float64)
        _m29 = VectorScaleModule(_m30, 1, dtype=torch.float64)
        _m12 = VectorReduceModule(_m13, 'sum')
        _m20 = VectorReduceModule(_m21, 'sum')
        _m28 = VectorReduceModule(_m29, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m8, _m12, _m20, _m28, _m36, _m42, _m48])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
