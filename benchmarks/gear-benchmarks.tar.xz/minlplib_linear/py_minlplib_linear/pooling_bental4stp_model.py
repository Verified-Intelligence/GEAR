"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import PoolingBental4stpModel
  model = PoolingBental4stpModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class PoolingBental4stpModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'pooling_bental4stp_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 24, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 24)
        _m8 = ConstantVectorModule([0.0] * 24, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 24)
        _m10 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(25)], [0.0] * 25, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 24, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 24, 25, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10], [[], [0] * 25], 25, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 25
