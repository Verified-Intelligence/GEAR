"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Polygon25Model
  model = Polygon25Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import CombinedASTModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class Polygon25Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'polygon25_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 24)
        _m7 = SharedLinearFormModule([0] * 25, [[0.0] * 25 for _ in range(24)], [0.0] * 24, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 24)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 300)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 300)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 300)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 300)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 300)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 300)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorUnaryOpModule(_m7, 'sin')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m8, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m22, 'add')
        _m31 = VectorBinaryOpModule(_m32, _m35, 'pow')
        _m36 = VectorBinaryOpModule(_m37, _m40, 'pow')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m17 = VectorUnaryOpModule(_m18, 'cos')
        _m2 = VectorScaleModule(_m3, -0.5, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m14 = VectorBinaryOpModule(_m15, _m25, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m28, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m31, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m36, 'add')
        _m0 = CombinedASTModule([_m1, _m9], [('scalar_at', 0, 0), ('vector_pick', 1, 0, 1), ('vector_pick', 1, 1, 2), ('vector_pick', 1, 2, 3), ('vector_pick', 1, 3, 4), ('vector_pick', 1, 4, 5), ('vector_pick', 1, 5, 6), ('vector_pick', 1, 6, 7), ('vector_pick', 1, 7, 8), ('vector_pick', 1, 8, 9), ('vector_pick', 1, 9, 10), ('vector_pick', 1, 10, 11), ('vector_pick', 1, 11, 12), ('vector_pick', 1, 12, 13), ('vector_pick', 1, 13, 14), ('vector_pick', 1, 14, 15), ('vector_pick', 1, 15, 16), ('vector_pick', 1, 16, 17), ('vector_pick', 1, 17, 18), ('vector_pick', 1, 18, 19), ('vector_pick', 1, 19, 20), ('vector_pick', 1, 20, 21), ('vector_pick', 1, 21, 22), ('vector_pick', 1, 22, 23), ('vector_pick', 1, 23, 24), ('vector_pick', 1, 24, 25), ('vector_pick', 1, 25, 26), ('vector_pick', 1, 26, 27), ('vector_pick', 1, 27, 28), ('vector_pick', 1, 28, 29), ('vector_pick', 1, 29, 30), ('vector_pick', 1, 30, 31), ('vector_pick', 1, 31, 32), ('vector_pick', 1, 32, 33), ('vector_pick', 1, 33, 34), ('vector_pick', 1, 34, 35), ('vector_pick', 1, 35, 36), ('vector_pick', 1, 36, 37), ('vector_pick', 1, 37, 38), ('vector_pick', 1, 38, 39), ('vector_pick', 1, 39, 40), ('vector_pick', 1, 40, 41), ('vector_pick', 1, 41, 42), ('vector_pick', 1, 42, 43), ('vector_pick', 1, 43, 44), ('vector_pick', 1, 44, 45), ('vector_pick', 1, 45, 46), ('vector_pick', 1, 46, 47), ('vector_pick', 1, 47, 48), ('vector_pick', 1, 48, 49), ('vector_pick', 1, 49, 50), ('vector_pick', 1, 50, 51), ('vector_pick', 1, 51, 52), ('vector_pick', 1, 52, 53), ('vector_pick', 1, 53, 54), ('vector_pick', 1, 54, 55), ('vector_pick', 1, 55, 56), ('vector_pick', 1, 56, 57), ('vector_pick', 1, 57, 58), ('vector_pick', 1, 58, 59), ('vector_pick', 1, 59, 60), ('vector_pick', 1, 60, 61), ('vector_pick', 1, 61, 62), ('vector_pick', 1, 62, 63), ('vector_pick', 1, 63, 64), ('vector_pick', 1, 64, 65), ('vector_pick', 1, 65, 66), ('vector_pick', 1, 66, 67), ('vector_pick', 1, 67, 68), ('vector_pick', 1, 68, 69), ('vector_pick', 1, 69, 70), ('vector_pick', 1, 70, 71), ('vector_pick', 1, 71, 72), ('vector_pick', 1, 72, 73), ('vector_pick', 1, 73, 74), ('vector_pick', 1, 74, 75), ('vector_pick', 1, 75, 76), ('vector_pick', 1, 76, 77), ('vector_pick', 1, 77, 78), ('vector_pick', 1, 78, 79), ('vector_pick', 1, 79, 80), ('vector_pick', 1, 80, 81), ('vector_pick', 1, 81, 82), ('vector_pick', 1, 82, 83), ('vector_pick', 1, 83, 84), ('vector_pick', 1, 84, 85), ('vector_pick', 1, 85, 86), ('vector_pick', 1, 86, 87), ('vector_pick', 1, 87, 88), ('vector_pick', 1, 88, 89), ('vector_pick', 1, 89, 90), ('vector_pick', 1, 90, 91), ('vector_pick', 1, 91, 92), ('vector_pick', 1, 92, 93), ('vector_pick', 1, 93, 94), ('vector_pick', 1, 94, 95), ('vector_pick', 1, 95, 96), ('vector_pick', 1, 96, 97), ('vector_pick', 1, 97, 98), ('vector_pick', 1, 98, 99), ('vector_pick', 1, 99, 100), ('vector_pick', 1, 100, 101), ('vector_pick', 1, 101, 102), ('vector_pick', 1, 102, 103), ('vector_pick', 1, 103, 104), ('vector_pick', 1, 104, 105), ('vector_pick', 1, 105, 106), ('vector_pick', 1, 106, 107), ('vector_pick', 1, 107, 108), ('vector_pick', 1, 108, 109), ('vector_pick', 1, 109, 110), ('vector_pick', 1, 110, 111), ('vector_pick', 1, 111, 112), ('vector_pick', 1, 112, 113), ('vector_pick', 1, 113, 114), ('vector_pick', 1, 114, 115), ('vector_pick', 1, 115, 116), ('vector_pick', 1, 116, 117), ('vector_pick', 1, 117, 118), ('vector_pick', 1, 118, 119), ('vector_pick', 1, 119, 120), ('vector_pick', 1, 120, 121), ('vector_pick', 1, 121, 122), ('vector_pick', 1, 122, 123), ('vector_pick', 1, 123, 124), ('vector_pick', 1, 124, 125), ('vector_pick', 1, 125, 126), ('vector_pick', 1, 126, 127), ('vector_pick', 1, 127, 128), ('vector_pick', 1, 128, 129), ('vector_pick', 1, 129, 130), ('vector_pick', 1, 130, 131), ('vector_pick', 1, 131, 132), ('vector_pick', 1, 132, 133), ('vector_pick', 1, 133, 134), ('vector_pick', 1, 134, 135), ('vector_pick', 1, 135, 136), ('vector_pick', 1, 136, 137), ('vector_pick', 1, 137, 138), ('vector_pick', 1, 138, 139), ('vector_pick', 1, 139, 140), ('vector_pick', 1, 140, 141), ('vector_pick', 1, 141, 142), ('vector_pick', 1, 142, 143), ('vector_pick', 1, 143, 144), ('vector_pick', 1, 144, 145), ('vector_pick', 1, 145, 146), ('vector_pick', 1, 146, 147), ('vector_pick', 1, 147, 148), ('vector_pick', 1, 148, 149), ('vector_pick', 1, 149, 150), ('vector_pick', 1, 150, 151), ('vector_pick', 1, 151, 152), ('vector_pick', 1, 152, 153), ('vector_pick', 1, 153, 154), ('vector_pick', 1, 154, 155), ('vector_pick', 1, 155, 156), ('vector_pick', 1, 156, 157), ('vector_pick', 1, 157, 158), ('vector_pick', 1, 158, 159), ('vector_pick', 1, 159, 160), ('vector_pick', 1, 160, 161), ('vector_pick', 1, 161, 162), ('vector_pick', 1, 162, 163), ('vector_pick', 1, 163, 164), ('vector_pick', 1, 164, 165), ('vector_pick', 1, 165, 166), ('vector_pick', 1, 166, 167), ('vector_pick', 1, 167, 168), ('vector_pick', 1, 168, 169), ('vector_pick', 1, 169, 170), ('vector_pick', 1, 170, 171), ('vector_pick', 1, 171, 172), ('vector_pick', 1, 172, 173), ('vector_pick', 1, 173, 174), ('vector_pick', 1, 174, 175), ('vector_pick', 1, 175, 176), ('vector_pick', 1, 176, 177), ('vector_pick', 1, 177, 178), ('vector_pick', 1, 178, 179), ('vector_pick', 1, 179, 180), ('vector_pick', 1, 180, 181), ('vector_pick', 1, 181, 182), ('vector_pick', 1, 182, 183), ('vector_pick', 1, 183, 184), ('vector_pick', 1, 184, 185), ('vector_pick', 1, 185, 186), ('vector_pick', 1, 186, 187), ('vector_pick', 1, 187, 188), ('vector_pick', 1, 188, 189), ('vector_pick', 1, 189, 190), ('vector_pick', 1, 190, 191), ('vector_pick', 1, 191, 192), ('vector_pick', 1, 192, 193), ('vector_pick', 1, 193, 194), ('vector_pick', 1, 194, 195), ('vector_pick', 1, 195, 196), ('vector_pick', 1, 196, 197), ('vector_pick', 1, 197, 198), ('vector_pick', 1, 198, 199), ('vector_pick', 1, 199, 200), ('vector_pick', 1, 200, 201), ('vector_pick', 1, 201, 202), ('vector_pick', 1, 202, 203), ('vector_pick', 1, 203, 204), ('vector_pick', 1, 204, 205), ('vector_pick', 1, 205, 206), ('vector_pick', 1, 206, 207), ('vector_pick', 1, 207, 208), ('vector_pick', 1, 208, 209), ('vector_pick', 1, 209, 210), ('vector_pick', 1, 210, 211), ('vector_pick', 1, 211, 212), ('vector_pick', 1, 212, 213), ('vector_pick', 1, 213, 214), ('vector_pick', 1, 214, 215), ('vector_pick', 1, 215, 216), ('vector_pick', 1, 216, 217), ('vector_pick', 1, 217, 218), ('vector_pick', 1, 218, 219), ('vector_pick', 1, 219, 220), ('vector_pick', 1, 220, 221), ('vector_pick', 1, 221, 222), ('vector_pick', 1, 222, 223), ('vector_pick', 1, 223, 224), ('vector_pick', 1, 224, 225), ('vector_pick', 1, 225, 226), ('vector_pick', 1, 226, 227), ('vector_pick', 1, 227, 228), ('vector_pick', 1, 228, 229), ('vector_pick', 1, 229, 230), ('vector_pick', 1, 230, 231), ('vector_pick', 1, 231, 232), ('vector_pick', 1, 232, 233), ('vector_pick', 1, 233, 234), ('vector_pick', 1, 234, 235), ('vector_pick', 1, 235, 236), ('vector_pick', 1, 236, 237), ('vector_pick', 1, 237, 238), ('vector_pick', 1, 238, 239), ('vector_pick', 1, 239, 240), ('vector_pick', 1, 240, 241), ('vector_pick', 1, 241, 242), ('vector_pick', 1, 242, 243), ('vector_pick', 1, 243, 244), ('vector_pick', 1, 244, 245), ('vector_pick', 1, 245, 246), ('vector_pick', 1, 246, 247), ('vector_pick', 1, 247, 248), ('vector_pick', 1, 248, 249), ('vector_pick', 1, 249, 250), ('vector_pick', 1, 250, 251), ('vector_pick', 1, 251, 252), ('vector_pick', 1, 252, 253), ('vector_pick', 1, 253, 254), ('vector_pick', 1, 254, 255), ('vector_pick', 1, 255, 256), ('vector_pick', 1, 256, 257), ('vector_pick', 1, 257, 258), ('vector_pick', 1, 258, 259), ('vector_pick', 1, 259, 260), ('vector_pick', 1, 260, 261), ('vector_pick', 1, 261, 262), ('vector_pick', 1, 262, 263), ('vector_pick', 1, 263, 264), ('vector_pick', 1, 264, 265), ('vector_pick', 1, 265, 266), ('vector_pick', 1, 266, 267), ('vector_pick', 1, 267, 268), ('vector_pick', 1, 268, 269), ('vector_pick', 1, 269, 270), ('vector_pick', 1, 270, 271), ('vector_pick', 1, 271, 272), ('vector_pick', 1, 272, 273), ('vector_pick', 1, 273, 274), ('vector_pick', 1, 274, 275), ('vector_pick', 1, 275, 276), ('vector_pick', 1, 276, 277), ('vector_pick', 1, 277, 278), ('vector_pick', 1, 278, 279), ('vector_pick', 1, 279, 280), ('vector_pick', 1, 280, 281), ('vector_pick', 1, 281, 282), ('vector_pick', 1, 282, 283), ('vector_pick', 1, 283, 284), ('vector_pick', 1, 284, 285), ('vector_pick', 1, 285, 286), ('vector_pick', 1, 286, 287), ('vector_pick', 1, 287, 288), ('vector_pick', 1, 288, 289), ('vector_pick', 1, 289, 290), ('vector_pick', 1, 290, 291), ('vector_pick', 1, 291, 292), ('vector_pick', 1, 292, 293), ('vector_pick', 1, 293, 294), ('vector_pick', 1, 294, 295), ('vector_pick', 1, 295, 296), ('vector_pick', 1, 296, 297), ('vector_pick', 1, 297, 298), ('vector_pick', 1, 298, 299), ('vector_pick', 1, 299, 300)], 301)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 301
