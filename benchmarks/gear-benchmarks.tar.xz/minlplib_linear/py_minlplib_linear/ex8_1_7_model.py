"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex817Model
  model = Ex817Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex817Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_1_7_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 2)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 2)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m48 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 4)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 4)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 4)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m46 = ResidualCoefScaleModule(_m47, [0.0] * 2, dtype=torch.float64)
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'add')
        _m22 = VectorBinaryOpModule(_m23, _m26, 'add')
        _m32 = VectorBinaryOpModule(_m33, _m36, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m45, 'pow')
        _m50 = VectorBinaryOpModule(_m51, _m54, 'pow')
        _m56 = VectorBinaryOpModule(_m57, _m60, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m19, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m29, 'pow')
        _m31 = VectorBinaryOpModule(_m32, _m39, 'pow')
        _m40 = ResidualCoefScaleModule(_m41, [0.0] * 2, dtype=torch.float64)
        _m49 = ResidualCoefScaleModule(_m50, [0.0] * 4, dtype=torch.float64)
        _m55 = ResidualCoefScaleModule(_m56, [0.0] * 4, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m10 = ResidualCoefScaleModule(_m11, [0.0] * 1, dtype=torch.float64)
        _m20 = ResidualCoefScaleModule(_m21, [0.0] * 1, dtype=torch.float64)
        _m30 = ResidualCoefScaleModule(_m31, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 7, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m20, _m30, _m40, _m46, _m48, _m49, _m55], [[], [0] * 1, [0] * 1, [0] * 2, [0] * 2, [0] * 2, [0] * 4, [0] * 4, [0] * 4], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
