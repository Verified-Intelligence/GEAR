"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex846Model
  model = Ex846Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex846Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_4_6_model_state.pt'

        _m6 = ConstantVectorModule([0.0] * 8, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 8)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 8)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(16)], [0.0] * 16, dtype=torch.float64)
        _m19 = ConstantVectorModule([0.0] * 48, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 48)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 48)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m17 = VectorUnaryOpModule(_m18, 'exp')
        _m4 = VectorBinaryOpModule(_m5, _m10, 'div')
        _m16 = VectorBinaryOpModule(_m17, _m21, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'pow')
        _m15 = ResidualCoefScaleModule(_m16, [0.0] * 48, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 8, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 8, 17, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m15], [[], [0] * 16, [0] * 48], 17, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 17
