"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE03Model
  model = StE03Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE03Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e03_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 2)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 2)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 2)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 2)
        _m33 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 6)
        _m36 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 6)
        _m38 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(8)], [0.0] * 8, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m24, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m35, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m12 = ResidualCoefScaleModule(_m13, [0.0] * 2, dtype=torch.float64)
        _m19 = VectorBinaryOpModule(_m20, _m27, 'mul')
        _m30 = ResidualCoefScaleModule(_m31, [0.0] * 6, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m18 = ResidualCoefScaleModule(_m19, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 8, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m12, _m18, _m30, _m38], [[], [0] * 2, [0] * 2, [0] * 6, [0] * 8], 8, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 8
