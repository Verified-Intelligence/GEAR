"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex845Model
  model = Ex845Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex845Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_4_5_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 11, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 11)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = SharedLinearFormModule([0] * 11, [[0.0] * 11 for _ in range(22)], [0.0] * 22, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 22)
        _m18 = ConstantVectorModule([0.0] * 22, dtype=torch.float64)
        _m20 = ConstantVectorModule([0.0] * 22, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 22)
        _m24 = ConstantVectorModule([0.0] * 22, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 22)
        _m29 = ConstantVectorModule([0.0] * 22, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 22)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m28, 'add')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 11, dtype=torch.float64)
        _m12 = VectorBinaryOpModule(_m13, _m22, 'div')
        _m1 = LiftCompactToFullModule(_m2, [0] * 11, 23, dtype=torch.float64)
        _m11 = ResidualCoefScaleModule(_m12, [0.0] * 22, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m11], [[], [0] * 22, [0] * 22], 23, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 23
