"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Waterund01Model
  model = Waterund01Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Waterund01Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'waterund01_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 6)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 6)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 6)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 6)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 6)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 6)
        _m27 = ConstantVectorModule([0.0] * 12, dtype=torch.float64)
        _m28 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(15)], [0.0] * 15, dtype=torch.float64)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 54)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 54)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = ResidualCoefScaleModule(_m27, [0.0] * 12, dtype=torch.float64)
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'add')
        _m30 = VectorBinaryOpModule(_m31, _m34, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m23, 'mul')
        _m29 = ResidualCoefScaleModule(_m30, [0.0] * 54, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 6, dtype=torch.float64)
        _m14 = ResidualCoefScaleModule(_m15, [0.0] * 6, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 6, 27, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m26, _m28, _m29], [[], [0] * 6, [0] * 12, [0] * 15, [0] * 54], 27, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 27
