"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE16Model
  model = StE16Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE16Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e16_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 1)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 1)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 1)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 1)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = VariableVectorGatherModule([0] * 1)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m68 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m69 = VariableVectorGatherModule([0] * 4)
        _m72 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = VariableVectorGatherModule([0] * 4)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 4)
        _m78 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m82 = ConstantVectorModule([0.0] * 8, dtype=torch.float64)
        _m83 = VariableVectorGatherModule([0] * 8)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m86 = VariableVectorGatherModule([0] * 8)
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m59 = VectorBinaryOpModule(_m60, _m61, 'mul')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m77 = ResidualCoefScaleModule(_m78, [0.0] * 4, dtype=torch.float64)
        _m81 = VectorBinaryOpModule(_m82, _m83, 'mul')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'add')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'add')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'add')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'add')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'add')
        _m70 = VectorBinaryOpModule(_m71, _m74, 'add')
        _m80 = VectorBinaryOpModule(_m81, _m84, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m27, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m45, 'add')
        _m51 = VectorBinaryOpModule(_m52, _m57, 'mul')
        _m66 = VectorBinaryOpModule(_m67, _m70, 'mul')
        _m79 = ResidualCoefScaleModule(_m80, [0.0] * 8, dtype=torch.float64)
        _m20 = VectorBinaryOpModule(_m21, _m32, 'pow')
        _m50 = VectorBinaryOpModule(_m51, _m62, 'pow')
        _m65 = ResidualCoefScaleModule(_m66, [0.0] * 4, dtype=torch.float64)
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m18, 'add')
        _m38 = VectorBinaryOpModule(_m39, _m48, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'div')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'add')
        _m35 = VectorBinaryOpModule(_m36, _m63, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'div')
        _m34 = ResidualCoefScaleModule(_m35, [0.0] * 1, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m33, 'pow')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 9, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m34, _m64, _m65, _m77, _m79], [[], [0] * 1, [0] * 4, [0] * 4, [0] * 4, [0] * 8], 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
