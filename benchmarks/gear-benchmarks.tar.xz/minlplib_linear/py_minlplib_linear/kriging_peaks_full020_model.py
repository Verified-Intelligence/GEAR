"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import KrigingPeaksFull020Model
  model = KrigingPeaksFull020Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class KrigingPeaksFull020Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'kriging_peaks_full020_model_state.pt'

        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 40)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 40)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 40)
        _m28 = ConstantVectorModule([0.0] * 80, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 80)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 81)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m7 = VectorUnaryOpModule(_m8, 'sqrt')
        _m18 = VectorUnaryOpModule(_m19, 'sqrt')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'add')
        _m33 = ResidualCoefScaleModule(_m34, [0.0] * 81, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m32, 'pow')
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m15 = VectorBinaryOpModule(_m16, _m22, 'add')
        _m25 = ResidualCoefScaleModule(_m26, [0.0] * 80, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 40, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 40, 81, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m25, _m33], [[], [0] * 80, [0] * 81], 81, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 81
