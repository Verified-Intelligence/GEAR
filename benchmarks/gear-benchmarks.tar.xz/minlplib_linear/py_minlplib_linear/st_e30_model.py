"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE30Model
  model = StE30Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE30Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e30_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 4)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = SharedLinearFormModule([0] * 7, [[0.0] * 7 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m14 = ConstantVectorModule([0.0] * 12, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 12)
        _m17 = ConstantVectorModule([0.0] * 12, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 12)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 2, 11, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m9, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'mul')
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 4, dtype=torch.float64)
        _m11 = ResidualCoefScaleModule(_m12, [0.0] * 12, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m10, _m11], [[], [0] * 4, [0] * 9, [0] * 12], 11, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 11
