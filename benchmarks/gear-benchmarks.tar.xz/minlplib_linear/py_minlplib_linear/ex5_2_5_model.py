"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex525Model
  model = Ex525Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex525Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex5_2_5_model_state.pt'

        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = SharedLinearFormModule([0] * 5, [[0.0] * 5 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 15)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 15)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 45)
        _m22 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m24 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 45)
        _m27 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 45)
        _m30 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 45)
        _m33 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 45)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 12, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m10, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'add')
        _m5 = ResidualCoefScaleModule(_m6, [0.0] * 15, dtype=torch.float64)
        _m20 = VectorBinaryOpModule(_m21, _m26, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m29, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m32, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m18, 'mul')
        _m13 = ResidualCoefScaleModule(_m14, [0.0] * 45, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m5, _m13], [[], [0] * 7, [0] * 15, [0] * 45], 12, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 12
