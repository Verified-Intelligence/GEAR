"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex544Model
  model = Ex544Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex544Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex5_4_4_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 3)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 3)
        _m16 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 3)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 3)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(6)], [0.0] * 6, dtype=torch.float64)
        _m24 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m28 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 30)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 30)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m23 = ResidualCoefScaleModule(_m24, [0.0] * 6, dtype=torch.float64)
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m18, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m14, 'add')
        _m25 = ResidualCoefScaleModule(_m26, [0.0] * 30, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'div')
        _m3 = VectorBinaryOpModule(_m4, _m21, 'pow')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 3, 13, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m22, _m23, _m25], [[], [0] * 6, [0] * 6, [0] * 30], 13, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 13
