"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import AlkylModel
  model = AlkylModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class AlkylModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'alkyl_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 2)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 2)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 2)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 2)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m36 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(11)], [0.0] * 11, dtype=torch.float64)
        _m40 = ConstantVectorModule([0.0] * 13, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 13)
        _m43 = ConstantVectorModule([0.0] * 13, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 13)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m33, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m42, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m29, 'add')
        _m37 = ResidualCoefScaleModule(_m38, [0.0] * 13, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m18 = ResidualCoefScaleModule(_m19, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 2, 13, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m18, _m36, _m37], [[], [0] * 2, [0] * 11, [0] * 13], 13, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 13
