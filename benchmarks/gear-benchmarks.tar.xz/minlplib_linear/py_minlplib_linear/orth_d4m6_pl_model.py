"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import OrthD4m6PlModel
  model = OrthD4m6PlModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule

class OrthD4m6PlModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'orth_d4m6_pl_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 12, dtype=torch.float64)
        _m8 = ConstantVectorModule([0.0] * 40, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 40)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 40)
        _m14 = ConstantVectorModule([0.0] * 40, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 40)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 41)
        _m23 = ConstantVectorModule([0.0] * 90, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 90)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 90)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 120)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 120)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 12, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 12, 83, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m10, 'mul')
        _m16 = ResidualCoefScaleModule(_m17, [0.0] * 41, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m25, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m13, 'mul')
        _m20 = ResidualCoefScaleModule(_m21, [0.0] * 90, dtype=torch.float64)
        _m29 = VectorBinaryOpModule(_m30, _m33, 'mul')
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 40, dtype=torch.float64)
        _m28 = ResidualCoefScaleModule(_m29, [0.0] * 120, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m16, _m20, _m28], [[], [0] * 40, [0] * 41, [0] * 90, [0] * 120], 83, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 83
