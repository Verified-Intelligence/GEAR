"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex627Model
  model = Ex627Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex627Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_7_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 9 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m3 = LastDimSliceModule(15, 16)
        _m6 = LastDimSliceModule(12, 13)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m20 = LastDimSliceModule(11, 12)
        _m21 = LastDimSliceModule(11, 12)
        _m24 = LastDimSliceModule(14, 15)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m38 = LastDimSliceModule(13, 14)
        _m39 = LastDimSliceModule(13, 14)
        _m42 = LastDimSliceModule(10, 11)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 1)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 1)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 1)
        _m56 = LastDimSliceModule(9, 10)
        _m57 = LastDimSliceModule(9, 10)
        _m61 = VariableVectorGatherModule([0] * 36)
        _m63 = ConstantVectorModule([0.0] * 36, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 36)
        _m69 = VariableVectorGatherModule([0] * 3)
        _m71 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m73 = VariableVectorGatherModule([0] * 3)
        _m77 = VariableVectorGatherModule([0] * 3)
        _m79 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 3)
        _m85 = VariableVectorGatherModule([0] * 9)
        _m87 = ConstantVectorModule([0.0] * 9, dtype=torch.float64)
        _m89 = SharedLinearFormModule([0] * 9, [[0.0] * 9 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m93 = VariableVectorGatherModule([0] * 3)
        _m95 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m97 = VariableVectorGatherModule([0] * 3)
        _m101 = VariableVectorGatherModule([0] * 3)
        _m103 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m105 = VariableVectorGatherModule([0] * 3)
        _m109 = VariableVectorGatherModule([0] * 3)
        _m111 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m113 = VariableVectorGatherModule([0] * 3)
        _m117 = VariableVectorGatherModule([0] * 3)
        _m119 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m121 = VariableVectorGatherModule([0] * 3)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m19 = VectorUnaryOpModule(_m20, 'log')
        _m23 = VectorUnaryOpModule(_m24, 'log')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m37 = VectorUnaryOpModule(_m38, 'log')
        _m41 = VectorUnaryOpModule(_m42, 'log')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m55 = VectorUnaryOpModule(_m56, 'log')
        _m64 = VectorUnaryOpModule(_m65, 'log')
        _m72 = VectorUnaryOpModule(_m73, 'log')
        _m80 = VectorUnaryOpModule(_m81, 'log')
        _m88 = VectorUnaryOpModule(_m89, 'log')
        _m96 = VectorUnaryOpModule(_m97, 'log')
        _m104 = VectorUnaryOpModule(_m105, 'log')
        _m112 = VectorUnaryOpModule(_m113, 'log')
        _m120 = VectorUnaryOpModule(_m121, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m12, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m21, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m39, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m48, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m57, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m94 = VectorBinaryOpModule(_m95, _m96, 'mul')
        _m102 = VectorBinaryOpModule(_m103, _m104, 'mul')
        _m110 = VectorBinaryOpModule(_m111, _m112, 'mul')
        _m118 = VectorBinaryOpModule(_m119, _m120, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m15, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m33, 'add')
        _m43 = VectorBinaryOpModule(_m44, _m51, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'mul')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'mul')
        _m100 = VectorBinaryOpModule(_m101, _m102, 'mul')
        _m108 = VectorBinaryOpModule(_m109, _m110, 'mul')
        _m116 = VectorBinaryOpModule(_m117, _m118, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m25, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m43, 'mul')
        _m59 = VectorScaleModule(_m60, 1, dtype=torch.float64)
        _m67 = VectorScaleModule(_m68, 1, dtype=torch.float64)
        _m75 = VectorScaleModule(_m76, 1, dtype=torch.float64)
        _m83 = VectorScaleModule(_m84, 1, dtype=torch.float64)
        _m91 = VectorScaleModule(_m92, 1, dtype=torch.float64)
        _m99 = VectorScaleModule(_m100, 1, dtype=torch.float64)
        _m107 = VectorScaleModule(_m108, 1, dtype=torch.float64)
        _m115 = VectorScaleModule(_m116, 1, dtype=torch.float64)
        _m58 = VectorReduceModule(_m59, 'sum')
        _m66 = VectorReduceModule(_m67, 'sum')
        _m74 = VectorReduceModule(_m75, 'sum')
        _m82 = VectorReduceModule(_m83, 'sum')
        _m90 = VectorReduceModule(_m91, 'sum')
        _m98 = VectorReduceModule(_m99, 'sum')
        _m106 = VectorReduceModule(_m107, 'sum')
        _m114 = VectorReduceModule(_m115, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m18, _m22, _m36, _m40, _m54, _m58, _m66, _m74, _m82, _m90, _m98, _m106, _m114])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
