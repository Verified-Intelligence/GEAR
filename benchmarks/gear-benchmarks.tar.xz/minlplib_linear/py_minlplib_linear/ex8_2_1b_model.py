"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex821bModel
  model = Ex821bModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex821bModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_2_1b_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 50, [[0.0] * 50 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 3)
        _m11 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 4)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 4)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 50)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 50)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 30, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = ResidualCoefScaleModule(_m20, [0.0] * 25, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m15 = ResidualCoefScaleModule(_m16, [0.0] * 4, dtype=torch.float64)
        _m22 = VectorBinaryOpModule(_m23, _m26, 'mul')
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 3, dtype=torch.float64)
        _m9 = VectorUnaryOpModule(_m10, 'exp')
        _m21 = ResidualCoefScaleModule(_m22, [0.0] * 50, dtype=torch.float64)
        _m8 = ResidualCoefScaleModule(_m9, [0.0] * 4, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3, _m8, _m15, _m19, _m21], [[], [0] * 3, [0] * 4, [0] * 4, [0] * 25, [0] * 50], 30, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 30
