"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import KallDiffcircles8Model
  model = KallDiffcircles8Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class KallDiffcircles8Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'kall_diffcircles_8_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m8 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 2)
        _m10 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m12 = ConstantVectorModule([0.0] * 28, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 56)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 56)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 56)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 56)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m11 = ResidualCoefScaleModule(_m12, [0.0] * 28, dtype=torch.float64)
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m22 = VectorBinaryOpModule(_m23, _m26, 'add')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m14 = VectorBinaryOpModule(_m15, _m22, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 2, 31, dtype=torch.float64)
        _m13 = ResidualCoefScaleModule(_m14, [0.0] * 56, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m11, _m13], [[], [0] * 3, [0] * 28, [0] * 56], 31, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 31
