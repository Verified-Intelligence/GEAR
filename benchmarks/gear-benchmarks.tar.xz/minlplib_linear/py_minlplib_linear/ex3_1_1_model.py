"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex311Model
  model = Ex311Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex311Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex3_1_1_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 5, [[0.0] * 5 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m6 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 5)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 5)
        _m1 = LiftCompactToFullModule(_m2, [0] * 4, 4, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'mul')
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 5, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3], [[], [0] * 5], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
