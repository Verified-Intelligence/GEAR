"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE05Model
  model = StE05Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE05Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e05_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 4)
        _m8 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 4)
        _m12 = SharedLinearFormModule([0] * 5, [[0.0] * 5 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 4, 5, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m12], [[], [0] * 5], 5, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
