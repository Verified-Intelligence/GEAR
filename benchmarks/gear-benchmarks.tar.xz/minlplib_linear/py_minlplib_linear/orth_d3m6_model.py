"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import OrthD3m6Model
  model = OrthD3m6Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class OrthD3m6Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'orth_d3m6_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 18, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 36)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 36)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 36)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(41)], [0.0] * 41, dtype=torch.float64)
        _m25 = ConstantVectorModule([0.0] * 276, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 276)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 276)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 276)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 18, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 18, 65, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m9, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'pow')
        _m23 = VectorBinaryOpModule(_m24, _m27, 'mul')
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 36, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m30, 'mul')
        _m10 = ResidualCoefScaleModule(_m11, [0.0] * 36, dtype=torch.float64)
        _m21 = ResidualCoefScaleModule(_m22, [0.0] * 276, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m10, _m20, _m21], [[], [0] * 36, [0] * 36, [0] * 41, [0] * 276], 65, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 65
