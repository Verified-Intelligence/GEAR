"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex6214Model
  model = Ex6214Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex6214Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_14_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(6)], [0.0] * 6, dtype=torch.float64)
        _m5 = LastDimSliceModule(6, 7)
        _m6 = LastDimSliceModule(6, 7)
        _m9 = LastDimSliceModule(4, 5)
        _m10 = LastDimSliceModule(4, 5)
        _m13 = LastDimSliceModule(9, 10)
        _m14 = LastDimSliceModule(9, 10)
        _m17 = LastDimSliceModule(7, 8)
        _m18 = LastDimSliceModule(7, 8)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m26 = VariableVectorGatherModule([0] * 2)
        _m27 = VariableVectorGatherModule([0] * 2)
        _m30 = VariableVectorGatherModule([0] * 2)
        _m31 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m39 = VariableVectorGatherModule([0] * 2)
        _m40 = VariableVectorGatherModule([0] * 2)
        _m43 = VariableVectorGatherModule([0] * 2)
        _m44 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 4)
        _m50 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 4)
        _m54 = VariableVectorGatherModule([0] * 1)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 1)
        _m60 = LastDimSliceModule(6, 7)
        _m62 = VariableVectorGatherModule([0] * 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = VariableVectorGatherModule([0] * 1)
        _m68 = LastDimSliceModule(4, 5)
        _m70 = VariableVectorGatherModule([0] * 1)
        _m72 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = VariableVectorGatherModule([0] * 1)
        _m76 = LastDimSliceModule(9, 10)
        _m78 = VariableVectorGatherModule([0] * 1)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = VariableVectorGatherModule([0] * 1)
        _m84 = LastDimSliceModule(7, 8)
        _m4 = VectorUnaryOpModule(_m5, 'log')
        _m8 = VectorUnaryOpModule(_m9, 'log')
        _m12 = VectorUnaryOpModule(_m13, 'log')
        _m16 = VectorUnaryOpModule(_m17, 'log')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'div')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'div')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'div')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'div')
        _m51 = VectorUnaryOpModule(_m52, 'log')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'div')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'div')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'div')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'div')
        _m3 = VectorBinaryOpModule(_m4, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m18, 'mul')
        _m24 = VectorUnaryOpModule(_m25, 'log')
        _m28 = VectorUnaryOpModule(_m29, 'log')
        _m37 = VectorUnaryOpModule(_m38, 'log')
        _m41 = VectorUnaryOpModule(_m42, 'log')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m57 = VectorUnaryOpModule(_m58, 'log')
        _m65 = VectorUnaryOpModule(_m66, 'log')
        _m73 = VectorUnaryOpModule(_m74, 'log')
        _m81 = VectorUnaryOpModule(_m82, 'log')
        _m23 = VectorBinaryOpModule(_m24, _m28, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m41, 'add')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'mul')
        _m79 = VectorBinaryOpModule(_m80, _m81, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m46 = VectorScaleModule(_m47, 1, dtype=torch.float64)
        _m53 = VectorBinaryOpModule(_m54, _m55, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m69 = VectorBinaryOpModule(_m70, _m71, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m20 = VectorScaleModule(_m21, 1, dtype=torch.float64)
        _m33 = VectorScaleModule(_m34, 1, dtype=torch.float64)
        _m45 = VectorReduceModule(_m46, 'sum')
        _m19 = VectorReduceModule(_m20, 'sum')
        _m32 = VectorReduceModule(_m33, 'sum')
        _m2 = VectorSumModule([_m3, _m7, _m11, _m15, _m19, _m32, _m45, _m53, _m61, _m69, _m77])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
