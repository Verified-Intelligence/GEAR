"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Prob06Model
  model = Prob06Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Prob06Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'prob06_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 4)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 3, 3, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'pow')
        _m3 = ResidualCoefScaleModule(_m4, [0.0] * 4, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m3], [[], [0] * 4], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
