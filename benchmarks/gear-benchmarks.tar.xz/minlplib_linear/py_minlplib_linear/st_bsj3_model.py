"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StBsj3Model
  model = StBsj3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorSumModule

class StBsj3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_bsj3_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 6 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m3 = LastDimSliceModule(6, 7)
        _m6 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 6)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorReduceModule(_m5, 'sum')
        _m2 = VectorSumModule([_m3, _m4])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
