"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex721Model
  model = Ex721Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex721Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex7_2_1_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 1)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 1)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 2)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 2)
        _m59 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 2)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 2)
        _m67 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m68 = VariableVectorGatherModule([0] * 3)
        _m70 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m71 = VariableVectorGatherModule([0] * 3)
        _m76 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m77 = VariableVectorGatherModule([0] * 3)
        _m79 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m80 = VariableVectorGatherModule([0] * 3)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = VariableVectorGatherModule([0] * 3)
        _m86 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m88 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m89 = VariableVectorGatherModule([0] * 5)
        _m91 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m92 = SharedLinearFormModule([0] * 7, [[0.0] * 7 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m96 = ConstantVectorModule([0.0] * 9, dtype=torch.float64)
        _m97 = VariableVectorGatherModule([0] * 9)
        _m99 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m100 = VariableVectorGatherModule([0] * 9)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'mul')
        _m69 = VectorBinaryOpModule(_m70, _m71, 'mul')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'mul')
        _m81 = VectorBinaryOpModule(_m82, _m83, 'mul')
        _m87 = VectorBinaryOpModule(_m88, _m89, 'mul')
        _m90 = ResidualCoefScaleModule(_m91, [0.0] * 6, dtype=torch.float64)
        _m95 = VectorBinaryOpModule(_m96, _m97, 'mul')
        _m98 = VectorBinaryOpModule(_m99, _m100, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'div')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m26, 'pow')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'div')
        _m47 = VectorBinaryOpModule(_m48, _m51, 'pow')
        _m57 = VectorBinaryOpModule(_m58, _m61, 'div')
        _m65 = VectorBinaryOpModule(_m66, _m69, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m78, 'div')
        _m85 = VectorBinaryOpModule(_m86, _m87, 'div')
        _m94 = VectorBinaryOpModule(_m95, _m98, 'div')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m40, 'div')
        _m46 = ResidualCoefScaleModule(_m47, [0.0] * 2, dtype=torch.float64)
        _m53 = VectorBinaryOpModule(_m54, _m57, 'mul')
        _m64 = ResidualCoefScaleModule(_m65, [0.0] * 3, dtype=torch.float64)
        _m73 = VectorBinaryOpModule(_m74, _m81, 'div')
        _m84 = ResidualCoefScaleModule(_m85, [0.0] * 5, dtype=torch.float64)
        _m93 = ResidualCoefScaleModule(_m94, [0.0] * 9, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m13, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m27, 'div')
        _m31 = VectorBinaryOpModule(_m32, _m43, 'div')
        _m52 = ResidualCoefScaleModule(_m53, [0.0] * 2, dtype=torch.float64)
        _m72 = ResidualCoefScaleModule(_m73, [0.0] * 3, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m18 = ResidualCoefScaleModule(_m19, [0.0] * 1, dtype=torch.float64)
        _m30 = ResidualCoefScaleModule(_m31, [0.0] * 1, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 13, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m18, _m30, _m46, _m52, _m64, _m72, _m84, _m90, _m92, _m93], [[], [0] * 1, [0] * 1, [0] * 2, [0] * 2, [0] * 3, [0] * 3, [0] * 5, [0] * 6, [0] * 7, [0] * 9], 13, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 13
