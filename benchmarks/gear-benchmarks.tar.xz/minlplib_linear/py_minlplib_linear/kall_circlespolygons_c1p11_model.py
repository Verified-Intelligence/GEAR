"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import KallCirclespolygonsC1p11Model
  model = KallCirclespolygonsC1p11Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class KallCirclespolygonsC1p11Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'kall_circlespolygons_c1p11_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 19)
        _m8 = SharedLinearFormModule([0] * 22, [[0.0] * 22 for _ in range(20)], [0.0] * 20, dtype=torch.float64)
        _m12 = ConstantVectorModule([0.0] * 46, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 46)
        _m15 = ConstantVectorModule([0.0] * 46, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 46)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m1 = LiftCompactToFullModule(_m2, [0] * 4, 43, dtype=torch.float64)
        _m4 = ResidualCoefScaleModule(_m5, [0.0] * 19, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m14, 'mul')
        _m9 = ResidualCoefScaleModule(_m10, [0.0] * 46, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m4, _m8, _m9], [[], [0] * 19, [0] * 20, [0] * 46], 43, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 43
