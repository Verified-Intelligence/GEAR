"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Prob09Model
  model = Prob09Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Prob09Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'prob09_model_state.pt'

        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 2)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 2)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m23, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'add')
        _m16 = ResidualCoefScaleModule(_m17, [0.0] * 2, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m15, 'pow')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 2, 3, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m16, _m24], [[], [0] * 2, [0] * 3], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
