"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex6213Model
  model = Ex6213Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Ex6213Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex6_2_13_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 6 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m3 = LastDimSliceModule(10, 11)
        _m6 = LastDimSliceModule(7, 8)
        _m7 = LastDimSliceModule(7, 8)
        _m10 = LastDimSliceModule(9, 10)
        _m11 = LastDimSliceModule(9, 10)
        _m17 = VariableVectorGatherModule([0] * 3)
        _m18 = VariableVectorGatherModule([0] * 3)
        _m19 = VariableVectorGatherModule([0] * 3)
        _m25 = VariableVectorGatherModule([0] * 3)
        _m26 = VariableVectorGatherModule([0] * 3)
        _m27 = VariableVectorGatherModule([0] * 3)
        _m33 = VariableVectorGatherModule([0] * 2)
        _m34 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m39 = VariableVectorGatherModule([0] * 6)
        _m41 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 6)
        _m47 = VariableVectorGatherModule([0] * 6)
        _m49 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 6)
        _m53 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(6)], [0.0] * 6, dtype=torch.float64)
        _m5 = VectorUnaryOpModule(_m6, 'log')
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'div')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'div')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'div')
        _m42 = VectorUnaryOpModule(_m43, 'log')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'div')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m11, 'mul')
        _m15 = VectorUnaryOpModule(_m16, 'log')
        _m23 = VectorUnaryOpModule(_m24, 'log')
        _m31 = VectorUnaryOpModule(_m32, 'log')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m50 = VectorUnaryOpModule(_m51, 'log')
        _m14 = VectorBinaryOpModule(_m15, _m19, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m35, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m13 = VectorScaleModule(_m14, 1, dtype=torch.float64)
        _m21 = VectorScaleModule(_m22, 1, dtype=torch.float64)
        _m29 = VectorScaleModule(_m30, 1, dtype=torch.float64)
        _m37 = VectorScaleModule(_m38, 1, dtype=torch.float64)
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m12 = VectorReduceModule(_m13, 'sum')
        _m20 = VectorReduceModule(_m21, 'sum')
        _m28 = VectorReduceModule(_m29, 'sum')
        _m36 = VectorReduceModule(_m37, 'sum')
        _m45 = VectorScaleModule(_m46, 1, dtype=torch.float64)
        _m44 = VectorReduceModule(_m45, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m8, _m12, _m20, _m28, _m36, _m44])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
