"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Arki0005Model
  model = Arki0005Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Arki0005Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'arki0005_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 672)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 672)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2688)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 2688)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = ConstantVectorModule([0.0] * 3360, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 3360)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 3360)
        _m34 = ConstantVectorModule([0.0] * 3360, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 3360)
        _m39 = ConstantVectorModule([0.0] * 4368, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 4368)
        _m42 = ConstantVectorModule([0.0] * 4368, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 4368)
        _m44 = SharedLinearFormModule([0] * 127, [[0.0] * 127 for _ in range(4704)], [0.0] * 4704, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m33, 'mul')
        _m36 = ResidualCoefScaleModule(_m37, [0.0] * 4368, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m14 = ResidualCoefScaleModule(_m15, [0.0] * 2688, dtype=torch.float64)
        _m24 = ResidualCoefScaleModule(_m25, [0.0] * 3360, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 672, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 672, 4705, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m24, _m36, _m44], [[], [0] * 2688, [0] * 3360, [0] * 4368, [0] * 4704], 4705, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4705
