"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import AlkylationModel
  model = AlkylationModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class AlkylationModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = True

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'alkylation_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 2)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 2)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 2)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 2)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 2)
        _m43 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 2)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 2)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 2)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 2)
        _m63 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m34, 'add')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'add')
        _m53 = VectorBinaryOpModule(_m54, _m57, 'pow')
        _m59 = VectorBinaryOpModule(_m60, _m63, 'pow')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m58 = ResidualCoefScaleModule(_m59, [0.0] * 2, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 9, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'div')
        _m27 = VectorBinaryOpModule(_m28, _m37, 'div')
        _m45 = VectorBinaryOpModule(_m46, _m51, 'add')
        _m10 = ResidualCoefScaleModule(_m11, [0.0] * 2, dtype=torch.float64)
        _m26 = ResidualCoefScaleModule(_m27, [0.0] * 2, dtype=torch.float64)
        _m41 = VectorBinaryOpModule(_m42, _m45, 'mul')
        _m40 = ResidualCoefScaleModule(_m41, [0.0] * 2, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m10, _m26, _m40, _m58, _m64], [[], [0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 9], 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
