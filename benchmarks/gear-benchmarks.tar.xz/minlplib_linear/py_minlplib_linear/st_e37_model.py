"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE37Model
  model = StE37Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class StE37Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e37_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(0, 1)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ConstantVectorModule([0.0] * 10, dtype=torch.float64)
        _m14 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 10)
        _m18 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 10)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m13 = VectorUnaryOpModule(_m14, 'exp')
        _m17 = VectorUnaryOpModule(_m18, 'exp')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m12 = VectorBinaryOpModule(_m13, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m19, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m16, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m20, 'pow')
        _m7 = VectorScaleModule(_m8, 1, dtype=torch.float64)
        _m6 = VectorReduceModule(_m7, 'sum')
        _m0 = VectorSumModule([_m1, _m6])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
