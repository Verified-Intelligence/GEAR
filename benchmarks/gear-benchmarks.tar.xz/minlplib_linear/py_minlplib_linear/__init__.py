"""Generated mod_files package: AMPL .mod models as PyTorch nn.Modules."""

from .alkyl_model import AlkylModel
from .alkylation_model import AlkylationModel
from .arki0005_model import Arki0005Model
from .arki0006_model import Arki0006Model
from .arki0015_model import Arki0015Model
from .eq6_1_model import Eq61Model
from .ex2_1_1_model import Ex211Model
from .ex2_1_5_model import Ex215Model
from .ex2_1_6_model import Ex216Model
from .ex2_1_8_model import Ex218Model
from .ex3_1_1_model import Ex311Model
from .ex3_1_2_model import Ex312Model
from .ex4_1_8_model import Ex418Model
from .ex4_1_9_model import Ex419Model
from .ex5_2_2_case1_model import Ex522Case1Model
from .ex5_2_2_case2_model import Ex522Case2Model
from .ex5_2_2_case3_model import Ex522Case3Model
from .ex5_2_4_model import Ex524Model
from .ex5_2_5_model import Ex525Model
from .ex5_3_2_model import Ex532Model
from .ex5_3_3_model import Ex533Model
from .ex5_4_2_model import Ex542Model
from .ex5_4_3_model import Ex543Model
from .ex5_4_4_model import Ex544Model
from .ex6_2_10_model import Ex6210Model
from .ex6_2_11_model import Ex6211Model
from .ex6_2_12_model import Ex6212Model
from .ex6_2_13_model import Ex6213Model
from .ex6_2_14_model import Ex6214Model
from .ex6_2_5_model import Ex625Model
from .ex6_2_6_model import Ex626Model
from .ex6_2_7_model import Ex627Model
from .ex6_2_8_model import Ex628Model
from .ex6_2_9_model import Ex629Model
from .ex7_2_1_model import Ex721Model
from .ex7_2_2_model import Ex722Model
from .ex7_2_3_model import Ex723Model
from .ex7_2_4_model import Ex724Model
from .ex8_1_7_model import Ex817Model
from .ex8_2_1b_model import Ex821bModel
from .ex8_2_4b_model import Ex824bModel
from .ex8_3_13_model import Ex8313Model
from .ex8_3_2_model import Ex832Model
from .ex8_3_3_model import Ex833Model
from .ex8_3_4_model import Ex834Model
from .ex8_3_5_model import Ex835Model
from .ex8_3_7_model import Ex837Model
from .ex8_3_8_model import Ex838Model
from .ex8_3_9_model import Ex839Model
from .ex8_4_1_model import Ex841Model
from .ex8_4_2_model import Ex842Model
from .ex8_4_3_model import Ex843Model
from .ex8_4_4_model import Ex844Model
from .ex8_4_5_model import Ex845Model
from .ex8_4_6_model import Ex846Model
from .gsg_0001_model import Gsg0001Model
from .kall_circles_c6a_model import KallCirclesC6aModel
from .kall_circles_c6b_model import KallCirclesC6bModel
from .kall_circles_c6c_model import KallCirclesC6cModel
from .kall_circles_c7a_model import KallCirclesC7aModel
from .kall_circles_c8a_model import KallCirclesC8aModel
from .kall_circlespolygons_c1p11_model import KallCirclespolygonsC1p11Model
from .kall_circlespolygons_c1p12_model import KallCirclespolygonsC1p12Model
from .kall_circlespolygons_c1p13_model import KallCirclespolygonsC1p13Model
from .kall_circlespolygons_c1p5a_model import KallCirclespolygonsC1p5aModel
from .kall_circlespolygons_c1p5b_model import KallCirclespolygonsC1p5bModel
from .kall_circlespolygons_c1p6a_model import KallCirclespolygonsC1p6aModel
from .kall_circlesrectangles_c1r11_model import KallCirclesrectanglesC1r11Model
from .kall_circlesrectangles_c1r12_model import KallCirclesrectanglesC1r12Model
from .kall_circlesrectangles_c1r13_model import KallCirclesrectanglesC1r13Model
from .kall_circlesrectangles_c6r1_model import KallCirclesrectanglesC6r1Model
from .kall_congruentcircles_c31_model import KallCongruentcirclesC31Model
from .kall_congruentcircles_c32_model import KallCongruentcirclesC32Model
from .kall_congruentcircles_c41_model import KallCongruentcirclesC41Model
from .kall_congruentcircles_c42_model import KallCongruentcirclesC42Model
from .kall_congruentcircles_c51_model import KallCongruentcirclesC51Model
from .kall_congruentcircles_c52_model import KallCongruentcirclesC52Model
from .kall_congruentcircles_c61_model import KallCongruentcirclesC61Model
from .kall_congruentcircles_c62_model import KallCongruentcirclesC62Model
from .kall_congruentcircles_c63_model import KallCongruentcirclesC63Model
from .kall_congruentcircles_c71_model import KallCongruentcirclesC71Model
from .kall_congruentcircles_c72_model import KallCongruentcirclesC72Model
from .kall_diffcircles_10_model import KallDiffcircles10Model
from .kall_diffcircles_5a_model import KallDiffcircles5aModel
from .kall_diffcircles_5b_model import KallDiffcircles5bModel
from .kall_diffcircles_6_model import KallDiffcircles6Model
from .kall_diffcircles_7_model import KallDiffcircles7Model
from .kall_diffcircles_8_model import KallDiffcircles8Model
from .kall_diffcircles_9_model import KallDiffcircles9Model
from .kriging_peaks_full010_model import KrigingPeaksFull010Model
from .kriging_peaks_full020_model import KrigingPeaksFull020Model
from .kriging_peaks_full030_model import KrigingPeaksFull030Model
from .kriging_peaks_full050_model import KrigingPeaksFull050Model
from .kriging_peaks_full100_model import KrigingPeaksFull100Model
from .kriging_peaks_full200_model import KrigingPeaksFull200Model
from .kriging_peaks_full500_model import KrigingPeaksFull500Model
from .mathopt1_model import Mathopt1Model
from .mathopt4_model import Mathopt4Model
from .orth_d3m6_model import OrthD3m6Model
from .orth_d4m6_pl_model import OrthD4m6PlModel
from .polygon100_model import Polygon100Model
from .polygon25_model import Polygon25Model
from .polygon50_model import Polygon50Model
from .polygon75_model import Polygon75Model
from .pooling_adhya1pq_model import PoolingAdhya1pqModel
from .pooling_adhya1stp_model import PoolingAdhya1stpModel
from .pooling_adhya1tp_model import PoolingAdhya1tpModel
from .pooling_adhya2pq_model import PoolingAdhya2pqModel
from .pooling_adhya2stp_model import PoolingAdhya2stpModel
from .pooling_adhya2tp_model import PoolingAdhya2tpModel
from .pooling_adhya3pq_model import PoolingAdhya3pqModel
from .pooling_adhya3stp_model import PoolingAdhya3stpModel
from .pooling_adhya3tp_model import PoolingAdhya3tpModel
from .pooling_adhya4pq_model import PoolingAdhya4pqModel
from .pooling_adhya4stp_model import PoolingAdhya4stpModel
from .pooling_adhya4tp_model import PoolingAdhya4tpModel
from .pooling_bental4pq_model import PoolingBental4pqModel
from .pooling_bental4stp_model import PoolingBental4stpModel
from .pooling_bental4tp_model import PoolingBental4tpModel
from .pooling_bental5pq_model import PoolingBental5pqModel
from .pooling_bental5stp_model import PoolingBental5stpModel
from .pooling_bental5tp_model import PoolingBental5tpModel
from .pooling_digabel16_model import PoolingDigabel16Model
from .pooling_digabel18_model import PoolingDigabel18Model
from .pooling_digabel19_model import PoolingDigabel19Model
from .pooling_foulds2pq_model import PoolingFoulds2pqModel
from .pooling_foulds2stp_model import PoolingFoulds2stpModel
from .pooling_foulds2tp_model import PoolingFoulds2tpModel
from .pooling_foulds3pq_model import PoolingFoulds3pqModel
from .pooling_foulds3stp_model import PoolingFoulds3stpModel
from .pooling_foulds3tp_model import PoolingFoulds3tpModel
from .pooling_foulds4pq_model import PoolingFoulds4pqModel
from .pooling_foulds4stp_model import PoolingFoulds4stpModel
from .pooling_foulds4tp_model import PoolingFoulds4tpModel
from .pooling_foulds5pq_model import PoolingFoulds5pqModel
from .pooling_foulds5stp_model import PoolingFoulds5stpModel
from .pooling_foulds5tp_model import PoolingFoulds5tpModel
from .pooling_haverly1pq_model import PoolingHaverly1pqModel
from .pooling_haverly1stp_model import PoolingHaverly1stpModel
from .pooling_haverly1tp_model import PoolingHaverly1tpModel
from .pooling_haverly2pq_model import PoolingHaverly2pqModel
from .pooling_haverly2stp_model import PoolingHaverly2stpModel
from .pooling_haverly2tp_model import PoolingHaverly2tpModel
from .pooling_haverly3pq_model import PoolingHaverly3pqModel
from .pooling_haverly3stp_model import PoolingHaverly3stpModel
from .pooling_haverly3tp_model import PoolingHaverly3tpModel
from .pooling_rt2pq_model import PoolingRt2pqModel
from .pooling_rt2stp_model import PoolingRt2stpModel
from .pooling_rt2tp_model import PoolingRt2tpModel
from .pooling_sppa0pq_model import PoolingSppa0pqModel
from .pooling_sppa0stp_model import PoolingSppa0stpModel
from .pooling_sppa0tp_model import PoolingSppa0tpModel
from .pooling_sppa5pq_model import PoolingSppa5pqModel
from .pooling_sppa5stp_model import PoolingSppa5stpModel
from .pooling_sppa5tp_model import PoolingSppa5tpModel
from .pooling_sppa9pq_model import PoolingSppa9pqModel
from .pooling_sppa9stp_model import PoolingSppa9stpModel
from .pooling_sppa9tp_model import PoolingSppa9tpModel
from .pooling_sppb0pq_model import PoolingSppb0pqModel
from .pooling_sppb0stp_model import PoolingSppb0stpModel
from .pooling_sppb0tp_model import PoolingSppb0tpModel
from .pooling_sppb2pq_model import PoolingSppb2pqModel
from .pooling_sppb2stp_model import PoolingSppb2stpModel
from .pooling_sppb2tp_model import PoolingSppb2tpModel
from .pooling_sppb5pq_model import PoolingSppb5pqModel
from .pooling_sppb5tp_model import PoolingSppb5tpModel
from .pooling_sppc0pq_model import PoolingSppc0pqModel
from .pooling_sppc0stp_model import PoolingSppc0stpModel
from .pooling_sppc0tp_model import PoolingSppc0tpModel
from .pooling_sppc1pq_model import PoolingSppc1pqModel
from .pooling_sppc1stp_model import PoolingSppc1stpModel
from .pooling_sppc1tp_model import PoolingSppc1tpModel
from .pricing050_model import Pricing050Model
from .prob06_model import Prob06Model
from .prob09_model import Prob09Model
from .process_model import ProcessModel
from .st_bpaf1a_model import StBpaf1aModel
from .st_bpaf1b_model import StBpaf1bModel
from .st_bpv1_model import StBpv1Model
from .st_bpv2_model import StBpv2Model
from .st_bsj3_model import StBsj3Model
from .st_bsj4_model import StBsj4Model
from .st_e01_model import StE01Model
from .st_e02_model import StE02Model
from .st_e03_model import StE03Model
from .st_e04_model import StE04Model
from .st_e05_model import StE05Model
from .st_e06_model import StE06Model
from .st_e07_model import StE07Model
from .st_e08_model import StE08Model
from .st_e09_model import StE09Model
from .st_e11_model import StE11Model
from .st_e12_model import StE12Model
from .st_e16_model import StE16Model
from .st_e18_model import StE18Model
from .st_e19_model import StE19Model
from .st_e21_model import StE21Model
from .st_e22_model import StE22Model
from .st_e23_model import StE23Model
from .st_e24_model import StE24Model
from .st_e26_model import StE26Model
from .st_e30_model import StE30Model
from .st_e33_model import StE33Model
from .st_e34_model import StE34Model
from .st_e37_model import StE37Model
from .st_e41_model import StE41Model
from .st_ht_model import StHtModel
from .st_iqpbk1_model import StIqpbk1Model
from .st_iqpbk2_model import StIqpbk2Model
from .st_jcbpaf2_model import StJcbpaf2Model
from .st_robot_model import StRobotModel
from .trig_model import TrigModel
from .wastewater02m1_model import Wastewater02m1Model
from .wastewater02m2_model import Wastewater02m2Model
from .wastewater04m1_model import Wastewater04m1Model
from .wastewater04m2_model import Wastewater04m2Model
from .wastewater05m1_model import Wastewater05m1Model
from .wastewater05m2_model import Wastewater05m2Model
from .wastewater11m1_model import Wastewater11m1Model
from .wastewater11m2_model import Wastewater11m2Model
from .wastewater12m1_model import Wastewater12m1Model
from .wastewater12m2_model import Wastewater12m2Model
from .wastewater13m1_model import Wastewater13m1Model
from .wastewater13m2_model import Wastewater13m2Model
from .wastewater14m1_model import Wastewater14m1Model
from .wastewater14m2_model import Wastewater14m2Model
from .wastewater15m1_model import Wastewater15m1Model
from .wastewater15m2_model import Wastewater15m2Model
from .waterund01_model import Waterund01Model
from .waterund08_model import Waterund08Model
from .waterund11_model import Waterund11Model
from .waterund14_model import Waterund14Model
from .waterund17_model import Waterund17Model
from .waterund18_model import Waterund18Model
from .waterund22_model import Waterund22Model
from .waterund25_model import Waterund25Model
from .waterund27_model import Waterund27Model
from .waterund28_model import Waterund28Model
from .waterund32_model import Waterund32Model
from .waterund36_model import Waterund36Model

__all__ = [
    'AlkylModel',
    'AlkylationModel',
    'Arki0005Model',
    'Arki0006Model',
    'Arki0015Model',
    'Eq61Model',
    'Ex211Model',
    'Ex215Model',
    'Ex216Model',
    'Ex218Model',
    'Ex311Model',
    'Ex312Model',
    'Ex418Model',
    'Ex419Model',
    'Ex522Case1Model',
    'Ex522Case2Model',
    'Ex522Case3Model',
    'Ex524Model',
    'Ex525Model',
    'Ex532Model',
    'Ex533Model',
    'Ex542Model',
    'Ex543Model',
    'Ex544Model',
    'Ex6210Model',
    'Ex6211Model',
    'Ex6212Model',
    'Ex6213Model',
    'Ex6214Model',
    'Ex625Model',
    'Ex626Model',
    'Ex627Model',
    'Ex628Model',
    'Ex629Model',
    'Ex721Model',
    'Ex722Model',
    'Ex723Model',
    'Ex724Model',
    'Ex817Model',
    'Ex821bModel',
    'Ex824bModel',
    'Ex8313Model',
    'Ex832Model',
    'Ex833Model',
    'Ex834Model',
    'Ex835Model',
    'Ex837Model',
    'Ex838Model',
    'Ex839Model',
    'Ex841Model',
    'Ex842Model',
    'Ex843Model',
    'Ex844Model',
    'Ex845Model',
    'Ex846Model',
    'Gsg0001Model',
    'KallCirclesC6aModel',
    'KallCirclesC6bModel',
    'KallCirclesC6cModel',
    'KallCirclesC7aModel',
    'KallCirclesC8aModel',
    'KallCirclespolygonsC1p11Model',
    'KallCirclespolygonsC1p12Model',
    'KallCirclespolygonsC1p13Model',
    'KallCirclespolygonsC1p5aModel',
    'KallCirclespolygonsC1p5bModel',
    'KallCirclespolygonsC1p6aModel',
    'KallCirclesrectanglesC1r11Model',
    'KallCirclesrectanglesC1r12Model',
    'KallCirclesrectanglesC1r13Model',
    'KallCirclesrectanglesC6r1Model',
    'KallCongruentcirclesC31Model',
    'KallCongruentcirclesC32Model',
    'KallCongruentcirclesC41Model',
    'KallCongruentcirclesC42Model',
    'KallCongruentcirclesC51Model',
    'KallCongruentcirclesC52Model',
    'KallCongruentcirclesC61Model',
    'KallCongruentcirclesC62Model',
    'KallCongruentcirclesC63Model',
    'KallCongruentcirclesC71Model',
    'KallCongruentcirclesC72Model',
    'KallDiffcircles10Model',
    'KallDiffcircles5aModel',
    'KallDiffcircles5bModel',
    'KallDiffcircles6Model',
    'KallDiffcircles7Model',
    'KallDiffcircles8Model',
    'KallDiffcircles9Model',
    'KrigingPeaksFull010Model',
    'KrigingPeaksFull020Model',
    'KrigingPeaksFull030Model',
    'KrigingPeaksFull050Model',
    'KrigingPeaksFull100Model',
    'KrigingPeaksFull200Model',
    'KrigingPeaksFull500Model',
    'Mathopt1Model',
    'Mathopt4Model',
    'OrthD3m6Model',
    'OrthD4m6PlModel',
    'Polygon100Model',
    'Polygon25Model',
    'Polygon50Model',
    'Polygon75Model',
    'PoolingAdhya1pqModel',
    'PoolingAdhya1stpModel',
    'PoolingAdhya1tpModel',
    'PoolingAdhya2pqModel',
    'PoolingAdhya2stpModel',
    'PoolingAdhya2tpModel',
    'PoolingAdhya3pqModel',
    'PoolingAdhya3stpModel',
    'PoolingAdhya3tpModel',
    'PoolingAdhya4pqModel',
    'PoolingAdhya4stpModel',
    'PoolingAdhya4tpModel',
    'PoolingBental4pqModel',
    'PoolingBental4stpModel',
    'PoolingBental4tpModel',
    'PoolingBental5pqModel',
    'PoolingBental5stpModel',
    'PoolingBental5tpModel',
    'PoolingDigabel16Model',
    'PoolingDigabel18Model',
    'PoolingDigabel19Model',
    'PoolingFoulds2pqModel',
    'PoolingFoulds2stpModel',
    'PoolingFoulds2tpModel',
    'PoolingFoulds3pqModel',
    'PoolingFoulds3stpModel',
    'PoolingFoulds3tpModel',
    'PoolingFoulds4pqModel',
    'PoolingFoulds4stpModel',
    'PoolingFoulds4tpModel',
    'PoolingFoulds5pqModel',
    'PoolingFoulds5stpModel',
    'PoolingFoulds5tpModel',
    'PoolingHaverly1pqModel',
    'PoolingHaverly1stpModel',
    'PoolingHaverly1tpModel',
    'PoolingHaverly2pqModel',
    'PoolingHaverly2stpModel',
    'PoolingHaverly2tpModel',
    'PoolingHaverly3pqModel',
    'PoolingHaverly3stpModel',
    'PoolingHaverly3tpModel',
    'PoolingRt2pqModel',
    'PoolingRt2stpModel',
    'PoolingRt2tpModel',
    'PoolingSppa0pqModel',
    'PoolingSppa0stpModel',
    'PoolingSppa0tpModel',
    'PoolingSppa5pqModel',
    'PoolingSppa5stpModel',
    'PoolingSppa5tpModel',
    'PoolingSppa9pqModel',
    'PoolingSppa9stpModel',
    'PoolingSppa9tpModel',
    'PoolingSppb0pqModel',
    'PoolingSppb0stpModel',
    'PoolingSppb0tpModel',
    'PoolingSppb2pqModel',
    'PoolingSppb2stpModel',
    'PoolingSppb2tpModel',
    'PoolingSppb5pqModel',
    'PoolingSppb5tpModel',
    'PoolingSppc0pqModel',
    'PoolingSppc0stpModel',
    'PoolingSppc0tpModel',
    'PoolingSppc1pqModel',
    'PoolingSppc1stpModel',
    'PoolingSppc1tpModel',
    'Pricing050Model',
    'Prob06Model',
    'Prob09Model',
    'ProcessModel',
    'StBpaf1aModel',
    'StBpaf1bModel',
    'StBpv1Model',
    'StBpv2Model',
    'StBsj3Model',
    'StBsj4Model',
    'StE01Model',
    'StE02Model',
    'StE03Model',
    'StE04Model',
    'StE05Model',
    'StE06Model',
    'StE07Model',
    'StE08Model',
    'StE09Model',
    'StE11Model',
    'StE12Model',
    'StE16Model',
    'StE18Model',
    'StE19Model',
    'StE21Model',
    'StE22Model',
    'StE23Model',
    'StE24Model',
    'StE26Model',
    'StE30Model',
    'StE33Model',
    'StE34Model',
    'StE37Model',
    'StE41Model',
    'StHtModel',
    'StIqpbk1Model',
    'StIqpbk2Model',
    'StJcbpaf2Model',
    'StRobotModel',
    'TrigModel',
    'Wastewater02m1Model',
    'Wastewater02m2Model',
    'Wastewater04m1Model',
    'Wastewater04m2Model',
    'Wastewater05m1Model',
    'Wastewater05m2Model',
    'Wastewater11m1Model',
    'Wastewater11m2Model',
    'Wastewater12m1Model',
    'Wastewater12m2Model',
    'Wastewater13m1Model',
    'Wastewater13m2Model',
    'Wastewater14m1Model',
    'Wastewater14m2Model',
    'Wastewater15m1Model',
    'Wastewater15m2Model',
    'Waterund01Model',
    'Waterund08Model',
    'Waterund11Model',
    'Waterund14Model',
    'Waterund17Model',
    'Waterund18Model',
    'Waterund22Model',
    'Waterund25Model',
    'Waterund27Model',
    'Waterund28Model',
    'Waterund32Model',
    'Waterund36Model',
]