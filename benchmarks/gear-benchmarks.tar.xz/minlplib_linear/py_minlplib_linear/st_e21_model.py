"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE21Model
  model = StE21Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class StE21Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e21_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 4, [[0.0] * 4 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m3 = LastDimSliceModule(6, 7)
        _m7 = VariableVectorGatherModule([0] * 2)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m5 = VectorScaleModule(_m6, 1, dtype=torch.float64)
        _m4 = VectorReduceModule(_m5, 'sum')
        _m2 = VectorSumModule([_m3, _m4, _m9])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
