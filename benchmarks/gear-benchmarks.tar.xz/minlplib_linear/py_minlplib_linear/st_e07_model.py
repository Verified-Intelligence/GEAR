"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE07Model
  model = StE07Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class StE07Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e07_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 2)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 2)
        _m34 = SharedLinearFormModule([0] * 7, [[0.0] * 7 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m31, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m23, 'mul')
        _m26 = ResidualCoefScaleModule(_m27, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m14 = ResidualCoefScaleModule(_m15, [0.0] * 1, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 5, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m14, _m26, _m34], [[], [0] * 1, [0] * 2, [0] * 5], 5, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
