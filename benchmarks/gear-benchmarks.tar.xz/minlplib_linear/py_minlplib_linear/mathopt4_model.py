"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Mathopt4Model
  model = Mathopt4Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from modules import GeneralResidualModule, LiftCompactToFullModule, ResidualCoefScaleModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Mathopt4Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'mathopt4_model_state.pt'

        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 2)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 2)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m32, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m36 = VectorUnaryOpModule(_m37, 'sin')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m26, 'add')
        _m35 = ResidualCoefScaleModule(_m36, [0.0] * 2, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m15, 'pow')
        _m17 = VectorBinaryOpModule(_m18, _m33, 'pow')
        _m2 = ResidualCoefScaleModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m16 = ResidualCoefScaleModule(_m17, [0.0] * 1, dtype=torch.float64)
        _m1 = LiftCompactToFullModule(_m2, [0] * 1, 3, dtype=torch.float64)
        _m0 = GeneralResidualModule([_m1, _m16, _m34, _m35], [[], [0] * 1, [0] * 2, [0] * 2], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
