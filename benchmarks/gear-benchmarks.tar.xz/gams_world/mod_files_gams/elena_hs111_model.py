"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaHs111Model
  model = ElenaHs111Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, CombinedASTModule, ConstantVectorModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class ElenaHs111Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_hs111_model_state.pt'

        _m5 = VariableVectorGatherModule([0] * 10)
        _m7 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 10)
        _m16 = VariableVectorGatherModule([0] * 10)
        _m19 = VariableVectorGatherModule([0] * 10)
        _m22 = VariableVectorGatherModule([0] * 10)
        _m25 = VariableVectorGatherModule([0] * 10)
        _m28 = VariableVectorGatherModule([0] * 10)
        _m31 = VariableVectorGatherModule([0] * 10)
        _m34 = VariableVectorGatherModule([0] * 10)
        _m37 = VariableVectorGatherModule([0] * 10)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 10)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 5)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m55 = VariableVectorGatherModule([0] * 5)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 4)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m69 = VariableVectorGatherModule([0] * 4)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m74 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 5)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m83 = VariableVectorGatherModule([0] * 5)
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m12 = VectorUnaryOpModule(_m13, 'exp')
        _m15 = VectorUnaryOpModule(_m16, 'exp')
        _m18 = VectorUnaryOpModule(_m19, 'exp')
        _m21 = VectorUnaryOpModule(_m22, 'exp')
        _m24 = VectorUnaryOpModule(_m25, 'exp')
        _m27 = VectorUnaryOpModule(_m28, 'exp')
        _m30 = VectorUnaryOpModule(_m31, 'exp')
        _m33 = VectorUnaryOpModule(_m34, 'exp')
        _m36 = VectorUnaryOpModule(_m37, 'exp')
        _m40 = VectorUnaryOpModule(_m41, 'exp')
        _m47 = VectorUnaryOpModule(_m48, 'exp')
        _m54 = VectorUnaryOpModule(_m55, 'exp')
        _m61 = VectorUnaryOpModule(_m62, 'exp')
        _m68 = VectorUnaryOpModule(_m69, 'exp')
        _m75 = VectorUnaryOpModule(_m76, 'exp')
        _m82 = VectorUnaryOpModule(_m83, 'exp')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'add')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m59 = VectorBinaryOpModule(_m60, _m61, 'mul')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m75, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m38, 'add')
        _m44 = VectorReduceModule(_m45, 'sum')
        _m51 = VectorReduceModule(_m52, 'sum')
        _m58 = VectorReduceModule(_m59, 'sum')
        _m65 = VectorReduceModule(_m66, 'sum')
        _m72 = VectorReduceModule(_m73, 'sum')
        _m79 = VectorReduceModule(_m80, 'sum')
        _m32 = VectorBinaryOpModule(_m33, _m35, 'add')
        _m42 = VectorSumModule([_m43, _m44])
        _m49 = VectorSumModule([_m50, _m51])
        _m56 = VectorSumModule([_m57, _m58])
        _m63 = VectorSumModule([_m64, _m65])
        _m70 = VectorSumModule([_m71, _m72])
        _m77 = VectorSumModule([_m78, _m79])
        _m29 = VectorBinaryOpModule(_m30, _m32, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m29, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m26, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m23, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m20, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m17, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m14, 'add')
        _m10 = VectorUnaryOpModule(_m11, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m6, 'mul')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = CombinedASTModule([_m1, _m42, _m49, _m56, _m63, _m70, _m77], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2), ('scalar_at', 3, 3), ('scalar_at', 4, 4), ('scalar_at', 5, 5), ('scalar_at', 6, 6)], 7)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
