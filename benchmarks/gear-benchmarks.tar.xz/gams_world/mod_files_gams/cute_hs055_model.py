"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs055Model
  model = CuteHs055Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHs055Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs055_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(13)], [0.0] * 13, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 0)], 13)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 13, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 13
