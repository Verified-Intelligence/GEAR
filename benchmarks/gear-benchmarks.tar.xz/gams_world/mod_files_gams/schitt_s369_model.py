"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS369Model
  model = SchittS369Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class SchittS369Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s369_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 4)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 4)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 4)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m22 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 2)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 2)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 2)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 2)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m11, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'div')
        _m23 = VectorBinaryOpModule(_m24, _m27, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m35, 'div')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'div')
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 1, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m23, 'div')
        _m30 = ResidualBucketScatterAddModule(_m31, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m20 = ResidualBucketScatterAddModule(_m21, [0.0] * 2, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m14, _m20, _m30], [[0] * 4, [0] * 1, [0] * 2, [0] * 2], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
