"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Bohachevsky1Model
  model = Bohachevsky1Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorSumModule, VectorUnaryOpModule

class Bohachevsky1Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Bohachevsky1_model_state.pt'

        _m2 = VariableVectorGatherModule([0] * 1)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m7 = LastDimSliceModule(1, 2)
        _m8 = LastDimSliceModule(0, 1)
        _m11 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m13 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m1 = VectorBinaryOpModule(_m2, _m3, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m12 = VectorUnaryOpModule(_m13, 'cos')
        _m4 = SharedLinearSingleCoreModule(_m5, _m6)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m9 = VectorReduceModule(_m10, 'sum')
        _m0 = VectorSumModule([_m1, _m4, _m9, _m14])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
