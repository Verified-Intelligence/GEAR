"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchwefelModel
  model = SchwefelModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class SchwefelModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Schwefel_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = LastDimSliceModule(1, 2)
        _m8 = LastDimSliceModule(0, 1)
        _m15 = VariableVectorGatherModule([0] * 9)
        _m16 = VariableVectorGatherModule([0] * 9)
        _m7 = VectorUnaryOpModule(_m8, 'abs')
        _m14 = VectorUnaryOpModule(_m15, 'abs')
        _m6 = VectorUnaryOpModule(_m7, 'sqrt')
        _m13 = VectorUnaryOpModule(_m14, 'sqrt')
        _m5 = VectorUnaryOpModule(_m6, 'sin')
        _m12 = VectorUnaryOpModule(_m13, 'sin')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m16, 'mul')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m10 = VectorScaleModule(_m11, -1, dtype=torch.float64)
        _m9 = VectorReduceModule(_m10, 'sum')
        _m0 = VectorSumModule([_m1, _m9])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
