import torch
import torch.nn as nn
import torch.nn.functional as F

class MinModule(nn.Module):
    """PyTorch module for min function with multiple arguments"""
    def __init__(self, arg_modules):
        super().__init__()
        self.arg_modules = nn.ModuleList(arg_modules)
    
    def forward(self, x):
        results = [module(x) for module in self.arg_modules]
        # Stack results along the last dimension to preserve batch dimension
        stacked = torch.stack(results, dim=-1)
        # Take min along the last dimension (the arguments dimension)
        return torch.min(stacked, dim=-1)[0]

class ConcatModules(nn.Module):
    """Concatenate outputs of modules along the last dim.

    Each module should output (..., K_i). The result is (..., sum K_i).
    """
    def __init__(self, modules_list, total_outputs: int):
        super().__init__()
        self.modules_list = nn.ModuleList(modules_list)
        self.total_outputs = total_outputs

    def forward(self, x):
        outs = []
        for m in self.modules_list:
            y = m(x)
            # Normalize shapes to (..., K)
            if y.dim() == 0:
                y = y.view(1)
            if y.dim() == 1:
                y = y.unsqueeze(-1)
            outs.append(y)
        return torch.concat(outs, dim=-1)

    def get_output_dimension(self):
        return self.total_outputs

class CombinedASTModule(nn.Module):
    """Combine multiple modules and stitch outputs per a layout map.

    layout entries:
      - ('scalar_at', mod_idx, pos)
      - ('vector_pick', mod_idx, elem_idx, pos)
    Output is concatenated in original AST order of length total_outputs.
    """
    def __init__(self, ast_modules, layout, total_outputs: int):
        super().__init__()
        self.ast_modules = nn.ModuleList(ast_modules)
        self.layout = layout
        self.total_outputs = total_outputs

        # Precompute a packing plan so we can stitch outputs with a *single* Gather.
        #
        # Why: the naive stitching path does v[..., i] per output, which exports to hundreds
        # of Slice/Gather nodes. Here we instead:
        #   1) concatenate needed module outputs into one packed vector (..., T)
        #   2) index_select once with a permutation index of length total_outputs.
        mod_dim = {}
        covered = [False] * int(total_outputs)
        for entry in self.layout:
            tag = entry[0]
            if tag == 'scalar_at':
                _, mod_idx, pos = entry
                mod_dim[mod_idx] = max(int(mod_dim.get(mod_idx, 1)), 1)
                if 0 <= int(pos) < int(total_outputs):
                    covered[int(pos)] = True
            elif tag == 'vector_pick':
                _, mod_idx, elem_idx, pos = entry
                mod_dim[mod_idx] = max(int(mod_dim.get(mod_idx, 0)), int(elem_idx) + 1)
                if 0 <= int(pos) < int(total_outputs):
                    covered[int(pos)] = True

        self.needed = sorted(mod_dim.keys())
        self.mod_dim = {k: int(v) for k, v in mod_dim.items()}

        offsets = {}
        cur = 0
        for mid in self.needed:
            offsets[mid] = int(cur)
            cur += int(self.mod_dim[mid])
        self.packed_dim = int(cur)

        # Build permutation indices: for each output position, which packed column to select.
        # Any uncovered positions map to a special zero column appended at runtime.
        select = [0 for _ in range(int(total_outputs))]
        self.has_missing = any(not c for c in covered)
        missing_col = int(self.packed_dim)  # appended as last column if needed
        for pos in range(int(total_outputs)):
            if not covered[pos]:
                select[pos] = missing_col

        for entry in self.layout:
            tag = entry[0]
            if tag == 'scalar_at':
                _, mod_idx, pos = entry
                select[int(pos)] = int(offsets[int(mod_idx)])
            elif tag == 'vector_pick':
                _, mod_idx, elem_idx, pos = entry
                select[int(pos)] = int(offsets[int(mod_idx)]) + int(elem_idx)

        # If select is identity and there are no missing outputs, we can skip the final index_select.
        # This avoids exporting a redundant Gather after the final concat.
        self.identity_select = (not self.has_missing) and (self.packed_dim == int(total_outputs)) and (
            select == list(range(int(total_outputs)))
        )
        if not self.identity_select:
            self.register_buffer('select_indices', torch.tensor(select, dtype=torch.long))
    
    def forward(self, x):
        # Compute needed modules and pack their outputs into (..., packed_dim)
        packed_parts = []
        for mid in self.needed:
            y = self.ast_modules[mid](x)
            # Normalize shapes to (..., K)
            if y.dim() == 0:
                y = y.view(1)
            if y.dim() == 1:
                y = y.unsqueeze(-1)
            k = int(self.mod_dim[mid])
            if y.shape[-1] > k:
                y = y[..., :k]
            elif y.shape[-1] < k:
                pad = torch.zeros(*y.shape[:-1], (k - int(y.shape[-1])), dtype=y.dtype, device=y.device)
                y = torch.concat([y, pad], dim=-1)
            packed_parts.append(y)

        if len(packed_parts) == 0:
            packed = torch.zeros(*x.shape[:-1], 0, dtype=x.dtype, device=x.device)
        elif len(packed_parts) == 1:
            packed = packed_parts[0]
        else:
            packed = torch.concat(packed_parts, dim=-1)

        if self.has_missing:
            z = torch.zeros(*x.shape[:-1], 1, dtype=x.dtype, device=x.device)
            packed = torch.concat([packed, z], dim=-1)

        # One gather to produce outputs in original order (skip when it's a no-op)
        if self.identity_select:
            return packed
        return torch.index_select(packed, dim=-1, index=self.select_indices)
    
    def get_output_dimension(self):
        return self.total_outputs

# ========================= Vector IR PyTorch Modules =========================

class VariableVectorGatherModule(nn.Module):
    """Gather a sequence of variables by indices to form a vector (..., N)."""
    def __init__(self, indices):
        super().__init__()
        self.register_buffer('indices', torch.tensor(indices, dtype=torch.long))
    def forward(self, x):
        return torch.index_select(x, dim=-1, index=self.indices)


class BatchedAffineGatherModule(nn.Module):
    """Compute N affine forms via one Gather + weighted sum.

    This is the "gather path" alternative to building a (potentially very sparse) MatMul:

      y_i = sum_j weights[i,j] * x[indices[i,j]] + bias[i]

    Shapes:
      - indices_2d: (N, Wmax) int64
      - weights_2d: (N, Wmax) float
      - bias: (N,) float
    Forward:
      - x: (..., K)
      - out: (..., N)
    """
    def __init__(self, indices_2d, weights_2d, bias, dtype: torch.dtype = torch.float32):
        super().__init__()
        idx = torch.tensor(indices_2d, dtype=torch.long)
        w = torch.tensor(weights_2d, dtype=dtype)
        b = torch.tensor(bias, dtype=dtype)
        if idx.dim() != 2:
            raise ValueError("indices_2d must be rank-2 (N, W)")
        if w.shape != idx.shape:
            raise ValueError("weights_2d must have the same shape as indices_2d")
        if b.dim() != 1 or b.shape[0] != idx.shape[0]:
            raise ValueError("bias must be shape (N,)")
        self.n = int(idx.shape[0])
        self.w = int(idx.shape[1])
        self.register_buffer('idx_flat', idx.reshape(-1))
        self.register_buffer('weights', w)
        self.register_buffer('bias', b)
        self.has_bias = bool(b.numel() > 0 and (b != 0).any().item())

    def forward(self, x):
        batch_shape = x.shape[:-1]
        if self.w == 1:
            gathered = torch.index_select(x, dim=-1, index=self.idx_flat)  # (..., N)
            gathered = gathered.view(*batch_shape, self.n)  # (..., N)
            w = self.weights.view(*([1] * len(batch_shape)), self.n)  # (..., N)
            out = gathered * w  # (..., N)
        else:
            gathered = torch.index_select(x, dim=-1, index=self.idx_flat)  # (..., N*W)
            gathered = gathered.view(*batch_shape, self.n, self.w)  # (..., N, W)
            w = self.weights.view(*([1] * len(batch_shape)), self.n, self.w)
            out = torch.sum(gathered * w, dim=-1)  # (..., N)
        if self.bias.numel() > 0 and (self.bias != 0).any().item():
            out = out + self.bias
        return out


class LastDimSliceModule(nn.Module):
    """Slice a tensor on the last dimension: x[..., start:end]."""
    def __init__(self, start: int, end: int):
        super().__init__()
        self.start = int(start)
        self.end = int(end)

    def forward(self, x):
        return x[..., self.start:self.end]


class ConstantVectorModule(nn.Module):
    """Constant vector of length N, broadcast over batch dims to (..., N)."""
    def __init__(self, values, dtype: torch.dtype = torch.float32):
        super().__init__()
        values = torch.tensor(values, dtype=dtype)
        self.register_buffer('values', values)
    def forward(self, x):
        return self.values


class ScalarConstantModule(nn.Module):
    """Scalar constant (0-d tensor) that broadcasts in binary ops."""
    def __init__(self, value: float, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.register_buffer('value', torch.tensor(float(value), dtype=dtype))
    def forward(self, x):
        return self.value


class VectorUnaryOpModule(nn.Module):
    """Elementwise unary op over a vector (..., N)."""
    def __init__(self, operand_module, operation):
        super().__init__()
        self.operand_module = operand_module
        self.operation = operation
    def forward(self, x):
        v = self.operand_module(x)
        if self.operation == 'log':
            return torch.log(v)
        elif self.operation == 'sin':
            return torch.sin(v)
        elif self.operation == 'cos':
            return torch.cos(v)
        elif self.operation == 'tan':
            return torch.tan(v)
        elif self.operation == 'exp':
            return torch.exp(v)
        elif self.operation == 'sqrt':
            return torch.sqrt(v)
        elif self.operation == 'tanh':
            return torch.tanh(v)
        elif self.operation == 'abs':
            return torch.abs(v)
        elif self.operation == 'neg':
            return -v
        else:
            raise ValueError(f"Unsupported unary vector operation: {self.operation}")


class VectorBinaryOpModule(nn.Module):
    """Elementwise binary op over vectors (..., N) and/or broadcastable scalars."""
    def __init__(self, left_module, right_module, operation):
        super().__init__()
        self.left_module = left_module
        self.right_module = right_module
        self.operation = operation
    def forward(self, x):
        l = self.left_module(x)
        r = self.right_module(x)
        if self.operation == 'add':
            if isinstance(self.left_module, ConstantVectorModule):
                return r + l
            return l + r
        elif self.operation == 'sub':
            return l - r
        elif self.operation == 'mul':
            if isinstance(self.left_module, ConstantVectorModule):
                return r * l
            return l * r
        elif self.operation == 'div':
            return l / r
        elif self.operation == 'pow':
            # In this project we treat exponent `y` in x^y as a scalar constant.
            # Different exponents are separated at signature time (see compiler),
            # so we do not vectorize across different `y` values.
            return torch.pow(l, r)
        else:
            raise ValueError(f"Unsupported binary vector operation: {self.operation}")


class VectorScaleModule(nn.Module):
    """Scale a vector (..., N) by a scalar constant."""
    def __init__(self, vector_module, scale: float, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.vector_module = vector_module
        self.register_buffer('scale', torch.tensor(float(scale), dtype=dtype))
    def forward(self, x):
        v = self.vector_module(x)
        # Make scale shape broadcastable: (..., 1)
        if v.dim() >= 1:
            s = self.scale
            for _ in range(v.dim() - 1):
                s = s.unsqueeze(0)
            return v * s
        return v * self.scale


class VectorReduceModule(nn.Module):
    """Generic reduce over last dim to (...,1): sum|min|max|mean."""
    def __init__(self, vector_module, op: str = 'sum'):
        super().__init__()
        self.vector_module = vector_module
        self.op = op
    def forward(self, x):
        v = self.vector_module(x)
        if self.op == 'sum':
            return torch.sum(v, dim=-1, keepdim=True)
        if self.op == 'min':
            return torch.min(v, dim=-1, keepdim=True).values
        if self.op == 'max':
            return torch.max(v, dim=-1, keepdim=True).values
        if self.op == 'mean':
            return torch.mean(v, dim=-1, keepdim=True)
        raise ValueError(f"Unsupported reduce op: {self.op}")


class VectorSumModule(nn.Module):
    """Kahan sum of a list of vector modules, each returning (..., 1)."""
    def __init__(self, modules_list):
        super().__init__()
        self.modules_list = nn.ModuleList(modules_list)
    def forward(self, x):
        if len(self.modules_list) == 0:
            raise ValueError("VectorSumModule requires at least one module")
        s = None
        c = None
        for mod in self.modules_list:
            y = mod(x)
            if s is None:
                s = y
                c = torch.zeros_like(y)
                continue
            y_k = y - c
            t = s + y_k
            c = (t - s) - y_k
            s = t
        return s

    def get_output_dimension(self):
        return 1


# ========================= Cross-formula shared modules =========================

class SharedLinearFormModule(nn.Module):
    """Compute a shared linear form for multiple formulas in one pass.

    Given:
      - indices: list[int] of variables used (length K)
      - coef_matrix: shape (M, K) where M is number of formulas
      - bias: shape (M,)

    Forward:
      y = x[..., indices] @ coef_matrix.T + bias
    Output shape: (..., M)
    """
    def __init__(self, indices, coef_matrix, bias, dtype: torch.dtype = torch.float32):
        super().__init__()
        # If indices is empty, we interpret it as "use x directly" (no index_select/Gather).
        self.straight_forward = True if indices is None else False
        indices = [] if indices is None else indices
        self.register_buffer('indices', torch.tensor(indices, dtype=torch.long))
        self.register_buffer('coef_matrix', torch.tensor(coef_matrix, dtype=dtype))
        bias_t = torch.tensor(bias, dtype=dtype)
        self.register_buffer('bias', bias_t)
        # Compile-time flag: avoid emitting Add if bias is identically zero.
        self.has_bias = bool(bias_t.numel() > 0 and (bias_t != 0).any().item())

    def forward(self, x):
        if self.straight_forward:
            v = x
        else:
            v = torch.index_select(x, dim=-1, index=self.indices)  # (..., K)
        # Ensure dtype matches weight matrix to avoid float/long mismatches.
        if v.dtype != self.coef_matrix.dtype:
            v = v.to(self.coef_matrix.dtype)
        y = v @ self.coef_matrix.t()  # (..., M)
        # Check has_bias at runtime so load_state_dict works (placeholder had all zeros)
        has_bias = bool(self.bias.numel() > 0 and (self.bias != 0).any().item())
        if has_bias:
            return y + self.bias
        return y


class CrossFormulaLinearResidualVectorModule(nn.Module):
    """Combine a shared linear module with residual module(s) to compute formula outputs.

    - shared_linear: SharedLinearFormModule or None, returns (..., K) where K is number of formulas
    - residual_module: list[nn.Module] of residual modules (e.g., ResidualBucketScatterAddModule or CombinedASTModule);
                       if form_indices is provided, modules return (..., M_i) and are scattered;
                       if form_indices is None, modules are assumed to return (..., K) directly
    - form_indices: list of form_idx tensors (one per residual_module) or None;
                    if not None, form_idx[i] maps bucket element i to formula index for scatter operations
    Output is (..., K) in original formula order: y = scatter(sum(residual_module), form_indices) + shared_linear(x)
    """
    def __init__(self, shared_linear, residual_module: list, form_indices, total_outputs: int, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.shared_linear = shared_linear
        self.residual_module = nn.ModuleList(residual_module) if residual_module else nn.ModuleList()
        self.total_outputs = int(total_outputs)
        self.dtype = dtype
        self.use_scatter = form_indices is not None
        
        if self.use_scatter:
            # Register form_indices as buffers so they move with model.to(device)
            idxs = []
            for i, form_idx in enumerate(form_indices):
                idxs.append(torch.tensor(form_idx, dtype=torch.long))
            idxs = torch.cat(idxs, dim=0)
            self.register_buffer(f'idxs', idxs)
            self._num_form_indices = len(form_indices)
            # TODO: Fast-path detection for structured patterns (placeholder)
            # This would detect contiguous repeat patterns and use reshape+reduce instead of scatter
            self.has_fast_paths = False  # Placeholder
        else:
            self._num_form_indices = 0
            self.has_fast_paths = False

    def forward(self, x):
        if self.use_scatter:
            if self.shared_linear is not None:
                y = self.shared_linear(x)
            else:
                raise RuntimeError("Shared linear should not be none!")

            # Scatter each bucket's contributions to formulas
            contribs = []
            for i, m in enumerate(self.residual_module):
                contrib = m(x)  # (..., M_i)
                contribs.append(contrib)
            contribs = torch.cat(contribs, dim=1)
            idx = getattr(self, f'idxs')
            y.index_add_(1, idx, contribs)
                
        else:
            # Direct summation (e.g., CombinedASTModule already handles layout)
            if self.shared_linear is not None:
                y = self.shared_linear(x)
            else:
                y = torch.zeros(*x.shape[:-1], self.total_outputs, dtype=self.dtype, device=x.device)
            for m in self.residual_module:
                y += m(x)

        return y

    def get_output_dimension(self):
        return self.total_outputs


class SharedLinearSingleCoreModule(nn.Module):
    """Compute a shared linear form once, then evaluate a single-core expression over its columns.

    This is used to optimize singleton nonlinear buckets (group size == 1) by lifting all affine
    subexpressions inside that core into one SharedLinearFormModule (MatMul/Gemm), avoiding
    repeated Gather/Add trees like x1+x2, x1+x3, x2+x3 inside nested residuals.

    - shared_linear: SharedLinearFormModule producing (..., M)
    - expr_over_lin: nn.Module taking input tensor (..., M) and producing (..., 1)
    """
    def __init__(self, shared_linear: nn.Module, expr_over_lin: nn.Module):
        super().__init__()
        self.shared_linear = shared_linear
        self.expr_over_lin = expr_over_lin

    def forward(self, x):
        lin = self.shared_linear(x)
        return self.expr_over_lin(lin)

    def get_output_dimension(self):
        return 1


class SharedLinearAugmentModule(nn.Module):
    """Compute shared linear forms and augment the input: concat([x, lin], -1) -> inner.

    This is used by the selective whole-tree affine pooling pass: only some affine subtrees
    are replaced by ('lin', col). The inner graph may still reference raw variables, so it
    must receive the original x as well as the pooled lin columns.
    """
    def __init__(self, shared_linear: nn.Module, inner: nn.Module):
        super().__init__()
        self.shared_linear = shared_linear
        self.inner = inner

    def forward(self, x):
        lin = self.shared_linear(x)  # (..., M)
        aug = torch.concat([x, lin], dim=-1)  # (..., K+M)
        return self.inner(aug)

    def get_output_dimension(self):
        if hasattr(self.inner, "get_output_dimension"):
            return self.inner.get_output_dimension()
        return 1

class ResidualBucketScatterAddModule(nn.Module):
    """Compute vectorized bucket values with coefficients applied.

    Returns (..., M) tensor where M is the number of occurrences in the bucket.
    Scatter to formulas is handled by CrossFormulaLinearResidualVectorModule.
    """
    def __init__(self, bucket_module: nn.Module, coef, dtype: torch.dtype = torch.float32):
        super().__init__()
        self.bucket_module = bucket_module
        w = torch.tensor(coef, dtype=dtype)
        if w.dim() != 1:
            raise ValueError("coef must be a 1D tensor")
        self.n = int(w.numel())
        self.register_buffer("coef", w)

    def forward(self, x):
        v = self.bucket_module(x)  # (..., N)
        batch_shape = x.shape[:-1]
        if v.dim() == 0:
            v = v.reshape(1)
        if v.dim() == 1 and len(batch_shape) > 0:
            v = v.expand(*batch_shape, v.shape[-1])
        if int(v.shape[-1]) == 1 and self.n != 1:
            v = v.expand(*v.shape[:-1], self.n)
        if int(v.shape[-1]) != self.n:
            raise ValueError(f"ResidualBucketScatterAddModule expected last-dim {self.n}, got {int(v.shape[-1])}")

        # Apply coefficients (compute flags from self.coef at runtime so load_state_dict works)
        w = self.coef
        coef_is_all_ones = bool((w == 1).all().item()) if self.n > 0 else True
        coef_is_scalar = False
        coef_scalar = 1.0
        if (not coef_is_all_ones) and self.n > 0:
            uniq = torch.unique(w)
            if int(uniq.numel()) == 1:
                coef_is_scalar = True
                coef_scalar = float(uniq[0].item())
        if coef_is_all_ones:
            contrib = v
        elif coef_is_scalar:
            contrib = v * coef_scalar
        else:
            contrib = v * self.coef.view(*([1] * (v.dim() - 1)), self.n)

        return contrib  # (..., M) where M = self.n
