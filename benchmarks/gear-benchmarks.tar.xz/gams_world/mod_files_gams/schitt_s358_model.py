"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS358Model
  model = SchittS358Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class SchittS358Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s358_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(5, 6)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ConstantVectorModule([0.0] * 32, dtype=torch.float64)
        _m15 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(32)], [0.0] * 32, dtype=torch.float64)
        _m16 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(32)], [0.0] * 32, dtype=torch.float64)
        _m19 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(32)], [0.0] * 32, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 32)
        _m21 = VariableVectorGatherModule([0] * 32)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m14 = VectorUnaryOpModule(_m15, 'exp')
        _m18 = VectorUnaryOpModule(_m19, 'exp')
        _m13 = VectorBinaryOpModule(_m14, _m16, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m20, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m17, 'sub')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m21, 'sub')
        _m8 = VectorBinaryOpModule(_m9, _m22, 'pow')
        _m7 = VectorScaleModule(_m8, 1, dtype=torch.float64)
        _m6 = VectorReduceModule(_m7, 'sum')
        _m2 = VectorSumModule([_m3, _m6])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
