"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Shekel7Model
  model = Shekel7Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule

class Shekel7Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Shekel7_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 7, dtype=torch.float64)
        _m4 = ConstantVectorModule([0.0] * 7, dtype=torch.float64)
        _m6 = ConstantVectorModule([0.0] * 7, dtype=torch.float64)
        _m11 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m16, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m19, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'div')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
