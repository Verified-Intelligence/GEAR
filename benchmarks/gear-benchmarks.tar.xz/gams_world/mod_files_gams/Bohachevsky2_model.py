"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Bohachevsky2Model
  model = Bohachevsky2Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Bohachevsky2Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Bohachevsky2_model_state.pt'

        _m2 = VariableVectorGatherModule([0] * 1)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m7 = LastDimSliceModule(1, 2)
        _m8 = LastDimSliceModule(0, 1)
        _m11 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = LastDimSliceModule(0, 1)
        _m18 = LastDimSliceModule(1, 2)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m1 = VectorBinaryOpModule(_m2, _m3, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m15 = VectorUnaryOpModule(_m16, 'cos')
        _m17 = VectorUnaryOpModule(_m18, 'cos')
        _m4 = SharedLinearSingleCoreModule(_m5, _m6)
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m17, 'mul')
        _m10 = SharedLinearSingleCoreModule(_m11, _m12)
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m4, _m9, _m19])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
