"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs062Model
  model = CuteHs062Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, LastDimSliceModule, SharedLinearAugmentModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteHs062Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs062_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m4 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m9 = LastDimSliceModule(6, 7)
        _m10 = LastDimSliceModule(5, 6)
        _m14 = LastDimSliceModule(4, 5)
        _m15 = LastDimSliceModule(3, 4)
        _m18 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m21 = LastDimSliceModule(1, 2)
        _m22 = LastDimSliceModule(0, 1)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'div')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'div')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'div')
        _m7 = VectorUnaryOpModule(_m8, 'log')
        _m12 = VectorUnaryOpModule(_m13, 'log')
        _m19 = VectorUnaryOpModule(_m20, 'log')
        _m6 = VectorScaleModule(_m7, -8204.369999999999, dtype=torch.float64)
        _m11 = VectorScaleModule(_m12, -9008.72, dtype=torch.float64)
        _m17 = SharedLinearSingleCoreModule(_m18, _m19)
        _m16 = VectorScaleModule(_m17, -9330.46, dtype=torch.float64)
        _m5 = VectorSumModule([_m6, _m11, _m16])
        _m3 = SharedLinearAugmentModule(_m4, _m5)
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 0)], 3)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
