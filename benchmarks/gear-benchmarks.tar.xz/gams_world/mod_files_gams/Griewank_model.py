"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import GriewankModel
  model = GriewankModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class GriewankModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Griewank_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 10)
        _m5 = VariableVectorGatherModule([0] * 10)
        _m8 = SharedLinearFormModule(None, [[0.0] * 10 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m19 = LastDimSliceModule(0, 1)
        _m21 = LastDimSliceModule(2, 3)
        _m23 = LastDimSliceModule(3, 4)
        _m25 = LastDimSliceModule(4, 5)
        _m27 = LastDimSliceModule(5, 6)
        _m29 = LastDimSliceModule(6, 7)
        _m31 = LastDimSliceModule(7, 8)
        _m33 = LastDimSliceModule(8, 9)
        _m35 = LastDimSliceModule(9, 10)
        _m37 = LastDimSliceModule(1, 2)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m18 = VectorUnaryOpModule(_m19, 'cos')
        _m20 = VectorUnaryOpModule(_m21, 'cos')
        _m22 = VectorUnaryOpModule(_m23, 'cos')
        _m24 = VectorUnaryOpModule(_m25, 'cos')
        _m26 = VectorUnaryOpModule(_m27, 'cos')
        _m28 = VectorUnaryOpModule(_m29, 'cos')
        _m30 = VectorUnaryOpModule(_m31, 'cos')
        _m32 = VectorUnaryOpModule(_m33, 'cos')
        _m34 = VectorUnaryOpModule(_m35, 'cos')
        _m36 = VectorUnaryOpModule(_m37, 'cos')
        _m2 = VectorScaleModule(_m3, 0.00025, dtype=torch.float64)
        _m17 = VectorBinaryOpModule(_m18, _m20, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m16 = VectorBinaryOpModule(_m17, _m22, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m24, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m26, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m28, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m30, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m32, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m34, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m36, 'mul')
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m6 = VectorScaleModule(_m7, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m6, _m38])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
