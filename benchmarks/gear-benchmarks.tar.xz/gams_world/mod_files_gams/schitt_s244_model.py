"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS244Model
  model = SchittS244Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class SchittS244Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s244_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m7 = LastDimSliceModule(1, 2)
        _m9 = LastDimSliceModule(0, 1)
        _m11 = LastDimSliceModule(2, 3)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 2)
        _m25 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorUnaryOpModule(_m7, 'exp')
        _m10 = VectorUnaryOpModule(_m11, 'exp')
        _m19 = VectorUnaryOpModule(_m20, 'exp')
        _m22 = VectorUnaryOpModule(_m23, 'exp')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m24, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m8, 'sub')
        _m18 = VectorBinaryOpModule(_m19, _m21, 'sub')
        _m4 = VectorBinaryOpModule(_m5, _m12, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m25, 'sub')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m26, 'pow')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m15 = VectorScaleModule(_m16, 1, dtype=torch.float64)
        _m14 = VectorReduceModule(_m15, 'sum')
        _m0 = VectorSumModule([_m1, _m14])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
