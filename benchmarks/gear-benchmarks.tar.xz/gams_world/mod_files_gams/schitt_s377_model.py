"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS377Model
  model = SchittS377Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class SchittS377Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s377_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 10, [[0.0] * 10 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 10)
        _m8 = ConstantVectorModule([0.0] * 10, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 10)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 10)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 10)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 10)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 10)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 10)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 10)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 10)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 10)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 10)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 10)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m26, 'add')
        _m21 = VectorBinaryOpModule(_m22, _m29, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m32, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m35, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m38, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m41, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m44, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m47, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m50, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'div')
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 10, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], [[0] * 10], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
