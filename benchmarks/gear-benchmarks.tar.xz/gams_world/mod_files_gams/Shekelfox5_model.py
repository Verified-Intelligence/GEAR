"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Shekelfox5Model
  model = Shekelfox5Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule

class Shekelfox5Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Shekelfox5_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m4 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m6 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m12 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m17, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m20, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m23, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'div')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
