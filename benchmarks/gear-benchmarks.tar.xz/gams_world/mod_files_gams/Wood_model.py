"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import WoodModel
  model = WoodModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class WoodModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Wood_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m8 = VariableVectorGatherModule([0] * 2)
        _m9 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m15 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m19 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m24 = LastDimSliceModule(0, 1)
        _m25 = LastDimSliceModule(1, 2)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m12 = VectorScaleModule(_m13, 1, dtype=torch.float64)
        _m17 = VectorScaleModule(_m18, 10.1, dtype=torch.float64)
        _m21 = SharedLinearSingleCoreModule(_m22, _m23)
        _m4 = VectorBinaryOpModule(_m5, _m10, 'pow')
        _m11 = VectorReduceModule(_m12, 'sum')
        _m16 = VectorReduceModule(_m17, 'sum')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m11, _m16, _m21])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
