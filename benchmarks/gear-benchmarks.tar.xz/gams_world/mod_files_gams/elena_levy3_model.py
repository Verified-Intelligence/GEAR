"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaLevy3Model
  model = ElenaLevy3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorUnaryOpModule

class ElenaLevy3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_levy3_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = LastDimSliceModule(0, 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = LastDimSliceModule(1, 2)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = LastDimSliceModule(2, 3)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = LastDimSliceModule(3, 4)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = LastDimSliceModule(4, 5)
        _m31 = LastDimSliceModule(5, 6)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = LastDimSliceModule(6, 7)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = LastDimSliceModule(7, 8)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = LastDimSliceModule(8, 9)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = LastDimSliceModule(9, 10)
        _m8 = VectorUnaryOpModule(_m9, 'cos')
        _m12 = VectorUnaryOpModule(_m13, 'cos')
        _m16 = VectorUnaryOpModule(_m17, 'cos')
        _m20 = VectorUnaryOpModule(_m21, 'cos')
        _m24 = VectorUnaryOpModule(_m25, 'cos')
        _m30 = VectorUnaryOpModule(_m31, 'cos')
        _m34 = VectorUnaryOpModule(_m35, 'cos')
        _m38 = VectorUnaryOpModule(_m39, 'cos')
        _m42 = VectorUnaryOpModule(_m43, 'cos')
        _m46 = VectorUnaryOpModule(_m47, 'cos')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m10, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m32, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m14, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m36, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m18, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m40, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m22, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m44, 'add')
        _m3 = VectorUnaryOpModule(_m4, 'neg')
        _m2 = VectorBinaryOpModule(_m3, _m26, 'mul')
        _m0 = SharedLinearSingleCoreModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
