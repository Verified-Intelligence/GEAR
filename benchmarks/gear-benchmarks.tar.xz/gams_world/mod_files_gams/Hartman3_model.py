"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hartman3Model
  model = Hartman3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule, VectorUnaryOpModule

class Hartman3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Hartman3_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m7 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m9 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m19 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m11, 'sub')
        _m4 = VectorBinaryOpModule(_m5, _m16, 'sub')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
