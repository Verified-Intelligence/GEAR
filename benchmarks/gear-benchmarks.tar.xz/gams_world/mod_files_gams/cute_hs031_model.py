"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs031Model
  model = CuteHs031Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorSumModule

class CuteHs031Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs031_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 3)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m12 = LastDimSliceModule(1, 2)
        _m13 = LastDimSliceModule(0, 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m9 = SharedLinearSingleCoreModule(_m10, _m11)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = VectorSumModule([_m8, _m9])
        _m0 = CombinedASTModule([_m1, _m7], [('scalar_at', 0, 0), ('scalar_at', 1, 1)], 2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
