"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHimmelp5Model
  model = CuteHimmelp5Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHimmelp5Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_himmelp5_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 4)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 1)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 1)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 1)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 1)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 1)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 1)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 1)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m90 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m91 = VariableVectorGatherModule([0] * 1)
        _m93 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m96 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m97 = VariableVectorGatherModule([0] * 1)
        _m98 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m101 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m102 = VariableVectorGatherModule([0] * 1)
        _m103 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m108 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m109 = VariableVectorGatherModule([0] * 1)
        _m111 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m112 = VariableVectorGatherModule([0] * 1)
        _m116 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m117 = VariableVectorGatherModule([0] * 1)
        _m119 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m120 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m89 = VectorBinaryOpModule(_m90, _m91, 'mul')
        _m95 = VectorBinaryOpModule(_m96, _m97, 'mul')
        _m100 = VectorBinaryOpModule(_m101, _m102, 'mul')
        _m107 = VectorBinaryOpModule(_m108, _m109, 'mul')
        _m110 = VectorBinaryOpModule(_m111, _m112, 'mul')
        _m115 = VectorBinaryOpModule(_m116, _m117, 'mul')
        _m118 = VectorBinaryOpModule(_m119, _m120, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'pow')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'pow')
        _m40 = VectorBinaryOpModule(_m41, _m44, 'pow')
        _m47 = VectorBinaryOpModule(_m48, _m51, 'pow')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'add')
        _m69 = VectorBinaryOpModule(_m70, _m73, 'pow')
        _m76 = VectorBinaryOpModule(_m77, _m80, 'pow')
        _m81 = VectorBinaryOpModule(_m82, _m85, 'pow')
        _m94 = VectorBinaryOpModule(_m95, _m98, 'pow')
        _m99 = VectorBinaryOpModule(_m100, _m103, 'pow')
        _m106 = VectorBinaryOpModule(_m107, _m110, 'mul')
        _m114 = VectorBinaryOpModule(_m115, _m118, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 2, dtype=torch.float64)
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 2, dtype=torch.float64)
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'div')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'mul')
        _m105 = VectorUnaryOpModule(_m106, 'exp')
        _m113 = ResidualBucketScatterAddModule(_m114, [0.0] * 1, dtype=torch.float64)
        _m27 = VectorBinaryOpModule(_m28, _m31, 'add')
        _m52 = ResidualBucketScatterAddModule(_m53, [0.0] * 1, dtype=torch.float64)
        _m63 = VectorBinaryOpModule(_m64, _m67, 'add')
        _m88 = VectorBinaryOpModule(_m89, _m92, 'add')
        _m104 = ResidualBucketScatterAddModule(_m105, [0.0] * 1, dtype=torch.float64)
        _m26 = VectorBinaryOpModule(_m27, _m38, 'add')
        _m62 = VectorBinaryOpModule(_m63, _m74, 'add')
        _m87 = VectorBinaryOpModule(_m88, _m99, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m45, 'add')
        _m61 = VectorBinaryOpModule(_m62, _m81, 'mul')
        _m86 = ResidualBucketScatterAddModule(_m87, [0.0] * 1, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m25, 'mul')
        _m60 = ResidualBucketScatterAddModule(_m61, [0.0] * 1, dtype=torch.float64)
        _m20 = ResidualBucketScatterAddModule(_m21, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m14, _m20, _m52, _m60, _m86, _m104, _m113], [[0] * 4, [0] * 2, [0] * 2, [0] * 1, [0] * 1, [0] * 1, [0] * 1, [0] * 1, [0] * 1], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
