"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs025Model
  model = CuteHs025Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class CuteHs025Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs025_model_state.pt'

        _m10 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(99)], [0.0] * 99, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 99)
        _m12 = VariableVectorGatherModule([0] * 99)
        _m13 = ConstantVectorModule([0.0] * 99, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m11, 'mul')
        _m7 = VectorUnaryOpModule(_m8, 'exp')
        _m6 = VectorUnaryOpModule(_m7, 'neg')
        _m5 = VectorBinaryOpModule(_m6, _m12, 'div')
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'sub')
        _m2 = VectorBinaryOpModule(_m3, _m14, 'pow')
        _m1 = VectorScaleModule(_m2, 1, dtype=torch.float64)
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
