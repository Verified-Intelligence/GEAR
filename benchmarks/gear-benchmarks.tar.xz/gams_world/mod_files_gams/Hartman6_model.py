"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hartman6Model
  model = Hartman6Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule, VectorUnaryOpModule

class Hartman6Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Hartman6_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m10 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m12 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m17 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m22 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m27 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m32 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m37 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'pow')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'pow')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m14, 'sub')
        _m7 = VectorBinaryOpModule(_m8, _m19, 'sub')
        _m6 = VectorBinaryOpModule(_m7, _m24, 'sub')
        _m5 = VectorBinaryOpModule(_m6, _m29, 'sub')
        _m4 = VectorBinaryOpModule(_m5, _m34, 'sub')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
