"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SalomonModel
  model = SalomonModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class SalomonModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Salomon_model_state.pt'

        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m12 = VariableVectorGatherModule([0] * 1)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m33 = VariableVectorGatherModule([0] * 1)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m38 = VariableVectorGatherModule([0] * 1)
        _m39 = VariableVectorGatherModule([0] * 1)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m42 = VariableVectorGatherModule([0] * 1)
        _m44 = VariableVectorGatherModule([0] * 1)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'add')
        _m30 = VectorBinaryOpModule(_m31, _m34, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m13, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m37, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m16, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m40, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m19, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m43, 'add')
        _m2 = VectorUnaryOpModule(_m3, 'sqrt')
        _m26 = VectorUnaryOpModule(_m27, 'sqrt')
        _m1 = VectorScaleModule(_m2, 0.1, dtype=torch.float64)
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m23 = VectorUnaryOpModule(_m24, 'cos')
        _m22 = VectorScaleModule(_m23, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m22, _m46])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
