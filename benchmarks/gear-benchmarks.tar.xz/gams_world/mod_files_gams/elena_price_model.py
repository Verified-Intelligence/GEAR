"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaPriceModel
  model = ElenaPriceModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule, VectorUnaryOpModule

class ElenaPriceModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_price_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 1)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m21 = LastDimSliceModule(0, 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = LastDimSliceModule(0, 1)
        _m24 = LastDimSliceModule(1, 2)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m19 = VectorUnaryOpModule(_m20, 'neg')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m23, 'add')
        _m2 = VectorBinaryOpModule(_m3, _m10, 'sub')
        _m17 = VectorBinaryOpModule(_m18, _m24, 'add')
        _m1 = VectorBinaryOpModule(_m2, _m13, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m25, 'pow')
        _m14 = SharedLinearSingleCoreModule(_m15, _m16)
        _m0 = VectorSumModule([_m1, _m14])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
