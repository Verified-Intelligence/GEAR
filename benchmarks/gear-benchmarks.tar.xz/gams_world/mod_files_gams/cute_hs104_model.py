"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs104Model
  model = CuteHs104Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHs104Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs104_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 6)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 6)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 2)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 2)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 2)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 2)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 2)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 2)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = VariableVectorGatherModule([0] * 2)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m59 = VectorBinaryOpModule(_m60, _m61, 'mul')
        _m9 = VectorUnaryOpModule(_m10, 'log')
        _m16 = VectorUnaryOpModule(_m17, 'log')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m33, 'div')
        _m43 = VectorUnaryOpModule(_m44, 'log')
        _m58 = VectorUnaryOpModule(_m59, 'log')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m20 = ResidualBucketScatterAddModule(_m21, [0.0] * 2, dtype=torch.float64)
        _m28 = ResidualBucketScatterAddModule(_m29, [0.0] * 2, dtype=torch.float64)
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m6 = VectorUnaryOpModule(_m7, 'exp')
        _m13 = VectorUnaryOpModule(_m14, 'exp')
        _m40 = VectorUnaryOpModule(_m41, 'exp')
        _m55 = VectorUnaryOpModule(_m56, 'exp')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m47, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m55, 'div')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'div')
        _m50 = ResidualBucketScatterAddModule(_m51, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 6, dtype=torch.float64)
        _m36 = ResidualBucketScatterAddModule(_m37, [0.0] * 2, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m20, _m28, _m36, _m50], [[0] * 6, [0] * 2, [0] * 2, [0] * 2, [0] * 2], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
