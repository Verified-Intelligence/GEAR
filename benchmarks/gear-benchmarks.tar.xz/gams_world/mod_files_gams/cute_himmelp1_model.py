"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHimmelp1Model
  model = CuteHimmelp1Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteHimmelp1Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_himmelp1_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 2)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 2)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 2)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m23 = LastDimSliceModule(1, 2)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = LastDimSliceModule(0, 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = LastDimSliceModule(2, 3)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = LastDimSliceModule(0, 1)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = LastDimSliceModule(0, 1)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = LastDimSliceModule(0, 1)
        _m50 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = LastDimSliceModule(0, 1)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = LastDimSliceModule(2, 3)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = LastDimSliceModule(0, 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = LastDimSliceModule(1, 2)
        _m67 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m70 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = LastDimSliceModule(0, 1)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = LastDimSliceModule(2, 3)
        _m80 = LastDimSliceModule(1, 2)
        _m81 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m87 = LastDimSliceModule(1, 2)
        _m88 = LastDimSliceModule(0, 1)
        _m91 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m92 = VariableVectorGatherModule([0] * 2)
        _m94 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'pow')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'pow')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'pow')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'div')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'pow')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'pow')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'pow')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'pow')
        _m79 = VectorBinaryOpModule(_m80, _m81, 'pow')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m90 = VectorBinaryOpModule(_m91, _m92, 'mul')
        _m93 = VectorScaleModule(_m94, -1, dtype=torch.float64)
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m43 = SharedLinearSingleCoreModule(_m44, _m45)
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m75, 'mul')
        _m85 = VectorUnaryOpModule(_m86, 'exp')
        _m89 = VectorReduceModule(_m90, 'sum')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = VectorReduceModule(_m8, 'sum')
        _m13 = VectorReduceModule(_m14, 'sum')
        _m26 = VectorBinaryOpModule(_m27, _m32, 'add')
        _m53 = VectorBinaryOpModule(_m54, _m59, 'add')
        _m72 = VectorBinaryOpModule(_m73, _m78, 'sub')
        _m83 = SharedLinearSingleCoreModule(_m84, _m85)
        _m25 = VectorBinaryOpModule(_m26, _m33, 'add')
        _m52 = VectorBinaryOpModule(_m53, _m60, 'sub')
        _m71 = VectorBinaryOpModule(_m72, _m79, 'mul')
        _m82 = VectorScaleModule(_m83, 2.8673112392, dtype=torch.float64)
        _m24 = VectorBinaryOpModule(_m25, _m38, 'sub')
        _m51 = VectorBinaryOpModule(_m52, _m65, 'mul')
        _m69 = SharedLinearSingleCoreModule(_m70, _m71)
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m49 = SharedLinearSingleCoreModule(_m50, _m51)
        _m68 = VectorScaleModule(_m69, -1, dtype=torch.float64)
        _m20 = SharedLinearSingleCoreModule(_m21, _m22)
        _m48 = VectorScaleModule(_m49, -1, dtype=torch.float64)
        _m19 = VectorScaleModule(_m20, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m7, _m13, _m19, _m43, _m48, _m68, _m82, _m89, _m93])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
