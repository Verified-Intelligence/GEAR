"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHongModel
  model = CuteHongModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHongModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hong_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 4, [[0.0] * 4 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 3)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m8 = VectorUnaryOpModule(_m9, 'exp')
        _m7 = ResidualBucketScatterAddModule(_m8, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m7], [[0] * 3, [0] * 1], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
