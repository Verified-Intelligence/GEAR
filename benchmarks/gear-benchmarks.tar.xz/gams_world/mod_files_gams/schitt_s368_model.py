"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS368Model
  model = SchittS368Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class SchittS368Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s368_model_state.pt'

        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 1)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 1)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 1)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 1)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 1)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 1)
        _m60 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 1)
        _m63 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 1)
        _m66 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = VariableVectorGatherModule([0] * 1)
        _m76 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 1)
        _m79 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 1)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 1)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m87 = VariableVectorGatherModule([0] * 1)
        _m88 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m90 = VariableVectorGatherModule([0] * 1)
        _m91 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m93 = VariableVectorGatherModule([0] * 1)
        _m94 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m96 = VariableVectorGatherModule([0] * 1)
        _m97 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'pow')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'pow')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'pow')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'pow')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'pow')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'pow')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'pow')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'pow')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'pow')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'pow')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'pow')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'pow')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'pow')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'pow')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'pow')
        _m83 = VectorBinaryOpModule(_m84, _m85, 'pow')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'pow')
        _m89 = VectorBinaryOpModule(_m90, _m91, 'pow')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'pow')
        _m95 = VectorBinaryOpModule(_m96, _m97, 'pow')
        _m8 = VectorBinaryOpModule(_m9, _m12, 'add')
        _m42 = VectorBinaryOpModule(_m43, _m46, 'add')
        _m73 = VectorBinaryOpModule(_m74, _m77, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m15, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m49, 'add')
        _m72 = VectorBinaryOpModule(_m73, _m80, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m18, 'add')
        _m40 = VectorBinaryOpModule(_m41, _m52, 'add')
        _m71 = VectorBinaryOpModule(_m72, _m83, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m21, 'add')
        _m39 = VectorBinaryOpModule(_m40, _m55, 'add')
        _m70 = VectorBinaryOpModule(_m71, _m86, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m24, 'add')
        _m38 = VectorBinaryOpModule(_m39, _m58, 'add')
        _m69 = VectorBinaryOpModule(_m70, _m89, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m27, 'add')
        _m37 = VectorBinaryOpModule(_m38, _m61, 'add')
        _m68 = VectorBinaryOpModule(_m69, _m92, 'add')
        _m2 = VectorBinaryOpModule(_m3, _m30, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m64, 'add')
        _m67 = VectorBinaryOpModule(_m68, _m95, 'add')
        _m1 = VectorBinaryOpModule(_m2, _m33, 'pow')
        _m35 = VectorBinaryOpModule(_m36, _m67, 'mul')
        _m34 = VectorScaleModule(_m35, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m34])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
