"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Neumaier3Model
  model = Neumaier3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class Neumaier3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Neumaier3_model_state.pt'

        _m4 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m9 = LastDimSliceModule(1, 2)
        _m10 = LastDimSliceModule(0, 1)
        _m14 = VariableVectorGatherModule([0] * 8)
        _m15 = VariableVectorGatherModule([0] * 8)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m6 = SharedLinearSingleCoreModule(_m7, _m8)
        _m12 = VectorScaleModule(_m13, -1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m11 = VectorReduceModule(_m12, 'sum')
        _m0 = VectorSumModule([_m1, _m6, _m11])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
