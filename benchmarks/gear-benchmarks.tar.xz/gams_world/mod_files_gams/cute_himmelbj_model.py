"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHimmelbjModel
  model = CuteHimmelbjModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHimmelbjModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_himmelbj_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 45, [[0.0] * 45 for _ in range(33)], [0.0] * 33, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 45)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 45)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 45)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 45)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 45)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 45)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 45)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 45)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = VariableVectorGatherModule([0] * 45)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 45)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 45)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 45)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 45)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 45)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m69 = VariableVectorGatherModule([0] * 45)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 45)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = VariableVectorGatherModule([0] * 45)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 45)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 45)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 45)
        _m86 = ConstantVectorModule([0.0] * 45, dtype=torch.float64)
        _m87 = VariableVectorGatherModule([0] * 45)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m75, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m79 = VectorBinaryOpModule(_m80, _m81, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m85 = VectorBinaryOpModule(_m86, _m87, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'log')
        _m30 = VectorBinaryOpModule(_m31, _m34, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m8, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m37, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 45, dtype=torch.float64)
        _m28 = VectorBinaryOpModule(_m29, _m40, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m43, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m46, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m49, 'add')
        _m24 = VectorBinaryOpModule(_m25, _m52, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m55, 'add')
        _m22 = VectorBinaryOpModule(_m23, _m58, 'add')
        _m21 = VectorBinaryOpModule(_m22, _m61, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m64, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m67, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m70, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m73, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m76, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m79, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m82, 'add')
        _m13 = VectorUnaryOpModule(_m14, 'log')
        _m12 = VectorBinaryOpModule(_m13, _m85, 'mul')
        _m11 = ResidualBucketScatterAddModule(_m12, [0.0] * 45, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m11], [[0] * 45, [0] * 45], 33, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 33
