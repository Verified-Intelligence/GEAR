"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteSinealiModel
  model = CuteSinealiModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteSinealiModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_sineali_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(0, 1)
        _m9 = VariableVectorGatherModule([0] * 19)
        _m12 = VariableVectorGatherModule([0] * 19)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorUnaryOpModule(_m4, 'sin')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m10 = VectorUnaryOpModule(_m11, 'neg')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'add')
        _m7 = VectorUnaryOpModule(_m8, 'sin')
        _m6 = VectorScaleModule(_m7, 100, dtype=torch.float64)
        _m5 = VectorReduceModule(_m6, 'sum')
        _m0 = VectorSumModule([_m1, _m5])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
