"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteLewispolModel
  model = CuteLewispolModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteLewispolModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_lewispol_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 7, [[0.0] * 7 for _ in range(15)], [0.0] * 15, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 7)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 2)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 2)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 2)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 2)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 2)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 2)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 2)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 2)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = VariableVectorGatherModule([0] * 2)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = VariableVectorGatherModule([0] * 2)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m69 = VariableVectorGatherModule([0] * 2)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 2)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = VariableVectorGatherModule([0] * 2)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 2)
        _m79 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 6)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m75, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'add')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'add')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'add')
        _m81 = VectorBinaryOpModule(_m82, _m85, 'pow')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 7, dtype=torch.float64)
        _m14 = VectorBinaryOpModule(_m15, _m20, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m47, 'add')
        _m64 = VectorBinaryOpModule(_m65, _m70, 'add')
        _m80 = ResidualBucketScatterAddModule(_m81, [0.0] * 6, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m23, 'add')
        _m40 = VectorBinaryOpModule(_m41, _m50, 'add')
        _m63 = VectorBinaryOpModule(_m64, _m73, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m26, 'add')
        _m39 = VectorBinaryOpModule(_m40, _m53, 'add')
        _m62 = VectorBinaryOpModule(_m63, _m76, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m29, 'add')
        _m38 = VectorBinaryOpModule(_m39, _m56, 'add')
        _m61 = VectorBinaryOpModule(_m62, _m79, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m32, 'add')
        _m37 = VectorBinaryOpModule(_m38, _m59, 'pow')
        _m60 = ResidualBucketScatterAddModule(_m61, [0.0] * 2, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m35, 'pow')
        _m36 = ResidualBucketScatterAddModule(_m37, [0.0] * 2, dtype=torch.float64)
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 2, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m36, _m60, _m80], [[0] * 7, [0] * 2, [0] * 2, [0] * 2, [0] * 6], 15, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 15
