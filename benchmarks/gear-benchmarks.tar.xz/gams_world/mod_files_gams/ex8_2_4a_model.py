"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex824aModel
  model = Ex824aModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex824aModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_2_4a_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 55, [[0.0] * 55 for _ in range(82)], [0.0] * 82, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 3)
        _m11 = ConstantVectorModule([0.0] * 150, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 150)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 150)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m9 = VectorUnaryOpModule(_m10, 'exp')
        _m8 = VectorBinaryOpModule(_m9, _m15, 'mul')
        _m7 = ResidualBucketScatterAddModule(_m8, [0.0] * 150, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m7], [[0] * 3, [0] * 150], 82, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 82
