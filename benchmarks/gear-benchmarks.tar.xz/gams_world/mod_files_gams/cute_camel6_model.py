"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteCamel6Model
  model = CuteCamel6Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class CuteCamel6Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_camel6_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 2)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 2)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m13 = VectorScaleModule(_m14, 0.333333333333333, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = VectorReduceModule(_m8, 'sum')
        _m0 = VectorSumModule([_m1, _m7, _m13, _m17])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
