"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs111Model
  model = CuteHs111Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, CombinedASTModule, ConstantVectorModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteHs111Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs111_model_state.pt'

        _m5 = VariableVectorGatherModule([0] * 10)
        _m7 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 10)
        _m16 = VariableVectorGatherModule([0] * 10)
        _m19 = VariableVectorGatherModule([0] * 10)
        _m22 = VariableVectorGatherModule([0] * 10)
        _m25 = VariableVectorGatherModule([0] * 10)
        _m28 = VariableVectorGatherModule([0] * 10)
        _m31 = VariableVectorGatherModule([0] * 10)
        _m34 = VariableVectorGatherModule([0] * 10)
        _m37 = VariableVectorGatherModule([0] * 10)
        _m39 = VariableVectorGatherModule([0] * 10)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 5)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 5)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 4)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m67 = VariableVectorGatherModule([0] * 4)
        _m69 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m74 = VariableVectorGatherModule([0] * 5)
        _m76 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 5)
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m12 = VectorUnaryOpModule(_m13, 'exp')
        _m15 = VectorUnaryOpModule(_m16, 'exp')
        _m18 = VectorUnaryOpModule(_m19, 'exp')
        _m21 = VectorUnaryOpModule(_m22, 'exp')
        _m24 = VectorUnaryOpModule(_m25, 'exp')
        _m27 = VectorUnaryOpModule(_m28, 'exp')
        _m30 = VectorUnaryOpModule(_m31, 'exp')
        _m33 = VectorUnaryOpModule(_m34, 'exp')
        _m36 = VectorUnaryOpModule(_m37, 'exp')
        _m38 = VectorUnaryOpModule(_m39, 'exp')
        _m45 = VectorUnaryOpModule(_m46, 'exp')
        _m52 = VectorUnaryOpModule(_m53, 'exp')
        _m59 = VectorUnaryOpModule(_m60, 'exp')
        _m66 = VectorUnaryOpModule(_m67, 'exp')
        _m73 = VectorUnaryOpModule(_m74, 'exp')
        _m80 = VectorUnaryOpModule(_m81, 'exp')
        _m35 = VectorBinaryOpModule(_m36, _m38, 'add')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m35, 'add')
        _m42 = VectorReduceModule(_m43, 'sum')
        _m49 = VectorReduceModule(_m50, 'sum')
        _m56 = VectorReduceModule(_m57, 'sum')
        _m63 = VectorReduceModule(_m64, 'sum')
        _m70 = VectorReduceModule(_m71, 'sum')
        _m77 = VectorReduceModule(_m78, 'sum')
        _m29 = VectorBinaryOpModule(_m30, _m32, 'add')
        _m40 = VectorSumModule([_m41, _m42])
        _m47 = VectorSumModule([_m48, _m49])
        _m54 = VectorSumModule([_m55, _m56])
        _m61 = VectorSumModule([_m62, _m63])
        _m68 = VectorSumModule([_m69, _m70])
        _m75 = VectorSumModule([_m76, _m77])
        _m26 = VectorBinaryOpModule(_m27, _m29, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m26, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m23, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m20, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m17, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m14, 'add')
        _m10 = VectorUnaryOpModule(_m11, 'log')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m6, 'mul')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = CombinedASTModule([_m1, _m40, _m47, _m54, _m61, _m68, _m75], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2), ('scalar_at', 3, 3), ('scalar_at', 4, 4), ('scalar_at', 5, 5), ('scalar_at', 6, 6)], 7)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
