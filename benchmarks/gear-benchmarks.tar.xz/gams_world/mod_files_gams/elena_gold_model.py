"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaGoldModel
  model = ElenaGoldModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class ElenaGoldModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_gold_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = LastDimSliceModule(3, 4)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 1)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 1)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = VariableVectorGatherModule([0] * 1)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 1)
        _m67 = LastDimSliceModule(2, 3)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'pow')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'pow')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'pow')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'pow')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'mul')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m20, 'sub')
        _m54 = VectorBinaryOpModule(_m55, _m60, 'sub')
        _m13 = VectorBinaryOpModule(_m14, _m23, 'sub')
        _m48 = VectorBinaryOpModule(_m49, _m54, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'add')
        _m47 = VectorBinaryOpModule(_m48, _m63, 'sub')
        _m8 = VectorBinaryOpModule(_m9, _m28, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m47, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'add')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m33, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m66, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'add')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'add')
        _m2 = VectorBinaryOpModule(_m3, _m36, 'mul')
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
