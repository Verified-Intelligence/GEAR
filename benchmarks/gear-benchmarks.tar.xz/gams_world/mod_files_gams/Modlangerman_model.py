"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ModlangermanModel
  model = ModlangermanModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule, VectorUnaryOpModule

class ModlangermanModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Modlangerman_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m70 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m82 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m85 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m86 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m88 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m89 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'pow')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'pow')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'pow')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'pow')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'pow')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'pow')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'pow')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'pow')
        _m69 = VectorBinaryOpModule(_m70, _m71, 'pow')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'pow')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'pow')
        _m78 = VectorBinaryOpModule(_m79, _m80, 'pow')
        _m81 = VectorBinaryOpModule(_m82, _m83, 'pow')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'pow')
        _m87 = VectorBinaryOpModule(_m88, _m89, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m59 = VectorBinaryOpModule(_m60, _m63, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m22, 'add')
        _m58 = VectorBinaryOpModule(_m59, _m66, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m25, 'add')
        _m57 = VectorBinaryOpModule(_m58, _m69, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m28, 'add')
        _m56 = VectorBinaryOpModule(_m57, _m72, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m31, 'add')
        _m55 = VectorBinaryOpModule(_m56, _m75, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m34, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m78, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m37, 'add')
        _m53 = VectorBinaryOpModule(_m54, _m81, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m40, 'add')
        _m52 = VectorBinaryOpModule(_m53, _m84, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m43, 'add')
        _m51 = VectorBinaryOpModule(_m52, _m87, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'cos')
        _m48 = VectorUnaryOpModule(_m49, 'exp')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m46, 'mul')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
