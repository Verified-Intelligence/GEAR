"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import PeriodicModel
  model = PeriodicModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class PeriodicModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Periodic_model_state.pt'

        _m5 = VariableVectorGatherModule([0] * 2)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m13 = LastDimSliceModule(2, 3)
        _m14 = LastDimSliceModule(0, 1)
        _m16 = LastDimSliceModule(1, 2)
        _m17 = LastDimSliceModule(1, 2)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorUnaryOpModule(_m5, 'sin')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m6, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'sub')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m10 = VectorUnaryOpModule(_m11, 'exp')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m8 = SharedLinearSingleCoreModule(_m9, _m10)
        _m7 = VectorScaleModule(_m8, -0.1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m7, _m18])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
