"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs087Model
  model = Hs087Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Hs087Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs087_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 4)
        _m9 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m11 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m15 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 4)
        _m20 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 4)
        _m24 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m27 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 4)
        _m32 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 4)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 1)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 1)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = VariableVectorGatherModule([0] * 1)
        _m66 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = VariableVectorGatherModule([0] * 1)
        _m70 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 1)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 1)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m87 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m88 = VariableVectorGatherModule([0] * 1)
        _m90 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m91 = VariableVectorGatherModule([0] * 1)
        _m95 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m96 = VariableVectorGatherModule([0] * 8)
        _m97 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m102 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m105 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m107 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m108 = VariableVectorGatherModule([0] * 4)
        _m110 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m111 = VariableVectorGatherModule([0] * 4)
        _m113 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m114 = VariableVectorGatherModule([0] * 4)
        _m119 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m122 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m124 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m125 = VariableVectorGatherModule([0] * 4)
        _m127 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m128 = VariableVectorGatherModule([0] * 4)
        _m130 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m131 = VariableVectorGatherModule([0] * 4)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'mul')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m89 = VectorBinaryOpModule(_m90, _m91, 'mul')
        _m94 = VectorBinaryOpModule(_m95, _m96, 'mul')
        _m106 = VectorBinaryOpModule(_m107, _m108, 'mul')
        _m109 = VectorBinaryOpModule(_m110, _m111, 'mul')
        _m112 = VectorBinaryOpModule(_m113, _m114, 'mul')
        _m123 = VectorBinaryOpModule(_m124, _m125, 'mul')
        _m126 = VectorBinaryOpModule(_m127, _m128, 'mul')
        _m129 = VectorBinaryOpModule(_m130, _m131, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'add')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'add')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'add')
        _m93 = VectorBinaryOpModule(_m94, _m97, 'pow')
        _m104 = VectorBinaryOpModule(_m105, _m106, 'add')
        _m121 = VectorBinaryOpModule(_m122, _m123, 'add')
        _m13 = VectorUnaryOpModule(_m14, 'abs')
        _m25 = VectorUnaryOpModule(_m26, 'abs')
        _m40 = VectorUnaryOpModule(_m41, 'abs')
        _m59 = VectorUnaryOpModule(_m60, 'abs')
        _m71 = VectorUnaryOpModule(_m72, 'abs')
        _m83 = VectorUnaryOpModule(_m84, 'abs')
        _m92 = ResidualBucketScatterAddModule(_m93, [0.0] * 8, dtype=torch.float64)
        _m103 = VectorUnaryOpModule(_m104, 'cos')
        _m120 = VectorUnaryOpModule(_m121, 'sin')
        _m12 = VectorBinaryOpModule(_m13, _m19, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'add')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'add')
        _m58 = VectorBinaryOpModule(_m59, _m65, 'add')
        _m69 = VectorBinaryOpModule(_m70, _m71, 'add')
        _m81 = VectorBinaryOpModule(_m82, _m83, 'add')
        _m101 = VectorBinaryOpModule(_m102, _m103, 'mul')
        _m118 = VectorBinaryOpModule(_m119, _m120, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m31, 'add')
        _m37 = VectorBinaryOpModule(_m38, _m46, 'add')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m77, 'add')
        _m80 = VectorBinaryOpModule(_m81, _m89, 'add')
        _m100 = VectorBinaryOpModule(_m101, _m109, 'mul')
        _m117 = VectorBinaryOpModule(_m118, _m126, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'add')
        _m99 = VectorBinaryOpModule(_m100, _m112, 'mul')
        _m116 = VectorBinaryOpModule(_m117, _m129, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m54, 'mul')
        _m98 = ResidualBucketScatterAddModule(_m99, [0.0] * 4, dtype=torch.float64)
        _m115 = ResidualBucketScatterAddModule(_m116, [0.0] * 4, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m22, 'div')
        _m49 = VectorBinaryOpModule(_m50, _m68, 'div')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m36 = VectorBinaryOpModule(_m37, _m49, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m80, 'div')
        _m34 = ResidualBucketScatterAddModule(_m35, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m34, _m92, _m98, _m115], [[0] * 4, [0] * 1, [0] * 8, [0] * 4, [0] * 4], 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
