"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex836Model
  model = Ex836Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex836Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_6_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 66, [[0.0] * 66 for _ in range(153)], [0.0] * 153, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m15 = ConstantVectorModule([0.0] * 408, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 408)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 408)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 10)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 10)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 10)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 10)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m17, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'div')
        _m12 = ResidualBucketScatterAddModule(_m13, [0.0] * 408, dtype=torch.float64)
        _m25 = VectorBinaryOpModule(_m26, _m33, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m21 = VectorBinaryOpModule(_m22, _m25, 'mul')
        _m20 = ResidualBucketScatterAddModule(_m21, [0.0] * 10, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m12, _m20], [[0] * 1, [0] * 408, [0] * 10], 153, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 153
