"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteExplinModel
  model = CuteExplinModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, ConstantVectorModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteExplinModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_explin_model_state.pt'

        _m5 = VariableVectorGatherModule([0] * 10)
        _m6 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = ConstantVectorModule([0.0] * 120, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 120)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m7 = VectorReduceModule(_m8, 'sum')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m7])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
