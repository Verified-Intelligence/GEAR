"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteTwobarsModel
  model = CuteTwobarsModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule, VectorUnaryOpModule

class CuteTwobarsModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_twobars_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m42 = VariableVectorGatherModule([0] * 1)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 1)
        _m50 = VariableVectorGatherModule([0] * 1)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'div')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'div')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'div')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'add')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'div')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'add')
        _m2 = VectorUnaryOpModule(_m3, 'sqrt')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'add')
        _m23 = VectorUnaryOpModule(_m24, 'sqrt')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m45 = VectorUnaryOpModule(_m46, 'sqrt')
        _m1 = VectorBinaryOpModule(_m2, _m8, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m36, 'add')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m21, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m43, 'mul')
        _m9 = VectorSumModule([_m10, _m11])
        _m29 = VectorSumModule([_m30, _m31])
        _m0 = CombinedASTModule([_m1, _m9, _m29], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
