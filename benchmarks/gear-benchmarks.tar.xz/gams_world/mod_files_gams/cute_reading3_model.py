"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteReading3Model
  model = CuteReading3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteReading3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_reading3_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 202, [[0.0] * 202 for _ in range(204)], [0.0] * 204, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 400, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 400)
        _m9 = ConstantVectorModule([0.0] * 400, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 400)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 400)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 400)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m13, 'pow')
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 400, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 400, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m14], [[0] * 400, [0] * 400], 204, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 204
