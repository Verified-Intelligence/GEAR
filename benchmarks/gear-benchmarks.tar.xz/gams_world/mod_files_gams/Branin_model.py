"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import BraninModel
  model = BraninModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class BraninModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Branin_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m8 = LastDimSliceModule(2, 3)
        _m9 = LastDimSliceModule(0, 1)
        _m10 = LastDimSliceModule(3, 4)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = LastDimSliceModule(1, 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m15 = VectorUnaryOpModule(_m16, 'cos')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'add')
        _m14 = VectorScaleModule(_m15, 9.60211264227029, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m11, 'sub')
        _m4 = VectorBinaryOpModule(_m5, _m12, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'pow')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m0 = VectorSumModule([_m1, _m14, _m17])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
