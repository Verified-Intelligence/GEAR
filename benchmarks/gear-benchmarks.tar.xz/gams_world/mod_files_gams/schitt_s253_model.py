"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS253Model
  model = SchittS253Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class SchittS253Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s253_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 3)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 3)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 3)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = VariableVectorGatherModule([0] * 3)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m58 = VariableVectorGatherModule([0] * 3)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 3)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m74 = VariableVectorGatherModule([0] * 1)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 1)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m85 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m87 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m88 = VariableVectorGatherModule([0] * 1)
        _m89 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'mul')
        _m79 = VectorBinaryOpModule(_m80, _m81, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'add')
        _m32 = VectorBinaryOpModule(_m33, _m36, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'pow')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m64, 'pow')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'add')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'add')
        _m84 = VectorBinaryOpModule(_m85, _m86, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m11, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m31, 'pow')
        _m46 = VectorBinaryOpModule(_m47, _m52, 'pow')
        _m53 = VectorBinaryOpModule(_m54, _m59, 'pow')
        _m69 = VectorBinaryOpModule(_m70, _m75, 'pow')
        _m76 = VectorBinaryOpModule(_m77, _m82, 'pow')
        _m83 = VectorBinaryOpModule(_m84, _m89, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m16, 'add')
        _m24 = VectorBinaryOpModule(_m25, _m32, 'add')
        _m45 = VectorBinaryOpModule(_m46, _m53, 'add')
        _m68 = VectorBinaryOpModule(_m69, _m76, 'add')
        _m3 = VectorUnaryOpModule(_m4, 'sqrt')
        _m23 = VectorBinaryOpModule(_m24, _m37, 'add')
        _m44 = VectorBinaryOpModule(_m45, _m60, 'add')
        _m67 = VectorBinaryOpModule(_m68, _m83, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m22 = VectorUnaryOpModule(_m23, 'sqrt')
        _m43 = VectorUnaryOpModule(_m44, 'sqrt')
        _m66 = VectorUnaryOpModule(_m67, 'sqrt')
        _m21 = ResidualBucketScatterAddModule(_m22, [0.0] * 3, dtype=torch.float64)
        _m42 = ResidualBucketScatterAddModule(_m43, [0.0] * 3, dtype=torch.float64)
        _m65 = ResidualBucketScatterAddModule(_m66, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m21, _m42, _m65], [[0] * 1, [0] * 3, [0] * 3, [0] * 1], 2, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
