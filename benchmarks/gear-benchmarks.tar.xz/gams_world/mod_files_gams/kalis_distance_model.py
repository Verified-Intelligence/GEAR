"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import KalisDistanceModel
  model = KalisDistanceModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class KalisDistanceModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = True

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'kalis_distance_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 4)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 4)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m12, 'pow')
        _m14 = VectorUnaryOpModule(_m15, 'sqrt')
        _m3 = VectorUnaryOpModule(_m4, 'sqrt')
        _m13 = ResidualBucketScatterAddModule(_m14, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 4, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m13], [[0] * 4, [0] * 2], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
