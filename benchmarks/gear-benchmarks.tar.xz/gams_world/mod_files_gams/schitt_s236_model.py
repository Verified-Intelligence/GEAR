"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS236Model
  model = SchittS236Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class SchittS236Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s236_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 3)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 2)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 2)
        _m31 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 2)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 2)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 2)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 2)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 1)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 1)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 1)
        _m69 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = VariableVectorGatherModule([0] * 1)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 1)
        _m79 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m86 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m87 = VariableVectorGatherModule([0] * 1)
        _m88 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m91 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m92 = VariableVectorGatherModule([0] * 1)
        _m93 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m97 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m100 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m101 = VariableVectorGatherModule([0] * 1)
        _m102 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m105 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m106 = VariableVectorGatherModule([0] * 1)
        _m107 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m112 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m113 = VariableVectorGatherModule([0] * 1)
        _m115 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m116 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m63 = VectorBinaryOpModule(_m64, _m65, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m85 = VectorBinaryOpModule(_m86, _m87, 'mul')
        _m90 = VectorBinaryOpModule(_m91, _m92, 'mul')
        _m99 = VectorBinaryOpModule(_m100, _m101, 'mul')
        _m104 = VectorBinaryOpModule(_m105, _m106, 'mul')
        _m111 = VectorBinaryOpModule(_m112, _m113, 'mul')
        _m114 = VectorBinaryOpModule(_m115, _m116, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'pow')
        _m43 = VectorBinaryOpModule(_m44, _m47, 'pow')
        _m53 = VectorBinaryOpModule(_m54, _m57, 'pow')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'add')
        _m70 = VectorBinaryOpModule(_m71, _m74, 'pow')
        _m75 = VectorBinaryOpModule(_m76, _m79, 'pow')
        _m84 = VectorBinaryOpModule(_m85, _m88, 'pow')
        _m89 = VectorBinaryOpModule(_m90, _m93, 'pow')
        _m98 = VectorBinaryOpModule(_m99, _m102, 'pow')
        _m103 = VectorBinaryOpModule(_m104, _m107, 'pow')
        _m110 = VectorBinaryOpModule(_m111, _m114, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 2, dtype=torch.float64)
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 2, dtype=torch.float64)
        _m20 = ResidualBucketScatterAddModule(_m21, [0.0] * 2, dtype=torch.float64)
        _m29 = VectorBinaryOpModule(_m30, _m33, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m43, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m53, 'mul')
        _m59 = VectorBinaryOpModule(_m60, _m61, 'div')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m96 = VectorBinaryOpModule(_m97, _m98, 'mul')
        _m109 = VectorUnaryOpModule(_m110, 'exp')
        _m28 = ResidualBucketScatterAddModule(_m29, [0.0] * 2, dtype=torch.float64)
        _m38 = ResidualBucketScatterAddModule(_m39, [0.0] * 2, dtype=torch.float64)
        _m48 = ResidualBucketScatterAddModule(_m49, [0.0] * 1, dtype=torch.float64)
        _m58 = ResidualBucketScatterAddModule(_m59, [0.0] * 1, dtype=torch.float64)
        _m67 = VectorBinaryOpModule(_m68, _m75, 'mul')
        _m81 = VectorBinaryOpModule(_m82, _m89, 'mul')
        _m95 = VectorBinaryOpModule(_m96, _m103, 'mul')
        _m108 = ResidualBucketScatterAddModule(_m109, [0.0] * 1, dtype=torch.float64)
        _m66 = ResidualBucketScatterAddModule(_m67, [0.0] * 1, dtype=torch.float64)
        _m80 = ResidualBucketScatterAddModule(_m81, [0.0] * 1, dtype=torch.float64)
        _m94 = ResidualBucketScatterAddModule(_m95, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m14, _m20, _m28, _m38, _m48, _m58, _m66, _m80, _m94, _m108], [[0] * 3, [0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 1, [0] * 1, [0] * 1, [0] * 1, [0] * 1, [0] * 1], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
