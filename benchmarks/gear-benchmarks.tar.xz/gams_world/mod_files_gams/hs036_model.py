"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs036Model
  model = Hs036Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, LastDimSliceModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule

class Hs036Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs036_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m7 = LastDimSliceModule(2, 3)
        _m8 = LastDimSliceModule(0, 1)
        _m9 = LastDimSliceModule(1, 2)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'mul')
        _m3 = SharedLinearSingleCoreModule(_m4, _m5)
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 0)], 2)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 2, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
