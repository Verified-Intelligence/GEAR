"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import MeyerrothModel
  model = MeyerrothModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule

class MeyerrothModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'MeyerRoth_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = LastDimSliceModule(3, 4)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = LastDimSliceModule(5, 6)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m29 = LastDimSliceModule(4, 5)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 1)
        _m40 = LastDimSliceModule(6, 7)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m49 = LastDimSliceModule(1, 2)
        _m50 = LastDimSliceModule(0, 1)
        _m51 = LastDimSliceModule(2, 3)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'div')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m29, 'div')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m51, 'div')
        _m4 = VectorBinaryOpModule(_m5, _m10, 'sub')
        _m14 = VectorBinaryOpModule(_m15, _m20, 'div')
        _m24 = VectorBinaryOpModule(_m25, _m30, 'sub')
        _m34 = VectorBinaryOpModule(_m35, _m40, 'div')
        _m46 = VectorBinaryOpModule(_m47, _m52, 'sub')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m21, 'sub')
        _m23 = VectorBinaryOpModule(_m24, _m31, 'pow')
        _m33 = VectorBinaryOpModule(_m34, _m41, 'sub')
        _m45 = VectorBinaryOpModule(_m46, _m53, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m22, 'pow')
        _m32 = VectorBinaryOpModule(_m33, _m42, 'pow')
        _m43 = SharedLinearSingleCoreModule(_m44, _m45)
        _m2 = VectorSumModule([_m3, _m12, _m23, _m32, _m43])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
