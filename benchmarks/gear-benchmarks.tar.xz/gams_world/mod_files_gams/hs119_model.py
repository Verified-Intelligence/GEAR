"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs119Model
  model = Hs119Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Hs119Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs119_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 16, [[0.0] * 16 for _ in range(17)], [0.0] * 17, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 46)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 46)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 46)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 46)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'add')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m10, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m21, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m15, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 46, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], [[0] * 46], 17, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 17
