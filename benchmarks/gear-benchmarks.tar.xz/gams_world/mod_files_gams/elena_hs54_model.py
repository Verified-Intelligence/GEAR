"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaHs54Model
  model = ElenaHs54Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class ElenaHs54Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_hs54_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 2)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 2)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 2)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 2)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 2)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = ConstantVectorModule([0.0] * 6, dtype=torch.float64)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 6)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'add')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'add')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'add')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m21, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m28, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m39, 'pow')
        _m40 = VectorBinaryOpModule(_m41, _m46, 'pow')
        _m48 = VectorBinaryOpModule(_m49, _m54, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m47 = ResidualBucketScatterAddModule(_m48, [0.0] * 6, dtype=torch.float64)
        _m12 = VectorBinaryOpModule(_m13, _m22, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m33, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m40, 'mul')
        _m7 = ResidualBucketScatterAddModule(_m8, [0.0] * 2, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m7, _m47], [[0] * 1, [0] * 2, [0] * 6], 5, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
