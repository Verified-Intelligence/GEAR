"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteNuffieldContinuumModel
  model = CuteNuffieldContinuumModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteNuffieldContinuumModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_nuffield_continuum_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 3)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 1)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 1)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 1)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 1)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'add')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'add')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'add')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'pow')
        _m10 = ResidualBucketScatterAddModule(_m11, [0.0] * 1, dtype=torch.float64)
        _m27 = VectorBinaryOpModule(_m28, _m33, 'pow')
        _m38 = VectorBinaryOpModule(_m39, _m44, 'add')
        _m47 = VectorBinaryOpModule(_m48, _m53, 'pow')
        _m55 = VectorBinaryOpModule(_m56, _m61, 'pow')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m54 = ResidualBucketScatterAddModule(_m55, [0.0] * 1, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m25, 'add')
        _m35 = VectorBinaryOpModule(_m36, _m47, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m23, 'mul')
        _m34 = ResidualBucketScatterAddModule(_m35, [0.0] * 1, dtype=torch.float64)
        _m16 = ResidualBucketScatterAddModule(_m17, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m10, _m16, _m34, _m54], [[0] * 3, [0] * 1, [0] * 1, [0] * 1, [0] * 1], 2, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
