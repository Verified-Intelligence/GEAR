"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs074Model
  model = Hs074Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Hs074Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs074_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 4, [[0.0] * 4 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ConstantVectorModule([0.0] * 8, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 8)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 4)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 4)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m9 = VectorUnaryOpModule(_m10, 'sin')
        _m17 = VectorBinaryOpModule(_m18, _m23, 'add')
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 8, dtype=torch.float64)
        _m16 = VectorUnaryOpModule(_m17, 'sin')
        _m15 = ResidualBucketScatterAddModule(_m16, [0.0] * 4, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m15], [[0] * 2, [0] * 8, [0] * 4], 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
