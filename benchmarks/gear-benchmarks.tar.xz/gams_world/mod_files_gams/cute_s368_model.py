"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteS368Model
  model = CuteS368Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class CuteS368Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_s368_model_state.pt'

        _m5 = VariableVectorGatherModule([0] * 10000)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = BatchedAffineGatherModule([[0] * 1 for _ in range(10000)], [[0.0] * 1 for _ in range(10000)], [0.0] * 10000, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 10000)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 10000)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'pow')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'mul')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m11 = VectorScaleModule(_m12, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m10 = VectorReduceModule(_m11, 'sum')
        _m0 = VectorSumModule([_m1, _m10])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
