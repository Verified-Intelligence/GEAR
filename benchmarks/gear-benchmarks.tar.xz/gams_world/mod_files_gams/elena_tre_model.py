"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaTreModel
  model = ElenaTreModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class ElenaTreModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_tre_model_state.pt'

        _m2 = VariableVectorGatherModule([0] * 1)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m1 = VectorBinaryOpModule(_m2, _m3, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m4 = VectorScaleModule(_m5, 4, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m8 = VectorReduceModule(_m9, 'sum')
        _m0 = VectorSumModule([_m1, _m4, _m8])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
