"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs065Model
  model = CuteHs065Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class CuteHs065Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs065_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m6 = LastDimSliceModule(4, 5)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m11 = LastDimSliceModule(0, 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = LastDimSliceModule(3, 4)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 3)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m4 = VectorScaleModule(_m5, 0.111111111111111, dtype=torch.float64)
        _m8 = SharedLinearSingleCoreModule(_m9, _m10)
        _m19 = VectorScaleModule(_m20, 1, dtype=torch.float64)
        _m3 = VectorSumModule([_m4, _m8, _m13])
        _m18 = VectorReduceModule(_m19, 'sum')
        _m1 = SharedLinearAugmentModule(_m2, _m3)
        _m16 = VectorSumModule([_m17, _m18])
        _m0 = CombinedASTModule([_m1, _m16], [('scalar_at', 0, 0), ('scalar_at', 1, 1)], 2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
