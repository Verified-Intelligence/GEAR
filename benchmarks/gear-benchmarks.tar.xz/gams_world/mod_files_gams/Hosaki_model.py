"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import HosakiModel
  model = HosakiModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorUnaryOpModule

class HosakiModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Hosaki_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m5 = LastDimSliceModule(1, 2)
        _m11 = LastDimSliceModule(4, 5)
        _m12 = LastDimSliceModule(0, 1)
        _m13 = LastDimSliceModule(5, 6)
        _m16 = LastDimSliceModule(3, 4)
        _m17 = LastDimSliceModule(0, 1)
        _m18 = LastDimSliceModule(0, 1)
        _m22 = LastDimSliceModule(2, 3)
        _m23 = LastDimSliceModule(0, 1)
        _m24 = LastDimSliceModule(0, 1)
        _m25 = LastDimSliceModule(0, 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = LastDimSliceModule(1, 2)
        _m29 = LastDimSliceModule(6, 7)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m28 = VectorUnaryOpModule(_m29, 'exp')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'sub')
        _m14 = VectorBinaryOpModule(_m15, _m18, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m24, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m14, 'sub')
        _m19 = VectorBinaryOpModule(_m20, _m25, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m19, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m26, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m27, 'mul')
        _m2 = VectorBinaryOpModule(_m3, _m28, 'mul')
        _m0 = SharedLinearSingleCoreModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
