"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS329Model
  model = SchittS329Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class SchittS329Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s329_model_state.pt'

        _m4 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'pow')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m14 = VectorScaleModule(_m15, -1, dtype=torch.float64)
        _m21 = VectorScaleModule(_m22, 1, dtype=torch.float64)
        _m28 = VectorScaleModule(_m29, -1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m8 = VectorReduceModule(_m9, 'sum')
        _m13 = VectorReduceModule(_m14, 'sum')
        _m20 = VectorReduceModule(_m21, 'sum')
        _m27 = VectorReduceModule(_m28, 'sum')
        _m6 = VectorSumModule([_m7, _m8])
        _m18 = VectorSumModule([_m19, _m20])
        _m25 = VectorSumModule([_m26, _m27])
        _m0 = CombinedASTModule([_m1, _m6, _m13, _m18, _m25], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2), ('scalar_at', 3, 3), ('scalar_at', 4, 4)], 5)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
