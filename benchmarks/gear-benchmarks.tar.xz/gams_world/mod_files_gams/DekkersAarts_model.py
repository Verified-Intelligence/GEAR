"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import DekkersaartsModel
  model = DekkersaartsModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class DekkersaartsModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'DekkersAarts_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = LastDimSliceModule(1, 2)
        _m5 = LastDimSliceModule(0, 1)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m16 = VariableVectorGatherModule([0] * 1)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m26 = VariableVectorGatherModule([0] * 1)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'add')
        _m21 = VectorBinaryOpModule(_m22, _m25, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m18, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m28, 'pow')
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m19 = VectorScaleModule(_m20, 1e-05, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m6, _m9, _m19])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
