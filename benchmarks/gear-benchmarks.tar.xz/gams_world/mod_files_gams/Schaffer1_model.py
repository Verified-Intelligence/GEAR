"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Schaffer1Model
  model = Schaffer1Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule, VectorUnaryOpModule

class Schaffer1Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Schaffer1_model_state.pt'

        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m12 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m26 = VariableVectorGatherModule([0] * 1)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'add')
        _m20 = VectorBinaryOpModule(_m21, _m24, 'add')
        _m5 = VectorUnaryOpModule(_m6, 'sqrt')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'sin')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m13, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m27, 'pow')
        _m2 = VectorBinaryOpModule(_m3, _m14, 'sub')
        _m1 = VectorBinaryOpModule(_m2, _m15, 'div')
        _m0 = VectorSumModule([_m1, _m28])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
