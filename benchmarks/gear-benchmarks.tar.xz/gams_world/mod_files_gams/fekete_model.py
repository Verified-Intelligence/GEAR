"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import FeketeModel
  model = FeketeModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, CombinedASTModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class FeketeModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'fekete_model_state.pt'

        _m7 = BatchedAffineGatherModule([[0] * 2 for _ in range(1225)], [[0.0] * 2 for _ in range(1225)], [0.0] * 1225, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = BatchedAffineGatherModule([[0] * 2 for _ in range(1225)], [[0.0] * 2 for _ in range(1225)], [0.0] * 1225, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = BatchedAffineGatherModule([[0] * 2 for _ in range(1225)], [[0.0] * 2 for _ in range(1225)], [0.0] * 1225, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 50)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 50)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 50)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'pow')
        _m24 = VectorBinaryOpModule(_m25, _m28, 'pow')
        _m29 = VectorBinaryOpModule(_m30, _m33, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m12, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'add')
        _m3 = VectorUnaryOpModule(_m4, 'log')
        _m16 = VectorBinaryOpModule(_m17, _m24, 'add')
        _m2 = VectorScaleModule(_m3, -1, dtype=torch.float64)
        _m15 = VectorBinaryOpModule(_m16, _m29, 'add')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = CombinedASTModule([_m1, _m15], [('scalar_at', 0, 0), ('vector_pick', 1, 0, 1), ('vector_pick', 1, 1, 2), ('vector_pick', 1, 2, 3), ('vector_pick', 1, 3, 4), ('vector_pick', 1, 4, 5), ('vector_pick', 1, 5, 6), ('vector_pick', 1, 6, 7), ('vector_pick', 1, 7, 8), ('vector_pick', 1, 8, 9), ('vector_pick', 1, 9, 10), ('vector_pick', 1, 10, 11), ('vector_pick', 1, 11, 12), ('vector_pick', 1, 12, 13), ('vector_pick', 1, 13, 14), ('vector_pick', 1, 14, 15), ('vector_pick', 1, 15, 16), ('vector_pick', 1, 16, 17), ('vector_pick', 1, 17, 18), ('vector_pick', 1, 18, 19), ('vector_pick', 1, 19, 20), ('vector_pick', 1, 20, 21), ('vector_pick', 1, 21, 22), ('vector_pick', 1, 22, 23), ('vector_pick', 1, 23, 24), ('vector_pick', 1, 24, 25), ('vector_pick', 1, 25, 26), ('vector_pick', 1, 26, 27), ('vector_pick', 1, 27, 28), ('vector_pick', 1, 28, 29), ('vector_pick', 1, 29, 30), ('vector_pick', 1, 30, 31), ('vector_pick', 1, 31, 32), ('vector_pick', 1, 32, 33), ('vector_pick', 1, 33, 34), ('vector_pick', 1, 34, 35), ('vector_pick', 1, 35, 36), ('vector_pick', 1, 36, 37), ('vector_pick', 1, 37, 38), ('vector_pick', 1, 38, 39), ('vector_pick', 1, 39, 40), ('vector_pick', 1, 40, 41), ('vector_pick', 1, 41, 42), ('vector_pick', 1, 42, 43), ('vector_pick', 1, 43, 44), ('vector_pick', 1, 44, 45), ('vector_pick', 1, 45, 46), ('vector_pick', 1, 46, 47), ('vector_pick', 1, 47, 48), ('vector_pick', 1, 48, 49), ('vector_pick', 1, 49, 50)], 51)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 51
