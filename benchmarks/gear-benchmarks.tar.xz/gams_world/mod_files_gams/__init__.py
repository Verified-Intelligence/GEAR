"""Generated mod_files package: AMPL .mod models as PyTorch nn.Modules."""

from .Ackleys_model import AckleysModel
from .AluffiPentini_model import AluffipentiniModel
from .BeckerLago_model import BeckerlagoModel
from .Bohachevsky1_model import Bohachevsky1Model
from .Bohachevsky2_model import Bohachevsky2Model
from .Branin_model import BraninModel
from .Camel3_model import Camel3Model
from .Camel6_model import Camel6Model
from .CosMix2_model import Cosmix2Model
from .CosMix4_model import Cosmix4Model
from .DekkersAarts_model import DekkersaartsModel
from .Easom_model import EasomModel
from .Expo_model import ExpoModel
from .GoldPrice_model import GoldpriceModel
from .Griewank_model import GriewankModel
from .Gulf_model import GulfModel
from .Hartman3_model import Hartman3Model
from .Hartman6_model import Hartman6Model
from .Hosaki_model import HosakiModel
from .Kowalik_model import KowalikModel
from .LM1_model import Lm1Model
from .LM2n10_model import Lm2n10Model
from .LM2n5_model import Lm2n5Model
from .McCormic_model import MccormicModel
from .MeyerRoth_model import MeyerrothModel
from .MieleCantrell_model import MielecantrellModel
from .ModRosenbrock_model import ModrosenbrockModel
from .Modlangerman_model import ModlangermanModel
from .MultiGauss_model import MultigaussModel
from .Neumaier2_model import Neumaier2Model
from .Neumaier3_model import Neumaier3Model
from .Paviani_model import PavianiModel
from .Periodic_model import PeriodicModel
from .PowellQ_model import PowellqModel
from .Rastrigin_model import RastriginModel
from .Rosenbrock_model import RosenbrockModel
from .Salomon_model import SalomonModel
from .Schaffer1_model import Schaffer1Model
from .Schaffer2_model import Schaffer2Model
from .Schubert_model import SchubertModel
from .Schwefel_model import SchwefelModel
from .Shekel10_model import Shekel10Model
from .Shekel5_model import Shekel5Model
from .Shekel7_model import Shekel7Model
from .Shekelfox10_model import Shekelfox10Model
from .Shekelfox5_model import Shekelfox5Model
from .Wood_model import WoodModel
from .Zeldasine10_model import Zeldasine10Model
from .Zeldasine20_model import Zeldasine20Model
from .cute_airport_model import CuteAirportModel
from .cute_alsotame_model import CuteAlsotameModel
from .cute_avion2_model import CuteAvion2Model
from .cute_batch_model import CuteBatchModel
from .cute_biggsc4_model import CuteBiggsc4Model
from .cute_bqp1var_model import CuteBqp1varModel
from .cute_camel6_model import CuteCamel6Model
from .cute_dual1_model import CuteDual1Model
from .cute_dual2_model import CuteDual2Model
from .cute_dual3_model import CuteDual3Model
from .cute_dual4_model import CuteDual4Model
from .cute_dualc1_model import CuteDualc1Model
from .cute_dualc2_model import CuteDualc2Model
from .cute_dualc5_model import CuteDualc5Model
from .cute_dualc8_model import CuteDualc8Model
from .cute_eigmaxb_model import CuteEigmaxbModel
from .cute_eigmina_model import CuteEigminaModel
from .cute_eigminb_model import CuteEigminbModel
from .cute_eigminc_model import CuteEigmincModel
from .cute_explin2_model import CuteExplin2Model
from .cute_explin_model import CuteExplinModel
from .cute_gouldqp2_model import CuteGouldqp2Model
from .cute_gouldqp3_model import CuteGouldqp3Model
from .cute_grouping_model import CuteGroupingModel
from .cute_hadamals_model import CuteHadamalsModel
from .cute_hart6_model import CuteHart6Model
from .cute_hatfldh_model import CuteHatfldhModel
from .cute_himmelbj_model import CuteHimmelbjModel
from .cute_himmelp1_model import CuteHimmelp1Model
from .cute_himmelp2_model import CuteHimmelp2Model
from .cute_himmelp3_model import CuteHimmelp3Model
from .cute_himmelp4_model import CuteHimmelp4Model
from .cute_himmelp5_model import CuteHimmelp5Model
from .cute_himmelp6_model import CuteHimmelp6Model
from .cute_hong_model import CuteHongModel
from .cute_hs005_model import CuteHs005Model
from .cute_hs018_model import CuteHs018Model
from .cute_hs019_model import CuteHs019Model
from .cute_hs021_model import CuteHs021Model
from .cute_hs023_model import CuteHs023Model
from .cute_hs025_model import CuteHs025Model
from .cute_hs030_model import CuteHs030Model
from .cute_hs031_model import CuteHs031Model
from .cute_hs034_model import CuteHs034Model
from .cute_hs036_model import CuteHs036Model
from .cute_hs037_model import CuteHs037Model
from .cute_hs041_model import CuteHs041Model
from .cute_hs045_model import CuteHs045Model
from .cute_hs053_model import CuteHs053Model
from .cute_hs054_model import CuteHs054Model
from .cute_hs055_model import CuteHs055Model
from .cute_hs059_model import CuteHs059Model
from .cute_hs060_model import CuteHs060Model
from .cute_hs062_model import CuteHs062Model
from .cute_hs065_model import CuteHs065Model
from .cute_hs066_model import CuteHs066Model
from .cute_hs071_model import CuteHs071Model
from .cute_hs072_model import CuteHs072Model
from .cute_hs074_model import CuteHs074Model
from .cute_hs075_model import CuteHs075Model
from .cute_hs080_model import CuteHs080Model
from .cute_hs083_model import CuteHs083Model
from .cute_hs084_model import CuteHs084Model
from .cute_hs095_model import CuteHs095Model
from .cute_hs096_model import CuteHs096Model
from .cute_hs097_model import CuteHs097Model
from .cute_hs098_model import CuteHs098Model
from .cute_hs101_model import CuteHs101Model
from .cute_hs102_model import CuteHs102Model
from .cute_hs103_model import CuteHs103Model
from .cute_hs104_model import CuteHs104Model
from .cute_hs106_model import CuteHs106Model
from .cute_hs110_model import CuteHs110Model
from .cute_hs111_model import CuteHs111Model
from .cute_hs116_model import CuteHs116Model
from .cute_hs118_model import CuteHs118Model
from .cute_hs119_model import CuteHs119Model
from .cute_lewispol_model import CuteLewispolModel
from .cute_lootsma_model import CuteLootsmaModel
from .cute_lsnnodoc_model import CuteLsnnodocModel
from .cute_nuffield_continuum_model import CuteNuffieldContinuumModel
from .cute_obstclal_model import CuteObstclalModel
from .cute_obstclbl_model import CuteObstclblModel
from .cute_obstclbu_model import CuteObstclbuModel
from .cute_optprloc_model import CuteOptprlocModel
from .cute_portfl1_model import CutePortfl1Model
from .cute_portfl2_model import CutePortfl2Model
from .cute_portfl3_model import CutePortfl3Model
from .cute_portfl4_model import CutePortfl4Model
from .cute_portfl6_model import CutePortfl6Model
from .cute_probpenl_model import CuteProbpenlModel
from .cute_qudlin_model import CuteQudlinModel
from .cute_reading3_model import CuteReading3Model
from .cute_s368_model import CuteS368Model
from .cute_sineali_model import CuteSinealiModel
from .cute_spanhyd_model import CuteSpanhydModel
from .cute_twirism1_model import CuteTwirism1Model
from .cute_twobars_model import CuteTwobarsModel
from .cute_zecevic2_model import CuteZecevic2Model
from .cute_zecevic3_model import CuteZecevic3Model
from .cute_zecevic4_model import CuteZecevic4Model
from .dea_model import DeaModel
from .elena_branin_model import ElenaBraninModel
from .elena_camel1_model import ElenaCamel1Model
from .elena_chi_model import ElenaChiModel
from .elena_gold_model import ElenaGoldModel
from .elena_griewank_model import ElenaGriewankModel
from .elena_hs105_model import ElenaHs105Model
from .elena_hs106_model import ElenaHs106Model
from .elena_hs111_model import ElenaHs111Model
from .elena_hs116_model import ElenaHs116Model
from .elena_hs23_model import ElenaHs23Model
from .elena_hs54_model import ElenaHs54Model
from .elena_hs5_model import ElenaHs5Model
from .elena_hs62_model import ElenaHs62Model
from .elena_hs87_model import ElenaHs87Model
from .elena_kowalik_model import ElenaKowalikModel
from .elena_levy3_model import ElenaLevy3Model
from .elena_powell_model import ElenaPowellModel
from .elena_price_model import ElenaPriceModel
from .elena_s383_model import ElenaS383Model
from .elena_schwefel_model import ElenaSchwefelModel
from .elena_shekel_model import ElenaShekelModel
from .elena_tre_model import ElenaTreModel
from .ex005_model import Ex005Model
from .ex8_2_1a_model import Ex821aModel
from .ex8_2_4a_model import Ex824aModel
from .ex8_3_10_model import Ex8310Model
from .ex8_3_11_model import Ex8311Model
from .ex8_3_12_model import Ex8312Model
from .ex8_3_14_model import Ex8314Model
from .ex8_3_1_model import Ex831Model
from .ex8_3_6_model import Ex836Model
from .fekete2_model import Fekete2Model
from .fekete3_model import Fekete3Model
from .fekete_model import FeketeModel
from .hs005_model import Hs005Model
from .hs018_model import Hs018Model
from .hs019_model import Hs019Model
from .hs021_model import Hs021Model
from .hs023_model import Hs023Model
from .hs025_model import Hs025Model
from .hs030_model import Hs030Model
from .hs031_model import Hs031Model
from .hs034_model import Hs034Model
from .hs036_model import Hs036Model
from .hs038_model import Hs038Model
from .hs041_model import Hs041Model
from .hs045_model import Hs045Model
from .hs053_model import Hs053Model
from .hs054_model import Hs054Model
from .hs055_model import Hs055Model
from .hs059_model import Hs059Model
from .hs05x_model import Hs05xModel
from .hs060_model import Hs060Model
from .hs062_model import Hs062Model
from .hs065_model import Hs065Model
from .hs066_model import Hs066Model
from .hs071_model import Hs071Model
from .hs074_model import Hs074Model
from .hs080_model import Hs080Model
from .hs081_model import Hs081Model
from .hs083_model import Hs083Model
from .hs084_model import Hs084Model
from .hs087_model import Hs087Model
from .hs095_model import Hs095Model
from .hs096_model import Hs096Model
from .hs097_model import Hs097Model
from .hs098_model import Hs098Model
from .hs101_model import Hs101Model
from .hs102_model import Hs102Model
from .hs103_model import Hs103Model
from .hs104_model import Hs104Model
from .hs106_model import Hs106Model
from .hs109_model import Hs109Model
from .hs110_model import Hs110Model
from .hs111_model import Hs111Model
from .hs116_model import Hs116Model
from .hs118_model import Hs118Model
from .hs119_model import Hs119Model
from .ive_folioqpgraph_model import IveFolioqpgraphModel
from .kalis_distance_model import KalisDistanceModel
from .meanvar_model import MeanvarModel
from .mosel_start_folioqpgraph_model import MoselStartFolioqpgraphModel
from .nltrans_model import NltransModel
from .pgon_polygon_model import PgonPolygonModel
from .sample_model import SampleModel
from .schitt_s223_model import SchittS223Model
from .schitt_s224_model import SchittS224Model
from .schitt_s229_model import SchittS229Model
from .schitt_s234_model import SchittS234Model
from .schitt_s236_model import SchittS236Model
from .schitt_s239_model import SchittS239Model
from .schitt_s242_model import SchittS242Model
from .schitt_s244_model import SchittS244Model
from .schitt_s250_model import SchittS250Model
from .schitt_s251_model import SchittS251Model
from .schitt_s253_model import SchittS253Model
from .schitt_s265_model import SchittS265Model
from .schitt_s315_model import SchittS315Model
from .schitt_s328_model import SchittS328Model
from .schitt_s329_model import SchittS329Model
from .schitt_s330_model import SchittS330Model
from .schitt_s332_model import SchittS332Model
from .schitt_s343_model import SchittS343Model
from .schitt_s346_model import SchittS346Model
from .schitt_s358_model import SchittS358Model
from .schitt_s366_model import SchittS366Model
from .schitt_s368_model import SchittS368Model
from .schitt_s369_model import SchittS369Model
from .schitt_s376_model import SchittS376Model
from .schitt_s377_model import SchittS377Model
from .schitt_s378_model import SchittS378Model
from .schitt_s380_model import SchittS380Model
from .schitt_s383_model import SchittS383Model
from .st_cqpjk2_model import StCqpjk2Model
from .st_e17_model import StE17Model

__all__ = [
    'AckleysModel',
    'AluffipentiniModel',
    'BeckerlagoModel',
    'Bohachevsky1Model',
    'Bohachevsky2Model',
    'BraninModel',
    'Camel3Model',
    'Camel6Model',
    'Cosmix2Model',
    'Cosmix4Model',
    'DekkersaartsModel',
    'EasomModel',
    'ExpoModel',
    'GoldpriceModel',
    'GriewankModel',
    'GulfModel',
    'Hartman3Model',
    'Hartman6Model',
    'HosakiModel',
    'KowalikModel',
    'Lm1Model',
    'Lm2n10Model',
    'Lm2n5Model',
    'MccormicModel',
    'MeyerrothModel',
    'MielecantrellModel',
    'ModrosenbrockModel',
    'ModlangermanModel',
    'MultigaussModel',
    'Neumaier2Model',
    'Neumaier3Model',
    'PavianiModel',
    'PeriodicModel',
    'PowellqModel',
    'RastriginModel',
    'RosenbrockModel',
    'SalomonModel',
    'Schaffer1Model',
    'Schaffer2Model',
    'SchubertModel',
    'SchwefelModel',
    'Shekel10Model',
    'Shekel5Model',
    'Shekel7Model',
    'Shekelfox10Model',
    'Shekelfox5Model',
    'WoodModel',
    'Zeldasine10Model',
    'Zeldasine20Model',
    'CuteAirportModel',
    'CuteAlsotameModel',
    'CuteAvion2Model',
    'CuteBatchModel',
    'CuteBiggsc4Model',
    'CuteBqp1varModel',
    'CuteCamel6Model',
    'CuteDual1Model',
    'CuteDual2Model',
    'CuteDual3Model',
    'CuteDual4Model',
    'CuteDualc1Model',
    'CuteDualc2Model',
    'CuteDualc5Model',
    'CuteDualc8Model',
    'CuteEigmaxbModel',
    'CuteEigminaModel',
    'CuteEigminbModel',
    'CuteEigmincModel',
    'CuteExplin2Model',
    'CuteExplinModel',
    'CuteGouldqp2Model',
    'CuteGouldqp3Model',
    'CuteGroupingModel',
    'CuteHadamalsModel',
    'CuteHart6Model',
    'CuteHatfldhModel',
    'CuteHimmelbjModel',
    'CuteHimmelp1Model',
    'CuteHimmelp2Model',
    'CuteHimmelp3Model',
    'CuteHimmelp4Model',
    'CuteHimmelp5Model',
    'CuteHimmelp6Model',
    'CuteHongModel',
    'CuteHs005Model',
    'CuteHs018Model',
    'CuteHs019Model',
    'CuteHs021Model',
    'CuteHs023Model',
    'CuteHs025Model',
    'CuteHs030Model',
    'CuteHs031Model',
    'CuteHs034Model',
    'CuteHs036Model',
    'CuteHs037Model',
    'CuteHs041Model',
    'CuteHs045Model',
    'CuteHs053Model',
    'CuteHs054Model',
    'CuteHs055Model',
    'CuteHs059Model',
    'CuteHs060Model',
    'CuteHs062Model',
    'CuteHs065Model',
    'CuteHs066Model',
    'CuteHs071Model',
    'CuteHs072Model',
    'CuteHs074Model',
    'CuteHs075Model',
    'CuteHs080Model',
    'CuteHs083Model',
    'CuteHs084Model',
    'CuteHs095Model',
    'CuteHs096Model',
    'CuteHs097Model',
    'CuteHs098Model',
    'CuteHs101Model',
    'CuteHs102Model',
    'CuteHs103Model',
    'CuteHs104Model',
    'CuteHs106Model',
    'CuteHs110Model',
    'CuteHs111Model',
    'CuteHs116Model',
    'CuteHs118Model',
    'CuteHs119Model',
    'CuteLewispolModel',
    'CuteLootsmaModel',
    'CuteLsnnodocModel',
    'CuteNuffieldContinuumModel',
    'CuteObstclalModel',
    'CuteObstclblModel',
    'CuteObstclbuModel',
    'CuteOptprlocModel',
    'CutePortfl1Model',
    'CutePortfl2Model',
    'CutePortfl3Model',
    'CutePortfl4Model',
    'CutePortfl6Model',
    'CuteProbpenlModel',
    'CuteQudlinModel',
    'CuteReading3Model',
    'CuteS368Model',
    'CuteSinealiModel',
    'CuteSpanhydModel',
    'CuteTwirism1Model',
    'CuteTwobarsModel',
    'CuteZecevic2Model',
    'CuteZecevic3Model',
    'CuteZecevic4Model',
    'DeaModel',
    'ElenaBraninModel',
    'ElenaCamel1Model',
    'ElenaChiModel',
    'ElenaGoldModel',
    'ElenaGriewankModel',
    'ElenaHs105Model',
    'ElenaHs106Model',
    'ElenaHs111Model',
    'ElenaHs116Model',
    'ElenaHs23Model',
    'ElenaHs54Model',
    'ElenaHs5Model',
    'ElenaHs62Model',
    'ElenaHs87Model',
    'ElenaKowalikModel',
    'ElenaLevy3Model',
    'ElenaPowellModel',
    'ElenaPriceModel',
    'ElenaS383Model',
    'ElenaSchwefelModel',
    'ElenaShekelModel',
    'ElenaTreModel',
    'Ex005Model',
    'Ex821aModel',
    'Ex824aModel',
    'Ex8310Model',
    'Ex8311Model',
    'Ex8312Model',
    'Ex8314Model',
    'Ex831Model',
    'Ex836Model',
    'Fekete2Model',
    'Fekete3Model',
    'FeketeModel',
    'Hs005Model',
    'Hs018Model',
    'Hs019Model',
    'Hs021Model',
    'Hs023Model',
    'Hs025Model',
    'Hs030Model',
    'Hs031Model',
    'Hs034Model',
    'Hs036Model',
    'Hs038Model',
    'Hs041Model',
    'Hs045Model',
    'Hs053Model',
    'Hs054Model',
    'Hs055Model',
    'Hs059Model',
    'Hs05xModel',
    'Hs060Model',
    'Hs062Model',
    'Hs065Model',
    'Hs066Model',
    'Hs071Model',
    'Hs074Model',
    'Hs080Model',
    'Hs081Model',
    'Hs083Model',
    'Hs084Model',
    'Hs087Model',
    'Hs095Model',
    'Hs096Model',
    'Hs097Model',
    'Hs098Model',
    'Hs101Model',
    'Hs102Model',
    'Hs103Model',
    'Hs104Model',
    'Hs106Model',
    'Hs109Model',
    'Hs110Model',
    'Hs111Model',
    'Hs116Model',
    'Hs118Model',
    'Hs119Model',
    'IveFolioqpgraphModel',
    'KalisDistanceModel',
    'MeanvarModel',
    'MoselStartFolioqpgraphModel',
    'NltransModel',
    'PgonPolygonModel',
    'SampleModel',
    'SchittS223Model',
    'SchittS224Model',
    'SchittS229Model',
    'SchittS234Model',
    'SchittS236Model',
    'SchittS239Model',
    'SchittS242Model',
    'SchittS244Model',
    'SchittS250Model',
    'SchittS251Model',
    'SchittS253Model',
    'SchittS265Model',
    'SchittS315Model',
    'SchittS328Model',
    'SchittS329Model',
    'SchittS330Model',
    'SchittS332Model',
    'SchittS343Model',
    'SchittS346Model',
    'SchittS358Model',
    'SchittS366Model',
    'SchittS368Model',
    'SchittS369Model',
    'SchittS376Model',
    'SchittS377Model',
    'SchittS378Model',
    'SchittS380Model',
    'SchittS383Model',
    'StCqpjk2Model',
    'StE17Model',
]