"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import DeaModel
  model = DeaModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class DeaModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'dea_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(101)], [0.0] * 101, dtype=torch.float64)
        _m4 = SharedLinearFormModule(None, [[0.0] * 6 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m7 = LastDimSliceModule(6, 7)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m26 = VariableVectorGatherModule([0] * 1)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m19, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m22, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m25, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'div')
        _m3 = SharedLinearAugmentModule(_m4, _m5)
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 0)], 101)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 101, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 101
