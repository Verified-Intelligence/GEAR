"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs095Model
  model = CuteHs095Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteHs095Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs095_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(5)], [0.0] * 5, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 11, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 11)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 11)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 11, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], [[0] * 11], 5, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 5
