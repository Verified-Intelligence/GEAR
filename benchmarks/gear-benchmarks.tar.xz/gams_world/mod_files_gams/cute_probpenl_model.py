"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteProbpenlModel
  model = CuteProbpenlModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteProbpenlModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_probpenl_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 500 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m6 = BatchedAffineGatherModule([[0] * 2 for _ in range(499)], [[0.0] * 2 for _ in range(499)], [0.0] * 499, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 499)
        _m12 = BatchedAffineGatherModule([[0] * 1 for _ in range(499)], [[0.0] * 1 for _ in range(499)], [0.0] * 499, dtype=torch.float64)
        _m15 = LastDimSliceModule(500, 501)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m9 = VectorUnaryOpModule(_m10, 'exp')
        _m13 = VectorScaleModule(_m14, 100, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorScaleModule(_m5, 1, dtype=torch.float64)
        _m3 = VectorReduceModule(_m4, 'sum')
        _m2 = VectorSumModule([_m3, _m13])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
