"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex8314Model
  model = Ex8314Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex8314Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_14_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 57, [[0.0] * 57 for _ in range(143)], [0.0] * 143, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 368)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 368)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 30)
        _m17 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 30)
        _m20 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 30)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 10)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 10)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 10)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 10)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = VariableVectorGatherModule([0] * 10)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 10)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 10)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m70 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m71 = VariableVectorGatherModule([0] * 10)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m74 = VariableVectorGatherModule([0] * 10)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 10)
        _m79 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m83 = VariableVectorGatherModule([0] * 10)
        _m84 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m89 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m90 = VariableVectorGatherModule([0] * 10)
        _m92 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m93 = VariableVectorGatherModule([0] * 10)
        _m95 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m96 = VariableVectorGatherModule([0] * 10)
        _m98 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m99 = VariableVectorGatherModule([0] * 10)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m69 = VectorBinaryOpModule(_m70, _m71, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m81 = VectorBinaryOpModule(_m82, _m83, 'mul')
        _m88 = VectorBinaryOpModule(_m89, _m90, 'mul')
        _m91 = VectorBinaryOpModule(_m92, _m93, 'mul')
        _m94 = VectorBinaryOpModule(_m95, _m96, 'mul')
        _m97 = VectorBinaryOpModule(_m98, _m99, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'div')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'pow')
        _m45 = VectorBinaryOpModule(_m46, _m49, 'add')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'div')
        _m75 = VectorBinaryOpModule(_m76, _m79, 'pow')
        _m80 = VectorBinaryOpModule(_m81, _m84, 'pow')
        _m87 = VectorBinaryOpModule(_m88, _m91, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 368, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m28 = VectorUnaryOpModule(_m29, 'exp')
        _m44 = VectorBinaryOpModule(_m45, _m52, 'add')
        _m66 = VectorUnaryOpModule(_m67, 'exp')
        _m86 = VectorBinaryOpModule(_m87, _m94, 'add')
        _m10 = ResidualBucketScatterAddModule(_m11, [0.0] * 30, dtype=torch.float64)
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m55, 'add')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m85 = VectorBinaryOpModule(_m86, _m97, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m34, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m58, 'pow')
        _m63 = VectorBinaryOpModule(_m64, _m72, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m37, 'mul')
        _m62 = VectorBinaryOpModule(_m63, _m75, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m42, 'div')
        _m61 = VectorBinaryOpModule(_m62, _m80, 'div')
        _m22 = ResidualBucketScatterAddModule(_m23, [0.0] * 10, dtype=torch.float64)
        _m60 = VectorBinaryOpModule(_m61, _m85, 'div')
        _m59 = ResidualBucketScatterAddModule(_m60, [0.0] * 10, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m10, _m22, _m59], [[0] * 368, [0] * 30, [0] * 10, [0] * 10], 143, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 143
