"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Zeldasine20Model
  model = Zeldasine20Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Zeldasine20Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Zeldasine20_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 20 for _ in range(20)], [0.0] * 20, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = LastDimSliceModule(0, 1)
        _m27 = LastDimSliceModule(11, 12)
        _m29 = LastDimSliceModule(13, 14)
        _m31 = LastDimSliceModule(14, 15)
        _m33 = LastDimSliceModule(15, 16)
        _m35 = LastDimSliceModule(16, 17)
        _m37 = LastDimSliceModule(17, 18)
        _m39 = LastDimSliceModule(18, 19)
        _m41 = LastDimSliceModule(19, 20)
        _m43 = LastDimSliceModule(1, 2)
        _m45 = LastDimSliceModule(2, 3)
        _m47 = LastDimSliceModule(3, 4)
        _m49 = LastDimSliceModule(4, 5)
        _m51 = LastDimSliceModule(5, 6)
        _m53 = LastDimSliceModule(6, 7)
        _m55 = LastDimSliceModule(7, 8)
        _m57 = LastDimSliceModule(8, 9)
        _m59 = LastDimSliceModule(9, 10)
        _m61 = LastDimSliceModule(10, 11)
        _m63 = LastDimSliceModule(12, 13)
        _m66 = SharedLinearFormModule(None, [[0.0] * 20 for _ in range(20)], [0.0] * 20, dtype=torch.float64)
        _m87 = LastDimSliceModule(0, 1)
        _m89 = LastDimSliceModule(11, 12)
        _m91 = LastDimSliceModule(13, 14)
        _m93 = LastDimSliceModule(14, 15)
        _m95 = LastDimSliceModule(15, 16)
        _m97 = LastDimSliceModule(16, 17)
        _m99 = LastDimSliceModule(17, 18)
        _m101 = LastDimSliceModule(18, 19)
        _m103 = LastDimSliceModule(19, 20)
        _m105 = LastDimSliceModule(1, 2)
        _m107 = LastDimSliceModule(2, 3)
        _m109 = LastDimSliceModule(3, 4)
        _m111 = LastDimSliceModule(4, 5)
        _m113 = LastDimSliceModule(5, 6)
        _m115 = LastDimSliceModule(6, 7)
        _m117 = LastDimSliceModule(7, 8)
        _m119 = LastDimSliceModule(8, 9)
        _m121 = LastDimSliceModule(9, 10)
        _m123 = LastDimSliceModule(10, 11)
        _m125 = LastDimSliceModule(12, 13)
        _m24 = VectorUnaryOpModule(_m25, 'sin')
        _m26 = VectorUnaryOpModule(_m27, 'sin')
        _m28 = VectorUnaryOpModule(_m29, 'sin')
        _m30 = VectorUnaryOpModule(_m31, 'sin')
        _m32 = VectorUnaryOpModule(_m33, 'sin')
        _m34 = VectorUnaryOpModule(_m35, 'sin')
        _m36 = VectorUnaryOpModule(_m37, 'sin')
        _m38 = VectorUnaryOpModule(_m39, 'sin')
        _m40 = VectorUnaryOpModule(_m41, 'sin')
        _m42 = VectorUnaryOpModule(_m43, 'sin')
        _m44 = VectorUnaryOpModule(_m45, 'sin')
        _m46 = VectorUnaryOpModule(_m47, 'sin')
        _m48 = VectorUnaryOpModule(_m49, 'sin')
        _m50 = VectorUnaryOpModule(_m51, 'sin')
        _m52 = VectorUnaryOpModule(_m53, 'sin')
        _m54 = VectorUnaryOpModule(_m55, 'sin')
        _m56 = VectorUnaryOpModule(_m57, 'sin')
        _m58 = VectorUnaryOpModule(_m59, 'sin')
        _m60 = VectorUnaryOpModule(_m61, 'sin')
        _m62 = VectorUnaryOpModule(_m63, 'sin')
        _m86 = VectorUnaryOpModule(_m87, 'sin')
        _m88 = VectorUnaryOpModule(_m89, 'sin')
        _m90 = VectorUnaryOpModule(_m91, 'sin')
        _m92 = VectorUnaryOpModule(_m93, 'sin')
        _m94 = VectorUnaryOpModule(_m95, 'sin')
        _m96 = VectorUnaryOpModule(_m97, 'sin')
        _m98 = VectorUnaryOpModule(_m99, 'sin')
        _m100 = VectorUnaryOpModule(_m101, 'sin')
        _m102 = VectorUnaryOpModule(_m103, 'sin')
        _m104 = VectorUnaryOpModule(_m105, 'sin')
        _m106 = VectorUnaryOpModule(_m107, 'sin')
        _m108 = VectorUnaryOpModule(_m109, 'sin')
        _m110 = VectorUnaryOpModule(_m111, 'sin')
        _m112 = VectorUnaryOpModule(_m113, 'sin')
        _m114 = VectorUnaryOpModule(_m115, 'sin')
        _m116 = VectorUnaryOpModule(_m117, 'sin')
        _m118 = VectorUnaryOpModule(_m119, 'sin')
        _m120 = VectorUnaryOpModule(_m121, 'sin')
        _m122 = VectorUnaryOpModule(_m123, 'sin')
        _m124 = VectorUnaryOpModule(_m125, 'sin')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m85 = VectorBinaryOpModule(_m86, _m88, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m26, 'mul')
        _m84 = VectorBinaryOpModule(_m85, _m90, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m28, 'mul')
        _m83 = VectorBinaryOpModule(_m84, _m92, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m30, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m94, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m32, 'mul')
        _m81 = VectorBinaryOpModule(_m82, _m96, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m34, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m98, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m36, 'mul')
        _m79 = VectorBinaryOpModule(_m80, _m100, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m38, 'mul')
        _m78 = VectorBinaryOpModule(_m79, _m102, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m40, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m104, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m42, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m106, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m44, 'mul')
        _m75 = VectorBinaryOpModule(_m76, _m108, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m46, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m110, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m48, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m112, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m50, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m114, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m52, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m116, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m54, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m118, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m56, 'mul')
        _m69 = VectorBinaryOpModule(_m70, _m120, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m58, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m122, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m60, 'mul')
        _m67 = VectorBinaryOpModule(_m68, _m124, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m62, 'mul')
        _m65 = SharedLinearSingleCoreModule(_m66, _m67)
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m64 = VectorScaleModule(_m65, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m64])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
