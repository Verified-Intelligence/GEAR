"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS346Model
  model = SchittS346Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule

class SchittS346Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s346_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m5 = LastDimSliceModule(2, 3)
        _m7 = LastDimSliceModule(0, 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = LastDimSliceModule(1, 2)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'pow')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'mul')
        _m12 = VectorSumModule([_m13, _m14])
        _m21 = VectorBinaryOpModule(_m22, _m27, 'mul')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m19 = VectorSumModule([_m20, _m21])
        _m0 = CombinedASTModule([_m1, _m12, _m19], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
