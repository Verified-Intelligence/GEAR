"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaChiModel
  model = ElenaChiModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class ElenaChiModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_chi_model_state.pt'

        _m2 = VariableVectorGatherModule([0] * 1)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m8 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m10 = LastDimSliceModule(0, 1)
        _m13 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m15 = LastDimSliceModule(0, 1)
        _m18 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = LastDimSliceModule(0, 1)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m1 = VectorBinaryOpModule(_m2, _m3, 'pow')
        _m4 = VectorScaleModule(_m5, -12, dtype=torch.float64)
        _m9 = VectorUnaryOpModule(_m10, 'cos')
        _m14 = VectorUnaryOpModule(_m15, 'sin')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m12 = SharedLinearSingleCoreModule(_m13, _m14)
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m6 = VectorScaleModule(_m7, 10, dtype=torch.float64)
        _m11 = VectorScaleModule(_m12, 8, dtype=torch.float64)
        _m19 = VectorUnaryOpModule(_m20, 'exp')
        _m17 = SharedLinearSingleCoreModule(_m18, _m19)
        _m16 = VectorScaleModule(_m17, -0.447213595499958, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m4, _m6, _m11, _m16, _m25])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
