"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Shekelfox10Model
  model = Shekelfox10Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule

class Shekelfox10Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Shekelfox10_model_state.pt'

        _m2 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m4 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m6 = ConstantVectorModule([0.0] * 30, dtype=torch.float64)
        _m17 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(30)], [0.0] * 30, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'pow')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'pow')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m39, 'pow')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'pow')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m22, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m25, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m28, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m31, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m34, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m37, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m40, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m43, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'div')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'mul')
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
