"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs005Model
  model = CuteHs005Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorSumModule, VectorUnaryOpModule

class CuteHs005Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs005_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = LastDimSliceModule(3, 4)
        _m6 = LastDimSliceModule(2, 3)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 2)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorUnaryOpModule(_m4, 'sin')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m8 = VectorReduceModule(_m9, 'sum')
        _m2 = VectorSumModule([_m3, _m5, _m8, _m12])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
