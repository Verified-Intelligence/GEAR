"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Neumaier2Model
  model = Neumaier2Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule, VectorUnaryOpModule

class Neumaier2Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Neumaier2_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(4, 5)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 1)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 1)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 1)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 1)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = VariableVectorGatherModule([0] * 1)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 1)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 1)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'pow')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'pow')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'pow')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'pow')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'pow')
        _m56 = VectorBinaryOpModule(_m57, _m58, 'pow')
        _m59 = VectorBinaryOpModule(_m60, _m61, 'pow')
        _m62 = VectorBinaryOpModule(_m63, _m64, 'pow')
        _m12 = VectorUnaryOpModule(_m13, 'neg')
        _m32 = VectorUnaryOpModule(_m33, 'neg')
        _m52 = VectorUnaryOpModule(_m53, 'neg')
        _m11 = VectorBinaryOpModule(_m12, _m16, 'sub')
        _m31 = VectorBinaryOpModule(_m32, _m36, 'sub')
        _m51 = VectorBinaryOpModule(_m52, _m56, 'sub')
        _m10 = VectorBinaryOpModule(_m11, _m19, 'sub')
        _m30 = VectorBinaryOpModule(_m31, _m39, 'sub')
        _m50 = VectorBinaryOpModule(_m51, _m59, 'sub')
        _m9 = VectorBinaryOpModule(_m10, _m22, 'sub')
        _m29 = VectorBinaryOpModule(_m30, _m42, 'sub')
        _m49 = VectorBinaryOpModule(_m50, _m62, 'sub')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'add')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m25, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m45, 'pow')
        _m46 = VectorBinaryOpModule(_m47, _m65, 'pow')
        _m2 = VectorSumModule([_m3, _m6, _m26, _m46])
        _m0 = SharedLinearAugmentModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
