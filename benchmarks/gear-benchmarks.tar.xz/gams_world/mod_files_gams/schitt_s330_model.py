"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS330Model
  model = SchittS330Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class SchittS330Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s330_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m8 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m10 = LastDimSliceModule(1, 2)
        _m12 = LastDimSliceModule(0, 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 1)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'div')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'pow')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'pow')
        _m2 = VectorScaleModule(_m3, 0.1, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m11, 'div')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m15 = VectorBinaryOpModule(_m16, _m21, 'div')
        _m27 = VectorBinaryOpModule(_m28, _m33, 'div')
        _m6 = VectorScaleModule(_m7, 0.1, dtype=torch.float64)
        _m14 = VectorScaleModule(_m15, 0.1, dtype=torch.float64)
        _m26 = VectorScaleModule(_m27, -1, dtype=torch.float64)
        _m1 = VectorSumModule([_m2, _m6, _m14])
        _m24 = VectorSumModule([_m25, _m26])
        _m0 = CombinedASTModule([_m1, _m24], [('scalar_at', 0, 0), ('scalar_at', 1, 1)], 2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
