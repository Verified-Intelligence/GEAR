"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs081Model
  model = Hs081Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Hs081Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs081_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 1)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 5)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 5)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 1)
        _m43 = VariableVectorGatherModule([0] * 1)
        _m46 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m48 = LastDimSliceModule(1, 2)
        _m49 = LastDimSliceModule(0, 1)
        _m51 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m53 = VariableVectorGatherModule([0] * 1)
        _m54 = VariableVectorGatherModule([0] * 1)
        _m56 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m58 = LastDimSliceModule(1, 2)
        _m59 = LastDimSliceModule(0, 1)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m65 = VariableVectorGatherModule([0] * 2)
        _m66 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 2)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'pow')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'pow')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'pow')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'pow')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'add')
        _m27 = VectorScaleModule(_m28, -1, dtype=torch.float64)
        _m34 = VectorScaleModule(_m35, 1, dtype=torch.float64)
        _m40 = VectorScaleModule(_m41, -1, dtype=torch.float64)
        _m45 = SharedLinearSingleCoreModule(_m46, _m47)
        _m55 = SharedLinearSingleCoreModule(_m56, _m57)
        _m63 = VectorScaleModule(_m64, -1, dtype=torch.float64)
        _m70 = VectorScaleModule(_m71, 1, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m20, 'add')
        _m26 = VectorReduceModule(_m27, 'sum')
        _m33 = VectorReduceModule(_m34, 'sum')
        _m44 = VectorScaleModule(_m45, -1, dtype=torch.float64)
        _m50 = VectorSumModule([_m51, _m52, _m55])
        _m62 = VectorReduceModule(_m63, 'sum')
        _m69 = VectorReduceModule(_m70, 'sum')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m23, 'pow')
        _m24 = VectorSumModule([_m25, _m26])
        _m31 = VectorSumModule([_m32, _m33])
        _m38 = VectorSumModule([_m39, _m40, _m44])
        _m60 = VectorSumModule([_m61, _m62])
        _m67 = VectorSumModule([_m68, _m69])
        _m2 = VectorUnaryOpModule(_m3, 'exp')
        _m12 = VectorScaleModule(_m13, -0.5, dtype=torch.float64)
        _m1 = VectorSumModule([_m2, _m12])
        _m0 = CombinedASTModule([_m1, _m24, _m31, _m38, _m50, _m60, _m67], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2), ('scalar_at', 3, 3), ('scalar_at', 4, 4), ('scalar_at', 5, 5), ('scalar_at', 6, 6)], 7)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
