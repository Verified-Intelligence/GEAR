"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteAirportModel
  model = CuteAirportModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, CombinedASTModule, ConstantVectorModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class CuteAirportModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_airport_model_state.pt'

        _m4 = BatchedAffineGatherModule([[0] * 2 for _ in range(1722)], [[0.0] * 2 for _ in range(1722)], [0.0] * 1722, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ConstantVectorModule([0.0] * 39, dtype=torch.float64)
        _m11 = ConstantVectorModule([0.0] * 39, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 39)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ConstantVectorModule([0.0] * 39, dtype=torch.float64)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 39)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 2)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 2)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 2)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'pow')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'pow')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'add')
        _m41 = VectorScaleModule(_m42, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m9 = VectorBinaryOpModule(_m10, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m22, 'pow')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'add')
        _m31 = VectorBinaryOpModule(_m32, _m37, 'pow')
        _m40 = VectorReduceModule(_m41, 'sum')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m23 = VectorBinaryOpModule(_m24, _m31, 'add')
        _m38 = VectorSumModule([_m39, _m40])
        _m6 = VectorBinaryOpModule(_m7, _m16, 'add')
        _m0 = CombinedASTModule([_m1, _m6, _m23, _m38], [('scalar_at', 0, 0), ('vector_pick', 1, 0, 1), ('vector_pick', 1, 1, 2), ('vector_pick', 1, 2, 3), ('vector_pick', 1, 3, 4), ('vector_pick', 1, 4, 5), ('vector_pick', 1, 5, 6), ('vector_pick', 1, 6, 7), ('vector_pick', 1, 7, 8), ('vector_pick', 1, 8, 9), ('vector_pick', 1, 9, 10), ('vector_pick', 1, 10, 11), ('vector_pick', 1, 11, 12), ('vector_pick', 1, 12, 13), ('vector_pick', 1, 13, 14), ('vector_pick', 1, 14, 15), ('vector_pick', 1, 15, 16), ('vector_pick', 1, 16, 17), ('vector_pick', 1, 17, 18), ('vector_pick', 1, 18, 20), ('vector_pick', 1, 19, 21), ('vector_pick', 1, 20, 22), ('vector_pick', 1, 21, 23), ('vector_pick', 1, 22, 24), ('vector_pick', 1, 23, 25), ('vector_pick', 1, 24, 26), ('vector_pick', 1, 25, 27), ('vector_pick', 1, 26, 28), ('vector_pick', 1, 27, 29), ('vector_pick', 1, 28, 31), ('vector_pick', 1, 29, 32), ('vector_pick', 1, 30, 33), ('vector_pick', 1, 31, 34), ('vector_pick', 1, 32, 35), ('vector_pick', 1, 33, 36), ('vector_pick', 1, 34, 37), ('vector_pick', 1, 35, 38), ('vector_pick', 1, 36, 39), ('vector_pick', 1, 37, 40), ('vector_pick', 1, 38, 41), ('vector_pick', 2, 0, 19), ('vector_pick', 2, 1, 30), ('scalar_at', 3, 42)], 43)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 43
