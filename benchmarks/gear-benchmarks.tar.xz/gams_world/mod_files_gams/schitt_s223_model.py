"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS223Model
  model = SchittS223Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class SchittS223Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s223_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 2)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'exp')
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], [[0] * 2], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
