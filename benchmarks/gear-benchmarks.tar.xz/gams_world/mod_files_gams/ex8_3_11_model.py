"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex8311Model
  model = Ex8311Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Ex8311Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_11_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 62, [[0.0] * 62 for _ in range(153)], [0.0] * 153, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 388, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 388)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 388)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 20)
        _m17 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 20)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 20)
        _m25 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m28 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 20)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 20)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 10)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = VariableVectorGatherModule([0] * 10)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m51 = VariableVectorGatherModule([0] * 10)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m46 = VectorBinaryOpModule(_m47, _m48, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m51, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'div')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'div')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 388, dtype=torch.float64)
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m26 = VectorUnaryOpModule(_m27, 'exp')
        _m40 = VectorUnaryOpModule(_m41, 'exp')
        _m10 = ResidualBucketScatterAddModule(_m11, [0.0] * 20, dtype=torch.float64)
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m32, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m46, 'mul')
        _m22 = ResidualBucketScatterAddModule(_m23, [0.0] * 20, dtype=torch.float64)
        _m36 = VectorBinaryOpModule(_m37, _m49, 'mul')
        _m35 = ResidualBucketScatterAddModule(_m36, [0.0] * 10, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m10, _m22, _m35], [[0] * 388, [0] * 20, [0] * 20, [0] * 10], 153, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 153
