"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Ex8310Model
  model = Ex8310Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class Ex8310Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ex8_3_10_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 106, [[0.0] * 106 for _ in range(216)], [0.0] * 216, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m13 = ConstantVectorModule([0.0] * 490, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 490)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 490)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 20)
        _m26 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 20)
        _m29 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 20)
        _m32 = ConstantVectorModule([0.0] * 20, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 20)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 10)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 10)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 10)
        _m49 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = VariableVectorGatherModule([0] * 10)
        _m56 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m57 = VariableVectorGatherModule([0] * 10)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m60 = VariableVectorGatherModule([0] * 10)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 10)
        _m65 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = VariableVectorGatherModule([0] * 10)
        _m68 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m69 = VariableVectorGatherModule([0] * 10)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m25 = VectorBinaryOpModule(_m26, _m27, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m48 = VectorBinaryOpModule(_m49, _m50, 'mul')
        _m55 = VectorBinaryOpModule(_m56, _m57, 'mul')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m64 = VectorBinaryOpModule(_m65, _m66, 'mul')
        _m67 = VectorBinaryOpModule(_m68, _m69, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'div')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m28, 'add')
        _m39 = VectorBinaryOpModule(_m40, _m43, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m58, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m10 = ResidualBucketScatterAddModule(_m11, [0.0] * 490, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m31, 'add')
        _m35 = VectorBinaryOpModule(_m36, _m39, 'mul')
        _m53 = VectorBinaryOpModule(_m54, _m61, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'mul')
        _m34 = ResidualBucketScatterAddModule(_m35, [0.0] * 10, dtype=torch.float64)
        _m52 = VectorBinaryOpModule(_m53, _m64, 'add')
        _m18 = ResidualBucketScatterAddModule(_m19, [0.0] * 20, dtype=torch.float64)
        _m51 = VectorBinaryOpModule(_m52, _m67, 'add')
        _m47 = VectorBinaryOpModule(_m48, _m51, 'mul')
        _m46 = ResidualBucketScatterAddModule(_m47, [0.0] * 10, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m10, _m18, _m34, _m46], [[0] * 1, [0] * 490, [0] * 20, [0] * 10, [0] * 10], 216, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 216
