"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaHs87Model
  model = ElenaHs87Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class ElenaHs87Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_hs87_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 8, [[0.0] * 8 for _ in range(13)], [0.0] * 13, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 8)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 4)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 4)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 4)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 4)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 4)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 4)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'add')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 8, dtype=torch.float64)
        _m13 = VectorUnaryOpModule(_m14, 'cos')
        _m30 = VectorUnaryOpModule(_m31, 'sin')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m19, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m36, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m22, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m39, 'mul')
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 4, dtype=torch.float64)
        _m25 = ResidualBucketScatterAddModule(_m26, [0.0] * 4, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m25], [[0] * 8, [0] * 4, [0] * 4], 13, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 13
