"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS343Model
  model = SchittS343Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule

class SchittS343Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s343_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m5 = LastDimSliceModule(2, 3)
        _m7 = LastDimSliceModule(1, 2)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = LastDimSliceModule(0, 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VariableVectorGatherModule([0] * 1)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'pow')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'pow')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'mul')
        _m14 = VectorSumModule([_m15, _m16])
        _m23 = VectorBinaryOpModule(_m24, _m29, 'mul')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m21 = VectorSumModule([_m22, _m23])
        _m0 = CombinedASTModule([_m1, _m14, _m21], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
