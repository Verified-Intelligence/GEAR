"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS366Model
  model = SchittS366Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class SchittS366Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s366_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 7, [[0.0] * 7 for _ in range(15)], [0.0] * 15, dtype=torch.float64)
        _m5 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 3)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VariableVectorGatherModule([0] * 3)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = VariableVectorGatherModule([0] * 2)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ConstantVectorModule([0.0] * 9, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 9)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 9)
        _m28 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 2)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 2)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = VariableVectorGatherModule([0] * 2)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 1)
        _m52 = ConstantVectorModule([0.0] * 5, dtype=torch.float64)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = VariableVectorGatherModule([0] * 5)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m66 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = VariableVectorGatherModule([0] * 1)
        _m71 = ConstantVectorModule([0.0] * 3, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 3)
        _m75 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 3)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 3)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m84 = VariableVectorGatherModule([0] * 1)
        _m88 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m89 = VariableVectorGatherModule([0] * 1)
        _m91 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m92 = VariableVectorGatherModule([0] * 1)
        _m94 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m95 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'mul')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m35, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m65 = VectorBinaryOpModule(_m66, _m67, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m82 = VectorBinaryOpModule(_m83, _m84, 'mul')
        _m87 = VectorBinaryOpModule(_m88, _m89, 'mul')
        _m90 = VectorBinaryOpModule(_m91, _m92, 'mul')
        _m93 = VectorBinaryOpModule(_m94, _m95, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m15, 'pow')
        _m17 = VectorBinaryOpModule(_m18, _m21, 'div')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m46, 'pow')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'div')
        _m60 = VectorBinaryOpModule(_m61, _m64, 'pow')
        _m73 = VectorBinaryOpModule(_m74, _m77, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m90, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 3, dtype=torch.float64)
        _m10 = ResidualBucketScatterAddModule(_m11, [0.0] * 2, dtype=torch.float64)
        _m16 = ResidualBucketScatterAddModule(_m17, [0.0] * 9, dtype=torch.float64)
        _m25 = VectorBinaryOpModule(_m26, _m33, 'div')
        _m38 = VectorBinaryOpModule(_m39, _m42, 'mul')
        _m50 = ResidualBucketScatterAddModule(_m51, [0.0] * 5, dtype=torch.float64)
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m69 = VectorBinaryOpModule(_m70, _m73, 'div')
        _m85 = VectorBinaryOpModule(_m86, _m93, 'mul')
        _m24 = ResidualBucketScatterAddModule(_m25, [0.0] * 2, dtype=torch.float64)
        _m37 = VectorBinaryOpModule(_m38, _m47, 'div')
        _m57 = VectorBinaryOpModule(_m58, _m65, 'div')
        _m68 = ResidualBucketScatterAddModule(_m69, [0.0] * 3, dtype=torch.float64)
        _m81 = VectorBinaryOpModule(_m82, _m85, 'div')
        _m36 = ResidualBucketScatterAddModule(_m37, [0.0] * 1, dtype=torch.float64)
        _m56 = ResidualBucketScatterAddModule(_m57, [0.0] * 1, dtype=torch.float64)
        _m80 = ResidualBucketScatterAddModule(_m81, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m10, _m16, _m24, _m36, _m50, _m56, _m68, _m80], [[0] * 3, [0] * 2, [0] * 9, [0] * 2, [0] * 1, [0] * 5, [0] * 1, [0] * 3, [0] * 1], 15, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 15
