"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Schaffer2Model
  model = Schaffer2Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Schaffer2Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Schaffer2_model_state.pt'

        _m2 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'pow')
        _m8 = VectorBinaryOpModule(_m9, _m12, 'add')
        _m17 = VectorBinaryOpModule(_m18, _m21, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m15, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m24, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorUnaryOpModule(_m5, 'sin')
        _m3 = VectorUnaryOpModule(_m4, 'sin')
        _m1 = VectorBinaryOpModule(_m2, _m3, 'add')
        _m0 = VectorBinaryOpModule(_m1, _m16, 'mul')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
