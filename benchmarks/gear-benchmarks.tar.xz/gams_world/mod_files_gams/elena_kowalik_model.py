"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaKowalikModel
  model = ElenaKowalikModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class ElenaKowalikModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_kowalik_model_state.pt'

        _m5 = ConstantVectorModule([0.0] * 10, dtype=torch.float64)
        _m8 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m10 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = SharedLinearFormModule(None, [[0.0] * 4 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m18 = LastDimSliceModule(0, 1)
        _m19 = LastDimSliceModule(1, 2)
        _m20 = LastDimSliceModule(2, 3)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m10, 'div')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'div')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m21, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m22, 'pow')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m12 = SharedLinearSingleCoreModule(_m13, _m14)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m12])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
