"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import BeckerlagoModel
  model = BeckerlagoModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class BeckerlagoModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'BeckerLago_model_state.pt'

        _m6 = VariableVectorGatherModule([0] * 2)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m4 = VectorUnaryOpModule(_m5, 'sqrt')
        _m10 = VectorUnaryOpModule(_m11, 'sqrt')
        _m3 = VectorBinaryOpModule(_m4, _m8, 'sub')
        _m9 = VectorBinaryOpModule(_m10, _m14, 'sub')
        _m2 = VectorBinaryOpModule(_m3, _m9, 'mul')
        _m1 = VectorScaleModule(_m2, 1, dtype=torch.float64)
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
