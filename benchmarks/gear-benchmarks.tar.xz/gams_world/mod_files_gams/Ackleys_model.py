"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import AckleysModel
  model = AckleysModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class AckleysModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Ackleys_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 1)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 1)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 1)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = VariableVectorGatherModule([0] * 1)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m49 = SharedLinearFormModule(None, [[0.0] * 10 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = LastDimSliceModule(0, 1)
        _m65 = LastDimSliceModule(2, 3)
        _m67 = LastDimSliceModule(3, 4)
        _m69 = LastDimSliceModule(4, 5)
        _m71 = LastDimSliceModule(5, 6)
        _m73 = LastDimSliceModule(6, 7)
        _m75 = LastDimSliceModule(7, 8)
        _m77 = LastDimSliceModule(8, 9)
        _m79 = LastDimSliceModule(9, 10)
        _m81 = LastDimSliceModule(1, 2)
        _m82 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VectorBinaryOpModule(_m18, _m19, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'pow')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'pow')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'pow')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'pow')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'pow')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'pow')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'pow')
        _m62 = VectorUnaryOpModule(_m63, 'cos')
        _m64 = VectorUnaryOpModule(_m65, 'cos')
        _m66 = VectorUnaryOpModule(_m67, 'cos')
        _m68 = VectorUnaryOpModule(_m69, 'cos')
        _m70 = VectorUnaryOpModule(_m71, 'cos')
        _m72 = VectorUnaryOpModule(_m73, 'cos')
        _m74 = VectorUnaryOpModule(_m75, 'cos')
        _m76 = VectorUnaryOpModule(_m77, 'cos')
        _m78 = VectorUnaryOpModule(_m79, 'cos')
        _m80 = VectorUnaryOpModule(_m81, 'cos')
        _m16 = VectorBinaryOpModule(_m17, _m20, 'add')
        _m61 = VectorBinaryOpModule(_m62, _m64, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m23, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m66, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m26, 'add')
        _m59 = VectorBinaryOpModule(_m60, _m68, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m29, 'add')
        _m58 = VectorBinaryOpModule(_m59, _m70, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m32, 'add')
        _m57 = VectorBinaryOpModule(_m58, _m72, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m35, 'add')
        _m56 = VectorBinaryOpModule(_m57, _m74, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m38, 'add')
        _m55 = VectorBinaryOpModule(_m56, _m76, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m41, 'add')
        _m54 = VectorBinaryOpModule(_m55, _m78, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m44, 'add')
        _m53 = VectorBinaryOpModule(_m54, _m80, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'mul')
        _m5 = VectorUnaryOpModule(_m6, 'sqrt')
        _m50 = VectorUnaryOpModule(_m51, 'exp')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m48 = SharedLinearSingleCoreModule(_m49, _m50)
        _m2 = VectorUnaryOpModule(_m3, 'exp')
        _m47 = VectorScaleModule(_m48, -1, dtype=torch.float64)
        _m1 = VectorScaleModule(_m2, -20, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m47, _m82])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
