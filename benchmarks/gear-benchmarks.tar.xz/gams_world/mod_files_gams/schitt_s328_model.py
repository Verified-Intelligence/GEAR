"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS328Model
  model = SchittS328Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class SchittS328Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s328_model_state.pt'

        _m3 = VariableVectorGatherModule([0] * 1)
        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = VariableVectorGatherModule([0] * 1)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 1)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m2 = VectorBinaryOpModule(_m3, _m4, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'pow')
        _m27 = VectorBinaryOpModule(_m28, _m29, 'pow')
        _m30 = VectorBinaryOpModule(_m31, _m32, 'pow')
        _m1 = VectorScaleModule(_m2, 0.1, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'add')
        _m19 = VectorBinaryOpModule(_m20, _m23, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m30, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m12, 'div')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'add')
        _m5 = VectorScaleModule(_m6, 0.1, dtype=torch.float64)
        _m16 = VectorBinaryOpModule(_m17, _m26, 'div')
        _m15 = VectorScaleModule(_m16, 0.1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m5, _m15, _m33])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
