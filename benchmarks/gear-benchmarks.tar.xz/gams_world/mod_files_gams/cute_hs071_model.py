"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs071Model
  model = CuteHs071Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteHs071Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs071_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 1)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 1)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m33 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 1)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 1)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = VariableVectorGatherModule([0] * 8)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m42, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'mul')
        _m12 = VectorBinaryOpModule(_m13, _m16, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m29, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m43, 'pow')
        _m11 = VectorBinaryOpModule(_m12, _m19, 'add')
        _m24 = VectorBinaryOpModule(_m25, _m32, 'mul')
        _m38 = ResidualBucketScatterAddModule(_m39, [0.0] * 8, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m11, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m35, 'mul')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m22 = ResidualBucketScatterAddModule(_m23, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m22, _m38], [[0] * 1, [0] * 1, [0] * 8], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
