"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import EasomModel
  model = EasomModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorUnaryOpModule

class EasomModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Easom_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m6 = LastDimSliceModule(0, 1)
        _m8 = LastDimSliceModule(1, 2)
        _m13 = LastDimSliceModule(2, 3)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = LastDimSliceModule(3, 4)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorUnaryOpModule(_m6, 'cos')
        _m7 = VectorUnaryOpModule(_m8, 'cos')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'pow')
        _m4 = VectorUnaryOpModule(_m5, 'neg')
        _m11 = VectorUnaryOpModule(_m12, 'neg')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m15, 'sub')
        _m9 = VectorUnaryOpModule(_m10, 'exp')
        _m2 = VectorBinaryOpModule(_m3, _m9, 'mul')
        _m0 = SharedLinearSingleCoreModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
