"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs038Model
  model = Hs038Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Hs038Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs038_model_state.pt'

        _m3 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m9 = VariableVectorGatherModule([0] * 2)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m25 = LastDimSliceModule(0, 1)
        _m26 = LastDimSliceModule(1, 2)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m7 = VectorUnaryOpModule(_m8, 'neg')
        _m13 = VectorScaleModule(_m14, 1, dtype=torch.float64)
        _m18 = VectorScaleModule(_m19, 10.1, dtype=torch.float64)
        _m22 = SharedLinearSingleCoreModule(_m23, _m24)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'add')
        _m12 = VectorReduceModule(_m13, 'sum')
        _m17 = VectorReduceModule(_m18, 'sum')
        _m4 = VectorBinaryOpModule(_m5, _m11, 'pow')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m12, _m17, _m22])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
