"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ModrosenbrockModel
  model = ModrosenbrockModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class ModrosenbrockModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'ModRosenbrock_model_state.pt'

        _m3 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m7 = LastDimSliceModule(2, 3)
        _m8 = LastDimSliceModule(0, 1)
        _m9 = LastDimSliceModule(1, 2)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = LastDimSliceModule(1, 2)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = LastDimSliceModule(0, 1)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m10, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m21, 'sub')
        _m2 = SharedLinearSingleCoreModule(_m3, _m4)
        _m14 = VectorBinaryOpModule(_m15, _m22, 'sub')
        _m1 = VectorScaleModule(_m2, 100, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m23, 'pow')
        _m11 = SharedLinearSingleCoreModule(_m12, _m13)
        _m0 = VectorSumModule([_m1, _m11])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
