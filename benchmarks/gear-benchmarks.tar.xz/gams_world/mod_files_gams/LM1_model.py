"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Lm1Model
  model = Lm1Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Lm1Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'LM1_model_state.pt'

        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m18 = LastDimSliceModule(0, 1)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m24 = LastDimSliceModule(0, 1)
        _m25 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VectorUnaryOpModule(_m8, 'sin')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m17 = VectorUnaryOpModule(_m18, 'sin')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m9, 'pow')
        _m16 = VectorBinaryOpModule(_m17, _m19, 'pow')
        _m21 = SharedLinearSingleCoreModule(_m22, _m23)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'add')
        _m14 = SharedLinearSingleCoreModule(_m15, _m16)
        _m20 = VectorScaleModule(_m21, 1.04719755119667, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m10, 'mul')
        _m13 = VectorScaleModule(_m14, 10.4719755119667, dtype=torch.float64)
        _m2 = VectorScaleModule(_m3, 1.04719755119667, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m13, _m20])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
