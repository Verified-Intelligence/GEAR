"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteAlsotameModel
  model = CuteAlsotameModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class CuteAlsotameModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_alsotame_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(2, 3)
        _m6 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = LastDimSliceModule(2, 3)
        _m13 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = LastDimSliceModule(2, 3)
        _m3 = VectorUnaryOpModule(_m4, 'exp')
        _m10 = VectorUnaryOpModule(_m11, 'sin')
        _m16 = VectorUnaryOpModule(_m17, 'sin')
        _m1 = SharedLinearAugmentModule(_m2, _m3)
        _m9 = VectorScaleModule(_m10, -1, dtype=torch.float64)
        _m14 = VectorSumModule([_m15, _m16])
        _m7 = VectorSumModule([_m8, _m9])
        _m12 = SharedLinearAugmentModule(_m13, _m14)
        _m5 = SharedLinearAugmentModule(_m6, _m7)
        _m0 = CombinedASTModule([_m1, _m5, _m12], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
