"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Cosmix4Model
  model = Cosmix4Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Cosmix4Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'CosMix4_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 4)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m9 = BatchedAffineGatherModule([[0] * 1 for _ in range(4)], [[0.0] * 1 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m8 = VectorUnaryOpModule(_m9, 'cos')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m7 = VectorScaleModule(_m8, -0.1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m6 = VectorReduceModule(_m7, 'sum')
        _m0 = VectorSumModule([_m1, _m6])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
