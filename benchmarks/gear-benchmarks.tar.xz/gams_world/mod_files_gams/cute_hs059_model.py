"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs059Model
  model = CuteHs059Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class CuteHs059Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs059_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 2)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m18 = VariableVectorGatherModule([0] * 2)
        _m20 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = VariableVectorGatherModule([0] * 2)
        _m25 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m26 = VariableVectorGatherModule([0] * 2)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 2)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 1)
        _m41 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m45 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 3)
        _m47 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m50 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m54 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = VariableVectorGatherModule([0] * 1)
        _m59 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m63 = VariableVectorGatherModule([0] * 1)
        _m64 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m68 = VariableVectorGatherModule([0] * 1)
        _m69 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m73 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m76 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m77 = VariableVectorGatherModule([0] * 1)
        _m78 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m82 = VariableVectorGatherModule([0] * 1)
        _m83 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m87 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m90 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m91 = VariableVectorGatherModule([0] * 1)
        _m92 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m95 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m96 = VariableVectorGatherModule([0] * 1)
        _m97 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m101 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m102 = VariableVectorGatherModule([0] * 2)
        _m105 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m106 = VariableVectorGatherModule([0] * 2)
        _m107 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m112 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m113 = VariableVectorGatherModule([0] * 1)
        _m115 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m116 = VariableVectorGatherModule([0] * 1)
        _m120 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m122 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m123 = VariableVectorGatherModule([0] * 1)
        _m124 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m53 = VectorBinaryOpModule(_m54, _m55, 'mul')
        _m61 = VectorBinaryOpModule(_m62, _m63, 'mul')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'mul')
        _m75 = VectorBinaryOpModule(_m76, _m77, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m89 = VectorBinaryOpModule(_m90, _m91, 'mul')
        _m94 = VectorBinaryOpModule(_m95, _m96, 'mul')
        _m100 = VectorBinaryOpModule(_m101, _m102, 'mul')
        _m104 = VectorBinaryOpModule(_m105, _m106, 'mul')
        _m111 = VectorBinaryOpModule(_m112, _m113, 'mul')
        _m114 = VectorBinaryOpModule(_m115, _m116, 'mul')
        _m121 = VectorBinaryOpModule(_m122, _m123, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m15 = VectorBinaryOpModule(_m16, _m19, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m31, 'pow')
        _m37 = VectorBinaryOpModule(_m38, _m41, 'pow')
        _m43 = VectorBinaryOpModule(_m44, _m47, 'pow')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m64, 'pow')
        _m65 = VectorBinaryOpModule(_m66, _m69, 'pow')
        _m74 = VectorBinaryOpModule(_m75, _m78, 'pow')
        _m79 = VectorBinaryOpModule(_m80, _m83, 'pow')
        _m88 = VectorBinaryOpModule(_m89, _m92, 'pow')
        _m93 = VectorBinaryOpModule(_m94, _m97, 'pow')
        _m103 = VectorBinaryOpModule(_m104, _m107, 'pow')
        _m110 = VectorBinaryOpModule(_m111, _m114, 'mul')
        _m119 = VectorBinaryOpModule(_m120, _m121, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 2, dtype=torch.float64)
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 2, dtype=torch.float64)
        _m23 = VectorBinaryOpModule(_m24, _m27, 'mul')
        _m33 = VectorBinaryOpModule(_m34, _m37, 'mul')
        _m42 = ResidualBucketScatterAddModule(_m43, [0.0] * 3, dtype=torch.float64)
        _m49 = VectorBinaryOpModule(_m50, _m51, 'div')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'mul')
        _m72 = VectorBinaryOpModule(_m73, _m74, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m99 = VectorBinaryOpModule(_m100, _m103, 'mul')
        _m109 = VectorUnaryOpModule(_m110, 'exp')
        _m118 = VectorBinaryOpModule(_m119, _m124, 'pow')
        _m22 = ResidualBucketScatterAddModule(_m23, [0.0] * 2, dtype=torch.float64)
        _m32 = ResidualBucketScatterAddModule(_m33, [0.0] * 1, dtype=torch.float64)
        _m48 = ResidualBucketScatterAddModule(_m49, [0.0] * 1, dtype=torch.float64)
        _m57 = VectorBinaryOpModule(_m58, _m65, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m79, 'mul')
        _m85 = VectorBinaryOpModule(_m86, _m93, 'mul')
        _m98 = ResidualBucketScatterAddModule(_m99, [0.0] * 2, dtype=torch.float64)
        _m108 = ResidualBucketScatterAddModule(_m109, [0.0] * 1, dtype=torch.float64)
        _m117 = ResidualBucketScatterAddModule(_m118, [0.0] * 1, dtype=torch.float64)
        _m56 = ResidualBucketScatterAddModule(_m57, [0.0] * 1, dtype=torch.float64)
        _m70 = ResidualBucketScatterAddModule(_m71, [0.0] * 1, dtype=torch.float64)
        _m84 = ResidualBucketScatterAddModule(_m85, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m14, _m22, _m32, _m42, _m48, _m56, _m70, _m84, _m98, _m108, _m117], [[0] * 2, [0] * 2, [0] * 2, [0] * 2, [0] * 1, [0] * 3, [0] * 1, [0] * 1, [0] * 1, [0] * 1, [0] * 2, [0] * 1, [0] * 1], 4, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 4
