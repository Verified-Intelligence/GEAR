"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import MultigaussModel
  model = MultigaussModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class MultigaussModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'MultiGauss_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = ConstantVectorModule([0.0] * 4, dtype=torch.float64)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = VariableVectorGatherModule([0] * 4)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(4)], [0.0] * 4, dtype=torch.float64)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m9, 'add')
        _m18 = VectorBinaryOpModule(_m19, _m22, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m2 = VectorUnaryOpModule(_m3, 'exp')
        _m15 = VectorUnaryOpModule(_m16, 'exp')
        _m1 = VectorScaleModule(_m2, -0.5, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m12 = VectorReduceModule(_m13, 'sum')
        _m0 = VectorSumModule([_m1, _m12])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
