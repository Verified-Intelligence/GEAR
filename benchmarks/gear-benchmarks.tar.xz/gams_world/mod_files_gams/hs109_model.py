"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs109Model
  model = Hs109Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorUnaryOpModule

class Hs109Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs109_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 6, [[0.0] * 6 for _ in range(17)], [0.0] * 17, dtype=torch.float64)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VariableVectorGatherModule([0] * 2)
        _m7 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = VariableVectorGatherModule([0] * 22)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m21 = ConstantVectorModule([0.0] * 8, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 8)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 8)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 8)
        _m35 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = VariableVectorGatherModule([0] * 4)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m41 = VariableVectorGatherModule([0] * 4)
        _m43 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m44 = VariableVectorGatherModule([0] * 4)
        _m46 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m47 = VariableVectorGatherModule([0] * 4)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ConstantVectorModule([0.0] * 8, dtype=torch.float64)
        _m56 = VariableVectorGatherModule([0] * 8)
        _m58 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 8)
        _m61 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m62 = VariableVectorGatherModule([0] * 8)
        _m69 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m71 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m72 = VariableVectorGatherModule([0] * 4)
        _m74 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m75 = VariableVectorGatherModule([0] * 4)
        _m77 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m78 = VariableVectorGatherModule([0] * 4)
        _m80 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m81 = VariableVectorGatherModule([0] * 4)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m36 = VectorBinaryOpModule(_m37, _m38, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m44, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m47, 'mul')
        _m54 = VectorBinaryOpModule(_m55, _m56, 'mul')
        _m57 = VectorBinaryOpModule(_m58, _m59, 'mul')
        _m60 = VectorBinaryOpModule(_m61, _m62, 'mul')
        _m70 = VectorBinaryOpModule(_m71, _m72, 'mul')
        _m73 = VectorBinaryOpModule(_m74, _m75, 'mul')
        _m76 = VectorBinaryOpModule(_m77, _m78, 'mul')
        _m79 = VectorBinaryOpModule(_m80, _m81, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m7, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'pow')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'add')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'add')
        _m52 = VectorBinaryOpModule(_m53, _m54, 'add')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'add')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 2, dtype=torch.float64)
        _m8 = ResidualBucketScatterAddModule(_m9, [0.0] * 22, dtype=torch.float64)
        _m17 = VectorUnaryOpModule(_m18, 'sin')
        _m33 = VectorBinaryOpModule(_m34, _m39, 'add')
        _m51 = VectorUnaryOpModule(_m52, 'cos')
        _m67 = VectorBinaryOpModule(_m68, _m73, 'add')
        _m16 = VectorBinaryOpModule(_m17, _m23, 'mul')
        _m32 = VectorUnaryOpModule(_m33, 'sin')
        _m50 = VectorBinaryOpModule(_m51, _m57, 'mul')
        _m66 = VectorUnaryOpModule(_m67, 'cos')
        _m15 = VectorBinaryOpModule(_m16, _m26, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m42, 'mul')
        _m49 = VectorBinaryOpModule(_m50, _m60, 'mul')
        _m65 = VectorBinaryOpModule(_m66, _m76, 'mul')
        _m14 = ResidualBucketScatterAddModule(_m15, [0.0] * 8, dtype=torch.float64)
        _m30 = VectorBinaryOpModule(_m31, _m45, 'mul')
        _m48 = ResidualBucketScatterAddModule(_m49, [0.0] * 8, dtype=torch.float64)
        _m64 = VectorBinaryOpModule(_m65, _m79, 'mul')
        _m29 = ResidualBucketScatterAddModule(_m30, [0.0] * 4, dtype=torch.float64)
        _m63 = ResidualBucketScatterAddModule(_m64, [0.0] * 4, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m8, _m14, _m29, _m48, _m63], [[0] * 2, [0] * 22, [0] * 8, [0] * 4, [0] * 8, [0] * 4], 17, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 17
