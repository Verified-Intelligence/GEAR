"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CutePortfl2Model
  model = CutePortfl2Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ConstantVectorModule, CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CutePortfl2Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_portfl2_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 12, [[0.0] * 12 for _ in range(3)], [0.0] * 3, dtype=torch.float64)
        _m16 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m18 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 60)
        _m21 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 60)
        _m24 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m25 = VariableVectorGatherModule([0] * 60)
        _m27 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m28 = VariableVectorGatherModule([0] * 60)
        _m30 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m31 = VariableVectorGatherModule([0] * 60)
        _m33 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m34 = VariableVectorGatherModule([0] * 60)
        _m36 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m37 = VariableVectorGatherModule([0] * 60)
        _m39 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 60)
        _m42 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m43 = VariableVectorGatherModule([0] * 60)
        _m45 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m46 = VariableVectorGatherModule([0] * 60)
        _m48 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m49 = VariableVectorGatherModule([0] * 60)
        _m51 = ConstantVectorModule([0.0] * 60, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 60)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m67 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m69 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m70 = VariableVectorGatherModule([0] * 2)
        _m72 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m73 = VariableVectorGatherModule([0] * 2)
        _m75 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m76 = VariableVectorGatherModule([0] * 2)
        _m78 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m79 = VariableVectorGatherModule([0] * 2)
        _m81 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m82 = VariableVectorGatherModule([0] * 2)
        _m84 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m85 = VariableVectorGatherModule([0] * 2)
        _m87 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m88 = VariableVectorGatherModule([0] * 2)
        _m90 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m91 = VariableVectorGatherModule([0] * 2)
        _m93 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m94 = VariableVectorGatherModule([0] * 2)
        _m96 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m97 = VariableVectorGatherModule([0] * 2)
        _m99 = ConstantVectorModule([0.0] * 2, dtype=torch.float64)
        _m100 = VariableVectorGatherModule([0] * 2)
        _m101 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m23 = VectorBinaryOpModule(_m24, _m25, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m29 = VectorBinaryOpModule(_m30, _m31, 'mul')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m43, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m47 = VectorBinaryOpModule(_m48, _m49, 'mul')
        _m50 = VectorBinaryOpModule(_m51, _m52, 'mul')
        _m68 = VectorBinaryOpModule(_m69, _m70, 'mul')
        _m71 = VectorBinaryOpModule(_m72, _m73, 'mul')
        _m74 = VectorBinaryOpModule(_m75, _m76, 'mul')
        _m77 = VectorBinaryOpModule(_m78, _m79, 'mul')
        _m80 = VectorBinaryOpModule(_m81, _m82, 'mul')
        _m83 = VectorBinaryOpModule(_m84, _m85, 'mul')
        _m86 = VectorBinaryOpModule(_m87, _m88, 'mul')
        _m89 = VectorBinaryOpModule(_m90, _m91, 'mul')
        _m92 = VectorBinaryOpModule(_m93, _m94, 'mul')
        _m95 = VectorBinaryOpModule(_m96, _m97, 'mul')
        _m98 = VectorBinaryOpModule(_m99, _m100, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'add')
        _m66 = VectorBinaryOpModule(_m67, _m68, 'add')
        _m14 = VectorBinaryOpModule(_m15, _m20, 'add')
        _m65 = VectorBinaryOpModule(_m66, _m71, 'add')
        _m13 = VectorBinaryOpModule(_m14, _m23, 'add')
        _m64 = VectorBinaryOpModule(_m65, _m74, 'add')
        _m12 = VectorBinaryOpModule(_m13, _m26, 'add')
        _m63 = VectorBinaryOpModule(_m64, _m77, 'add')
        _m11 = VectorBinaryOpModule(_m12, _m29, 'add')
        _m62 = VectorBinaryOpModule(_m63, _m80, 'add')
        _m10 = VectorBinaryOpModule(_m11, _m32, 'add')
        _m61 = VectorBinaryOpModule(_m62, _m83, 'add')
        _m9 = VectorBinaryOpModule(_m10, _m35, 'add')
        _m60 = VectorBinaryOpModule(_m61, _m86, 'add')
        _m8 = VectorBinaryOpModule(_m9, _m38, 'add')
        _m59 = VectorBinaryOpModule(_m60, _m89, 'add')
        _m7 = VectorBinaryOpModule(_m8, _m41, 'add')
        _m58 = VectorBinaryOpModule(_m59, _m92, 'add')
        _m6 = VectorBinaryOpModule(_m7, _m44, 'add')
        _m57 = VectorBinaryOpModule(_m58, _m95, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m47, 'add')
        _m56 = VectorBinaryOpModule(_m57, _m98, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m50, 'add')
        _m55 = VectorBinaryOpModule(_m56, _m101, 'pow')
        _m3 = VectorBinaryOpModule(_m4, _m53, 'pow')
        _m54 = ResidualBucketScatterAddModule(_m55, [0.0] * 2, dtype=torch.float64)
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 60, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m54], [[0] * 60, [0] * 2], 3, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
