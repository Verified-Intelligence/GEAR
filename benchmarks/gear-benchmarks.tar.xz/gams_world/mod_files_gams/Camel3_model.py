"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Camel3Model
  model = Camel3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class Camel3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Camel3_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m5 = LastDimSliceModule(0, 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = LastDimSliceModule(0, 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m14 = LastDimSliceModule(1, 2)
        _m15 = LastDimSliceModule(0, 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m17 = LastDimSliceModule(0, 1)
        _m21 = VariableVectorGatherModule([0] * 2)
        _m22 = VariableVectorGatherModule([0] * 2)
        _m10 = VectorBinaryOpModule(_m11, _m12, 'pow')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m19 = VectorScaleModule(_m20, 1, dtype=torch.float64)
        _m7 = VectorBinaryOpModule(_m8, _m13, 'sub')
        _m18 = VectorReduceModule(_m19, 'sum')
        _m6 = VectorBinaryOpModule(_m7, _m16, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m17, 'mul')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m0 = VectorSumModule([_m1, _m18])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
