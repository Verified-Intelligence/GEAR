"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Zeldasine10Model
  model = Zeldasine10Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Zeldasine10Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Zeldasine10_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 10 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = LastDimSliceModule(0, 1)
        _m17 = LastDimSliceModule(2, 3)
        _m19 = LastDimSliceModule(3, 4)
        _m21 = LastDimSliceModule(4, 5)
        _m23 = LastDimSliceModule(5, 6)
        _m25 = LastDimSliceModule(6, 7)
        _m27 = LastDimSliceModule(7, 8)
        _m29 = LastDimSliceModule(8, 9)
        _m31 = LastDimSliceModule(9, 10)
        _m33 = LastDimSliceModule(1, 2)
        _m36 = SharedLinearFormModule(None, [[0.0] * 10 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m47 = LastDimSliceModule(0, 1)
        _m49 = LastDimSliceModule(2, 3)
        _m51 = LastDimSliceModule(3, 4)
        _m53 = LastDimSliceModule(4, 5)
        _m55 = LastDimSliceModule(5, 6)
        _m57 = LastDimSliceModule(6, 7)
        _m59 = LastDimSliceModule(7, 8)
        _m61 = LastDimSliceModule(8, 9)
        _m63 = LastDimSliceModule(9, 10)
        _m65 = LastDimSliceModule(1, 2)
        _m14 = VectorUnaryOpModule(_m15, 'sin')
        _m16 = VectorUnaryOpModule(_m17, 'sin')
        _m18 = VectorUnaryOpModule(_m19, 'sin')
        _m20 = VectorUnaryOpModule(_m21, 'sin')
        _m22 = VectorUnaryOpModule(_m23, 'sin')
        _m24 = VectorUnaryOpModule(_m25, 'sin')
        _m26 = VectorUnaryOpModule(_m27, 'sin')
        _m28 = VectorUnaryOpModule(_m29, 'sin')
        _m30 = VectorUnaryOpModule(_m31, 'sin')
        _m32 = VectorUnaryOpModule(_m33, 'sin')
        _m46 = VectorUnaryOpModule(_m47, 'sin')
        _m48 = VectorUnaryOpModule(_m49, 'sin')
        _m50 = VectorUnaryOpModule(_m51, 'sin')
        _m52 = VectorUnaryOpModule(_m53, 'sin')
        _m54 = VectorUnaryOpModule(_m55, 'sin')
        _m56 = VectorUnaryOpModule(_m57, 'sin')
        _m58 = VectorUnaryOpModule(_m59, 'sin')
        _m60 = VectorUnaryOpModule(_m61, 'sin')
        _m62 = VectorUnaryOpModule(_m63, 'sin')
        _m64 = VectorUnaryOpModule(_m65, 'sin')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'mul')
        _m45 = VectorBinaryOpModule(_m46, _m48, 'mul')
        _m11 = VectorBinaryOpModule(_m12, _m16, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m50, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m18, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m52, 'mul')
        _m9 = VectorBinaryOpModule(_m10, _m20, 'mul')
        _m42 = VectorBinaryOpModule(_m43, _m54, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m22, 'mul')
        _m41 = VectorBinaryOpModule(_m42, _m56, 'mul')
        _m7 = VectorBinaryOpModule(_m8, _m24, 'mul')
        _m40 = VectorBinaryOpModule(_m41, _m58, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m26, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m60, 'mul')
        _m5 = VectorBinaryOpModule(_m6, _m28, 'mul')
        _m38 = VectorBinaryOpModule(_m39, _m62, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m30, 'mul')
        _m37 = VectorBinaryOpModule(_m38, _m64, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m32, 'mul')
        _m35 = SharedLinearSingleCoreModule(_m36, _m37)
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m34 = VectorScaleModule(_m35, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m34])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
