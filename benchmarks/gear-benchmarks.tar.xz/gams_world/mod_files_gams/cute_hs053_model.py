"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs053Model
  model = CuteHs053Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CrossFormulaLinearResidualVectorModule, ResidualBucketScatterAddModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule

class CuteHs053Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs053_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 5, [[0.0] * 5 for _ in range(7)], [0.0] * 7, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m22 = VariableVectorGatherModule([0] * 1)
        _m23 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = VariableVectorGatherModule([0] * 2)
        _m31 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'add')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m11, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m20, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m31, 'pow')
        _m2 = ResidualBucketScatterAddModule(_m3, [0.0] * 1, dtype=torch.float64)
        _m13 = VectorBinaryOpModule(_m14, _m23, 'pow')
        _m24 = ResidualBucketScatterAddModule(_m25, [0.0] * 2, dtype=torch.float64)
        _m12 = ResidualBucketScatterAddModule(_m13, [0.0] * 1, dtype=torch.float64)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2, _m12, _m24], [[0] * 1, [0] * 1, [0] * 2], 7, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
