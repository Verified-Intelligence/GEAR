"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import PavianiModel
  model = PavianiModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class PavianiModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Paviani_model_state.pt'

        _m5 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = BatchedAffineGatherModule([[0] * 1 for _ in range(10)], [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m21 = VariableVectorGatherModule([0] * 1)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m25 = VariableVectorGatherModule([0] * 1)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m31 = VariableVectorGatherModule([0] * 1)
        _m33 = VariableVectorGatherModule([0] * 1)
        _m35 = VariableVectorGatherModule([0] * 1)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m4 = VectorUnaryOpModule(_m5, 'log')
        _m10 = VectorUnaryOpModule(_m11, 'log')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m3 = VectorBinaryOpModule(_m4, _m6, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m12, 'pow')
        _m32 = VectorBinaryOpModule(_m33, _m34, 'mul')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m8 = VectorScaleModule(_m9, 1, dtype=torch.float64)
        _m30 = VectorBinaryOpModule(_m31, _m32, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = VectorReduceModule(_m8, 'sum')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'mul')
        _m24 = VectorBinaryOpModule(_m25, _m26, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'mul')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'mul')
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m17 = VectorUnaryOpModule(_m18, 'log')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'mul')
        _m14 = VectorUnaryOpModule(_m15, 'exp')
        _m13 = VectorScaleModule(_m14, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m7, _m13])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
