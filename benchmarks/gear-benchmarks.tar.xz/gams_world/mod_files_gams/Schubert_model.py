"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchubertModel
  model = SchubertModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorUnaryOpModule

class SchubertModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Schubert_model_state.pt'

        _m1 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m8 = LastDimSliceModule(0, 1)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m12 = LastDimSliceModule(1, 2)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = LastDimSliceModule(2, 3)
        _m18 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m20 = LastDimSliceModule(3, 4)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = LastDimSliceModule(4, 5)
        _m30 = LastDimSliceModule(5, 6)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m34 = LastDimSliceModule(6, 7)
        _m36 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m38 = LastDimSliceModule(7, 8)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m42 = LastDimSliceModule(8, 9)
        _m44 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m46 = LastDimSliceModule(9, 10)
        _m7 = VectorUnaryOpModule(_m8, 'cos')
        _m11 = VectorUnaryOpModule(_m12, 'cos')
        _m15 = VectorUnaryOpModule(_m16, 'cos')
        _m19 = VectorUnaryOpModule(_m20, 'cos')
        _m23 = VectorUnaryOpModule(_m24, 'cos')
        _m29 = VectorUnaryOpModule(_m30, 'cos')
        _m33 = VectorUnaryOpModule(_m34, 'cos')
        _m37 = VectorUnaryOpModule(_m38, 'cos')
        _m41 = VectorUnaryOpModule(_m42, 'cos')
        _m45 = VectorUnaryOpModule(_m46, 'cos')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'mul')
        _m17 = VectorBinaryOpModule(_m18, _m19, 'mul')
        _m21 = VectorBinaryOpModule(_m22, _m23, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m43 = VectorBinaryOpModule(_m44, _m45, 'mul')
        _m6 = VectorBinaryOpModule(_m7, _m9, 'add')
        _m28 = VectorBinaryOpModule(_m29, _m31, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m13, 'add')
        _m27 = VectorBinaryOpModule(_m28, _m35, 'add')
        _m4 = VectorBinaryOpModule(_m5, _m17, 'add')
        _m26 = VectorBinaryOpModule(_m27, _m39, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m21, 'add')
        _m25 = VectorBinaryOpModule(_m26, _m43, 'add')
        _m2 = VectorBinaryOpModule(_m3, _m25, 'mul')
        _m0 = SharedLinearSingleCoreModule(_m1, _m2)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
