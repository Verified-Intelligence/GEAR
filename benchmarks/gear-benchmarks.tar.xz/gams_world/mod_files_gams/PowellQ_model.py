"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import PowellqModel
  model = PowellqModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class PowellqModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'PowellQ_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m4 = LastDimSliceModule(1, 2)
        _m5 = LastDimSliceModule(0, 1)
        _m7 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m9 = LastDimSliceModule(1, 2)
        _m10 = LastDimSliceModule(0, 1)
        _m12 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m14 = LastDimSliceModule(0, 1)
        _m15 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m20 = LastDimSliceModule(0, 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'mul')
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m13 = VectorBinaryOpModule(_m14, _m15, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m6 = SharedLinearSingleCoreModule(_m7, _m8)
        _m11 = SharedLinearSingleCoreModule(_m12, _m13)
        _m17 = SharedLinearSingleCoreModule(_m18, _m19)
        _m16 = VectorScaleModule(_m17, 10, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m6, _m11, _m16])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
