"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import RosenbrockModel
  model = RosenbrockModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import BatchedAffineGatherModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule

class RosenbrockModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'Rosenbrock_model_state.pt'

        _m6 = VariableVectorGatherModule([0] * 9)
        _m7 = VariableVectorGatherModule([0] * 9)
        _m8 = VariableVectorGatherModule([0] * 9)
        _m11 = VariableVectorGatherModule([0] * 9)
        _m12 = BatchedAffineGatherModule([[0] * 1 for _ in range(9)], [[0.0] * 1 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m13 = BatchedAffineGatherModule([[0] * 1 for _ in range(9)], [[0.0] * 1 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m17 = BatchedAffineGatherModule([[0] * 1 for _ in range(9)], [[0.0] * 1 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m18 = BatchedAffineGatherModule([[0] * 1 for _ in range(9)], [[0.0] * 1 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m12, 'mul')
        _m16 = VectorBinaryOpModule(_m17, _m18, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m8, 'sub')
        _m9 = VectorBinaryOpModule(_m10, _m13, 'sub')
        _m15 = VectorScaleModule(_m16, 1, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m9, 'mul')
        _m14 = VectorReduceModule(_m15, 'sum')
        _m2 = VectorScaleModule(_m3, 1, dtype=torch.float64)
        _m1 = VectorReduceModule(_m2, 'sum')
        _m0 = VectorSumModule([_m1, _m14])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
