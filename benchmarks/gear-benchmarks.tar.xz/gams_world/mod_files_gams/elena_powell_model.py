"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaPowellModel
  model = ElenaPowellModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class ElenaPowellModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_powell_model_state.pt'

        _m2 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m4 = LastDimSliceModule(0, 1)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m10 = LastDimSliceModule(0, 1)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m15 = LastDimSliceModule(0, 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m21 = LastDimSliceModule(0, 1)
        _m22 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m22, 'pow')
        _m1 = SharedLinearSingleCoreModule(_m2, _m3)
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m12 = SharedLinearSingleCoreModule(_m13, _m14)
        _m18 = SharedLinearSingleCoreModule(_m19, _m20)
        _m6 = VectorScaleModule(_m7, 5, dtype=torch.float64)
        _m17 = VectorScaleModule(_m18, 10, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m6, _m12, _m17])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
