"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Hs080Model
  model = Hs080Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class Hs080Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'hs080_model_state.pt'

        _m3 = VariableVectorGatherModule([0] * 1)
        _m5 = VariableVectorGatherModule([0] * 1)
        _m7 = VariableVectorGatherModule([0] * 1)
        _m9 = VariableVectorGatherModule([0] * 1)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m12 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = VariableVectorGatherModule([0] * 5)
        _m17 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 5)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m26 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m29 = VariableVectorGatherModule([0] * 1)
        _m30 = VariableVectorGatherModule([0] * 1)
        _m33 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m35 = LastDimSliceModule(1, 2)
        _m36 = LastDimSliceModule(0, 1)
        _m38 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m40 = VariableVectorGatherModule([0] * 1)
        _m41 = VariableVectorGatherModule([0] * 1)
        _m43 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m45 = LastDimSliceModule(1, 2)
        _m46 = LastDimSliceModule(0, 1)
        _m48 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m52 = VariableVectorGatherModule([0] * 2)
        _m53 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m55 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m59 = VariableVectorGatherModule([0] * 2)
        _m60 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VectorBinaryOpModule(_m9, _m10, 'mul')
        _m15 = VectorBinaryOpModule(_m16, _m17, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m28 = VectorBinaryOpModule(_m29, _m30, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m36, 'mul')
        _m39 = VectorBinaryOpModule(_m40, _m41, 'mul')
        _m44 = VectorBinaryOpModule(_m45, _m46, 'mul')
        _m51 = VectorBinaryOpModule(_m52, _m53, 'pow')
        _m58 = VectorBinaryOpModule(_m59, _m60, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m14 = VectorScaleModule(_m15, -1, dtype=torch.float64)
        _m21 = VectorScaleModule(_m22, 1, dtype=torch.float64)
        _m27 = VectorScaleModule(_m28, -1, dtype=torch.float64)
        _m32 = SharedLinearSingleCoreModule(_m33, _m34)
        _m42 = SharedLinearSingleCoreModule(_m43, _m44)
        _m50 = VectorScaleModule(_m51, -1, dtype=torch.float64)
        _m57 = VectorScaleModule(_m58, 1, dtype=torch.float64)
        _m4 = VectorBinaryOpModule(_m5, _m6, 'mul')
        _m13 = VectorReduceModule(_m14, 'sum')
        _m20 = VectorReduceModule(_m21, 'sum')
        _m31 = VectorScaleModule(_m32, -1, dtype=torch.float64)
        _m37 = VectorSumModule([_m38, _m39, _m42])
        _m49 = VectorReduceModule(_m50, 'sum')
        _m56 = VectorReduceModule(_m57, 'sum')
        _m2 = VectorBinaryOpModule(_m3, _m4, 'mul')
        _m11 = VectorSumModule([_m12, _m13])
        _m18 = VectorSumModule([_m19, _m20])
        _m25 = VectorSumModule([_m26, _m27, _m31])
        _m47 = VectorSumModule([_m48, _m49])
        _m54 = VectorSumModule([_m55, _m56])
        _m1 = VectorUnaryOpModule(_m2, 'exp')
        _m0 = CombinedASTModule([_m1, _m11, _m18, _m25, _m37, _m47, _m54], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2), ('scalar_at', 3, 3), ('scalar_at', 4, 4), ('scalar_at', 5, 5), ('scalar_at', 6, 6)], 7)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 7
