"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import StE17Model
  model = StE17Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, ScalarConstantModule, SharedLinearFormModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule

class StE17Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'st_e17_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m6 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VariableVectorGatherModule([0] * 1)
        _m9 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VariableVectorGatherModule([0] * 1)
        _m7 = VectorBinaryOpModule(_m8, _m9, 'pow')
        _m5 = VectorBinaryOpModule(_m6, _m7, 'mul')
        _m4 = VectorBinaryOpModule(_m5, _m10, 'div')
        _m3 = VectorScaleModule(_m4, -1, dtype=torch.float64)
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 1)], 2)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 2, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 2
