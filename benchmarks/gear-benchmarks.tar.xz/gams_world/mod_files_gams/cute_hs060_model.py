"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteHs060Model
  model = CuteHs060Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, LastDimSliceModule, ScalarConstantModule, SharedLinearAugmentModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorScaleModule, VectorSumModule

class CuteHs060Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_hs060_model_state.pt'

        _m2 = SharedLinearFormModule(None, [[0.0] * 3 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m5 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m7 = LastDimSliceModule(0, 1)
        _m8 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = LastDimSliceModule(3, 4)
        _m11 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m13 = LastDimSliceModule(4, 5)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m19 = VariableVectorGatherModule([0] * 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m23 = VariableVectorGatherModule([0] * 1)
        _m24 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m27 = VariableVectorGatherModule([0] * 1)
        _m28 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m30 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m32 = VariableVectorGatherModule([0] * 1)
        _m34 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 1)
        _m37 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m39 = VariableVectorGatherModule([0] * 1)
        _m40 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m6 = VectorBinaryOpModule(_m7, _m8, 'pow')
        _m9 = VectorBinaryOpModule(_m10, _m11, 'pow')
        _m12 = VectorBinaryOpModule(_m13, _m14, 'pow')
        _m22 = VectorBinaryOpModule(_m23, _m24, 'pow')
        _m26 = VectorBinaryOpModule(_m27, _m28, 'pow')
        _m35 = VectorBinaryOpModule(_m36, _m37, 'pow')
        _m38 = VectorBinaryOpModule(_m39, _m40, 'pow')
        _m4 = SharedLinearSingleCoreModule(_m5, _m6)
        _m20 = VectorBinaryOpModule(_m21, _m22, 'add')
        _m25 = VectorScaleModule(_m26, -1, dtype=torch.float64)
        _m33 = VectorBinaryOpModule(_m34, _m35, 'add')
        _m3 = VectorSumModule([_m4, _m9, _m12])
        _m18 = VectorBinaryOpModule(_m19, _m20, 'mul')
        _m31 = VectorBinaryOpModule(_m32, _m33, 'mul')
        _m1 = SharedLinearAugmentModule(_m2, _m3)
        _m17 = VectorScaleModule(_m18, -1, dtype=torch.float64)
        _m29 = VectorSumModule([_m30, _m31, _m38])
        _m15 = VectorSumModule([_m16, _m17, _m25])
        _m0 = CombinedASTModule([_m1, _m15, _m29], [('scalar_at', 0, 0), ('scalar_at', 1, 1), ('scalar_at', 2, 2)], 3)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 3
