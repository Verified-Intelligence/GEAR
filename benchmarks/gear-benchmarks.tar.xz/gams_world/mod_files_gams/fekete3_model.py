"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import Fekete3Model
  model = Fekete3Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class Fekete3Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'fekete3_model_state.pt'

        _m4 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m11 = VariableVectorGatherModule([0] * 105)
        _m13 = VariableVectorGatherModule([0] * 105)
        _m16 = VariableVectorGatherModule([0] * 105)
        _m18 = VariableVectorGatherModule([0] * 105)
        _m19 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m24 = VariableVectorGatherModule([0] * 105)
        _m26 = VariableVectorGatherModule([0] * 105)
        _m29 = VariableVectorGatherModule([0] * 105)
        _m31 = VariableVectorGatherModule([0] * 105)
        _m32 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m36 = VariableVectorGatherModule([0] * 105)
        _m38 = VariableVectorGatherModule([0] * 105)
        _m39 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m10 = VectorUnaryOpModule(_m11, 'cos')
        _m12 = VectorUnaryOpModule(_m13, 'sin')
        _m15 = VectorUnaryOpModule(_m16, 'cos')
        _m17 = VectorUnaryOpModule(_m18, 'sin')
        _m23 = VectorUnaryOpModule(_m24, 'sin')
        _m25 = VectorUnaryOpModule(_m26, 'sin')
        _m28 = VectorUnaryOpModule(_m29, 'sin')
        _m30 = VectorUnaryOpModule(_m31, 'sin')
        _m35 = VectorUnaryOpModule(_m36, 'cos')
        _m37 = VectorUnaryOpModule(_m38, 'cos')
        _m9 = VectorBinaryOpModule(_m10, _m12, 'mul')
        _m14 = VectorBinaryOpModule(_m15, _m17, 'mul')
        _m22 = VectorBinaryOpModule(_m23, _m25, 'mul')
        _m27 = VectorBinaryOpModule(_m28, _m30, 'mul')
        _m34 = VectorBinaryOpModule(_m35, _m37, 'sub')
        _m8 = VectorBinaryOpModule(_m9, _m14, 'sub')
        _m21 = VectorBinaryOpModule(_m22, _m27, 'sub')
        _m33 = VectorBinaryOpModule(_m34, _m39, 'pow')
        _m7 = VectorBinaryOpModule(_m8, _m19, 'pow')
        _m20 = VectorBinaryOpModule(_m21, _m32, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m20, 'add')
        _m5 = VectorBinaryOpModule(_m6, _m33, 'add')
        _m3 = VectorBinaryOpModule(_m4, _m5, 'add')
        _m2 = VectorUnaryOpModule(_m3, 'log')
        _m1 = VectorScaleModule(_m2, -1, dtype=torch.float64)
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
