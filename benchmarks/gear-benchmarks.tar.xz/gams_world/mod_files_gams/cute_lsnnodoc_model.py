"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteLsnnodocModel
  model = CuteLsnnodocModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import CombinedASTModule, CrossFormulaLinearResidualVectorModule, LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule, VectorUnaryOpModule

class CuteLsnnodocModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_lsnnodoc_model_state.pt'

        _m1 = SharedLinearFormModule([0] * 5, [[0.0] * 5 for _ in range(9)], [0.0] * 9, dtype=torch.float64)
        _m5 = SharedLinearFormModule([0] * 3, [[0.0] * 3 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m7 = LastDimSliceModule(0, 1)
        _m9 = LastDimSliceModule(1, 2)
        _m12 = VariableVectorGatherModule([0] * 1)
        _m13 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m15 = VariableVectorGatherModule([0] * 1)
        _m16 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m18 = SharedLinearFormModule([0] * 2, [[0.0] * 2 for _ in range(1)], [0.0] * 1, dtype=torch.float64)
        _m20 = LastDimSliceModule(0, 1)
        _m21 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = VectorUnaryOpModule(_m9, 'exp')
        _m11 = VectorBinaryOpModule(_m12, _m13, 'pow')
        _m14 = VectorBinaryOpModule(_m15, _m16, 'pow')
        _m19 = VectorBinaryOpModule(_m20, _m21, 'pow')
        _m6 = VectorBinaryOpModule(_m7, _m8, 'mul')
        _m10 = VectorBinaryOpModule(_m11, _m14, 'mul')
        _m17 = SharedLinearSingleCoreModule(_m18, _m19)
        _m4 = SharedLinearSingleCoreModule(_m5, _m6)
        _m3 = VectorSumModule([_m4, _m10, _m17])
        _m2 = CombinedASTModule([_m3], [('scalar_at', 0, 0)], 9)
        _m0 = CrossFormulaLinearResidualVectorModule(_m1, [_m2], None, 9, dtype=torch.float64)
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 9
