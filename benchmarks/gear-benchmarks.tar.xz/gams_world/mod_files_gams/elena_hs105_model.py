"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import ElenaHs105Model
  model = ElenaHs105Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import LastDimSliceModule, ScalarConstantModule, SharedLinearFormModule, SharedLinearSingleCoreModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorSumModule, VectorUnaryOpModule

class ElenaHs105Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'elena_hs105_model_state.pt'

        _m4 = VariableVectorGatherModule([0] * 2)
        _m5 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m8 = SharedLinearFormModule(None, [[0.0] * 2 for _ in range(2)], [0.0] * 2, dtype=torch.float64)
        _m11 = LastDimSliceModule(0, 1)
        _m13 = LastDimSliceModule(1, 2)
        _m14 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m3 = VectorBinaryOpModule(_m4, _m5, 'pow')
        _m10 = VectorUnaryOpModule(_m11, 'cos')
        _m12 = VectorUnaryOpModule(_m13, 'cos')
        _m2 = VectorScaleModule(_m3, 0.005, dtype=torch.float64)
        _m9 = VectorBinaryOpModule(_m10, _m12, 'mul')
        _m1 = VectorReduceModule(_m2, 'sum')
        _m7 = SharedLinearSingleCoreModule(_m8, _m9)
        _m6 = VectorScaleModule(_m7, -1, dtype=torch.float64)
        _m0 = VectorSumModule([_m1, _m6, _m14])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
