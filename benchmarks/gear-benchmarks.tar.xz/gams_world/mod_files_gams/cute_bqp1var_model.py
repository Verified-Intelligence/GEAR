"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import CuteBqp1varModel
  model = CuteBqp1varModel()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, VariableVectorGatherModule, VectorBinaryOpModule, VectorSumModule

class CuteBqp1varModel(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'cute_bqp1var_model_state.pt'

        _m2 = VariableVectorGatherModule([0] * 1)
        _m3 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m4 = VariableVectorGatherModule([0] * 1)
        _m1 = VectorBinaryOpModule(_m2, _m3, 'pow')
        _m0 = VectorSumModule([_m1, _m4])
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)

    def get_output_dimension(self):
        return 1
