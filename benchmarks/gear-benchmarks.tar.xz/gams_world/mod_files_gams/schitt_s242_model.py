"""
Generated from AMPL .mod file. Contains a single nn.Module class definition.

Structure only. Tensor data loaded from .pt file. Ensure the .pt file is in the same directory as this module.
  from <this_module> import SchittS242Model
  model = SchittS242Model()
"""

import torch
import torch.nn as nn
from pathlib import Path
from .modules import ScalarConstantModule, SharedLinearFormModule, VectorBinaryOpModule, VectorReduceModule, VectorScaleModule, VectorUnaryOpModule

class SchittS242Model(nn.Module):
    """PyTorch model generated from AMPL .mod file."""

    _is_maximization: bool = False

    @property
    def is_maximization(self) -> bool:
        return bool(self.__class__._is_maximization)

    def __init__(self, pt_path=None):
        super().__init__()
        if pt_path is None:
            pt_path = Path(__file__).resolve().parent / 'schitt_s242_model_state.pt'

        _m6 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m8 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m9 = SharedLinearFormModule([0] * 1, [[0.0] * 1 for _ in range(10)], [0.0] * 10, dtype=torch.float64)
        _m10 = ScalarConstantModule(0.0, dtype=torch.float64)
        _m5 = VectorUnaryOpModule(_m6, 'exp')
        _m7 = VectorUnaryOpModule(_m8, 'exp')
        _m4 = VectorBinaryOpModule(_m5, _m7, 'sub')
        _m3 = VectorBinaryOpModule(_m4, _m9, 'sub')
        _m2 = VectorBinaryOpModule(_m3, _m10, 'pow')
        _m1 = VectorScaleModule(_m2, 1, dtype=torch.float64)
        _m0 = VectorReduceModule(_m1, 'sum')
        self._root = _m0
        try:
            _sd = torch.load(pt_path, weights_only=True, map_location='cpu')
        except TypeError:
            _sd = torch.load(pt_path, map_location='cpu')
        if isinstance(_sd, dict) and 'state_dict' in _sd:
            _sd = _sd['state_dict']
        self._root.load_state_dict(_sd, strict=True)

    def forward(self, x):
        return self._root(x)
